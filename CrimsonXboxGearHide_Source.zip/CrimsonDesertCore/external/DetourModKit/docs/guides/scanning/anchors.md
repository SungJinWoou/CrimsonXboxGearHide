# Anchor Registry (`anchor.hpp`)

The Anchor Registry (`anchor.hpp`, `DetourModKit::anchor`) collapses patch-fragile constants into one declarative table that resolves at init and reports uniformly. It composes the existing self-healing backends documented in [aob-signatures.md](../../misc/aob-signatures.md), [rtti-walker.md](../rtti/rtti-walker.md), and [rtti-self-heal.md](../rtti/rtti-self-heal.md): `scan::resolve`, `scan::read_code_constant`, `scan::find_string_xref`, `scan::resolve_export`, and `rtti::vtable_for_type`. The module adds no scanner of its own. It adds the table, quorum corroboration, validators, and drift report.

## Anchor kinds

| `AnchorKind` | Backend | Resolves to |
|--------------|---------|-------------|
| `VtableIdentity` | `rtti::vtable_for_type` | A class vtable address, keyed on its mangled name |
| `RipGlobal` | `scan::resolve` | An absolute address (Direct or RIP-relative candidates) |
| `CodeOperand` | `scan::read_code_constant` | An in-code immediate or `[reg + disp]` displacement |
| `StringXref` | `scan::find_string_xref` | The instruction (or enclosing function) that references an immutable string literal |
| `ExportName` | `scan::resolve_export` | A named export, resolved by a walk of its module's PE Export Address Table (the most update-resilient kind) |
| `Manual` | none (pinned literal) | The literal, flagged as at-risk in a report |
| `CallArgHome` | reserved | Not yet resolvable (reports `Unsupported`) |
| `Quorum` | N-of-M vote across sub-anchors via `resolve` | The corroborated value, accepted only when at least N of M independent signals resolve and agree |
| `Unset` | none (fail-closed) | The default for an anchor whose `kind` was never set. Always reports `Failed` |

`Anchor::kind` defaults to `Unset`, so a designated-initializer table entry that forgets to set `kind` fails closed (`AnchorStatus::Failed`) rather than a silent resolve as a trusted `Manual` address 0. A declared `Unset` is always a mistake. It exists so the mistake fails safe. Always set `kind` explicitly.

A `StringXref` anchor is the most update-resilient kind that anchors on in-image content (an `ExportName` is more resilient still when the target is a named export, see below). It locates an immutable string literal in the image's read-only data and resolves the unique RIP-relative `lea` / `mov` that references it. It returns that instruction, or one of two alternatives:

- With `xref_return = scan::XrefReturn::EnclosingFunction`, the enclosing function's entry. It uses authoritative x64 `.pdata` bounds via `RtlLookupFunctionEntry`, with a heuristic prologue back-scan fallback.
- With `xref_return = scan::XrefReturn::StringPointerSlot`, the global data slot that a `mov [rip+slot], reg` caches the loaded pointer into. See [String-reference anchors](../../misc/aob-signatures.md).

Strings survive game patches far better than the code bytes around them. A `StringXref` anchor fails closed on an absent, duplicated (linker-pooled), or unreferenced string. Pick a long, specific literal that occurs and is referenced exactly once. `xref_require_terminator` (default true) keeps a prefix of a longer literal from a match ("Player" inside "PlayerController").

Set `xref_encoding = scan::StringEncoding::Utf16le` for `wchar_t` literals. The anchor text stays UTF-8 and is transcoded to UTF-16LE, with surrogate pairs for supplementary code points. A non-ASCII literal therefore resolves exactly, not as a search for widened bytes. Ill-formed UTF-8 (or an embedded NUL on either encoding) fails closed with `ErrorCode::MalformedQueryText` instead of a search for a different literal. The `Utf8` route stays byte-transparent, so a byte string that is not well-formed UTF-8 is still a usable anchor.

`xref_broad_match` (default false) selects the phase-2 reference scan. The default shape scan matches only `REX.W lea` / `mov reg, [rip+disp32]`. `xref_broad_match = true` keeps that scan and adds a Zydis decode sweep for rarer shapes (`cmp [rip+d], imm`, `push [rip+d]`, a no-REX `lea` / `mov`). If the default reports a miss for a string that you know is referenced, use broad mode. See [String-reference anchors](../../misc/aob-signatures.md) for the full two-mode model.

An `ExportName` anchor is the most update-resilient kind of all. It resolves a named export by a walk of the target module's PE Export Address Table (`scan::resolve_export`). An export name is a module's documented ABI, so it survives a game patch far better than the code bytes, string literals, or absolute addresses the other backends key on. An internal function can move or be rewritten every build, but an exported entry point keeps its name. Set `export_name` to the exact, case-sensitive symbol (no decoration). When the export lives in a module other than the one the anchor is resolved against, set `export_module` to the owning module's basename (`"engine.dll"`, for example). An empty `export_module` resolves the export within the resolve scope, so an anchor on the scanned module's own export needs no module name. The walk is deterministic and loader-free (it parses the mapped image directly, never a call to `GetProcAddress` and never a trigger of a `DllMain`) and fails closed at every step. A missing export directory, an absent or ordinal-only name, an out-of-image RVA, or an unloaded module all report `Failed` with no invented address. A *forwarded* export (one whose entry names another DLL's symbol as an ASCII string rather than code in this image) fails closed rather than a return of the address of a string. This is export ANCHORING (a read of the EAT to resolve an address). It is distinct from EAT HOOKING (a patch of the export table to redirect calls), which DetourModKit deliberately does not do.

`CallArgHome` is a reserved enumerator for a future prologue-dataflow backend (a map of a call argument to its current register or stack home). A declaration of it now keeps a registry table forward-compatible.

### Corroborating a critical target (`Quorum`)

For a target whose breakage is costly, a single signal can be too weak. One AOB or code constant can resolve to a coincidental match after a patch. A `Quorum` anchor votes across `M` independent sub-anchors and accepts only when at least `N` of them resolve *and agree* (N-of-M voting). A coincidental match therefore has to fool a whole cluster at once. Unlike a strict pair, the target still corroborates when a game patch breaks some of the signals, as long as `N` of the rest still agree. List the members in `quorum_members` (non-owning pointers into your own anchor storage, kept alive across the `resolve` call), set `quorum_threshold` to `N`, and pick the agreement policy:

```cpp
// Corroborate a struct stride read from three independent code sites; any two agreeing is enough,
// so the stride still resolves when a patch shifts one of the three call sites.
const an::Anchor stride_a = {
    .kind = an::AnchorKind::CodeOperand,
    .site = k_equip_stride_a,
    .operand_index = 2,
};
const an::Anchor stride_b = {
    .kind = an::AnchorKind::CodeOperand,
    .site = k_equip_stride_b,
    .operand_index = 2,
};
const an::Anchor stride_c = {
    .kind = an::AnchorKind::CodeOperand,
    .site = k_equip_stride_c,
    .operand_index = 2,
};
const an::Anchor *stride_votes[] = {&stride_a, &stride_b, &stride_c};
const an::Anchor stride = {
    .label = "equip_stride",
    .kind = an::AnchorKind::Quorum,
    .quorum_members = stride_votes,
    .quorum_threshold = 2, // 2-of-3; the default 0 means unanimous (all members)
    .quorum_match = an::QuorumMatch::ExactValue, // or WithinTolerance + quorum_tolerance
};
```

`quorum_members` are non-owning pointers into your own anchor storage, so keep the members alive across the `resolve` call. `quorum_threshold` is `N`. `0` (the default) means unanimous, so a two-member quorum with the default is the strict 2-of-2 corroboration. A quorum is corroboration, so an explicit `N` below 2 or above the member count is malformed. `QuorumMatch::ExactValue` (the default) requires identical values. `QuorumMatch::WithinTolerance` accepts a gap no larger than `quorum_tolerance` (a negative tolerance never accepts). A single qualifying cluster commits its smallest qualifying center, independent of declaration order. If two qualifying centers disagree, resolution returns `AnchorStatus::QuorumAmbiguous` instead of a choice by order. Fewer than `N` agreeing members and malformed declarations return `AnchorStatus::Failed`.

Independence is checked twice, because corroboration only means something when every vote is separate evidence. Before resolution, five patterns make the quorum `QuorumNotIndependent`:

- Reuse of one `Anchor`.
- A pair of two `Manual` literals.
- A shared candidate rung.
- Selection of two operands from one declared instruction.
- The same effective export spelled as both scoped and explicit.

This comparison uses evidence content rather than view storage, ignores cosmetic names and operand selectors, and compares ladder atoms as sets. After resolution, the winning physical sources are compared too. Overlapping byte-pattern spans, or a decoded instruction site that overlaps another winner's span, are one failure domain even when different patterns, bounded jumps, result markers, or walk-backs selected them. Exports are correlated by the entry they resolved through rather than by the name that asked for it. Two names that share an `AddressOfFunctions` slot, or that carry the same function RVA in one image, count once. That is what a declaration alone cannot decide, because which names alias is a property of the live export table. Equal resolved values alone are not dependency, so distinct instructions that reference the same target remain independent, and an export still corroborates against a signal read from somewhere else.

### Post-resolve validators

Any backend-resolved anchor (not `Manual` or `CallArgHome`) can carry an optional `validator`: a `bool(*)(std::int64_t value, const void* context) noexcept` predicate run on the resolved value immediately before it is accepted. A return of `false` fails the anchor closed (`Failed`, value reset to 0), identical to a backend miss, so the caller re-heals by a re-run of `resolve`. Use it to assert a domain invariant a generic backend cannot know: the target lies in an expected sub-range, a displacement points into `.rdata`, or the site begins with a plausible prologue (`scan::is_likely_function_prologue`). `validator_context` is an opaque pointer forwarded verbatim to the predicate (nullptr if unused). For a `Quorum`, the validator runs once on the corroborated value after the members vote.

Two opt-in policy flags harden this further (both default to preservation of the existing behaviour):

- `validate_manual = true` runs the `validator` on a `Manual` anchor too, instead of a take of the pinned literal unchecked, so you can assert a domain invariant on a hand-pinned constant.
- `require_validator = true` rejects a backend-resolvable anchor that carries no `validator` at all (status `Failed`). A function or global target with no domain check is treated as unverified. A `Quorum` is exempt, because its N-of-M corroboration already is the verification.

When a target can be expressed more than one way, prefer the most update-resilient backend: `ExportName` > `StringXref` > `VtableIdentity` > `RipGlobal` > `CodeOperand`. A `Quorum` votes over several of those to raise confidence further. `Manual` is the last resort.

RTTI pointer-field offset healing (`rtti::heal_landmark`) is intentionally **not** a registry kind. It needs a runtime struct base that is itself resolved from another anchor, so it is driven directly once that base is known (see [rtti-self-heal.md](../rtti/rtti-self-heal.md)).

## Declaring and resolving a table

```cpp
#include "DetourModKit/anchor.hpp"

namespace an = DetourModKit::anchor;
namespace sc = DetourModKit::scan;

// One declarative candidate ladder per cascade-backed anchor. scan::Candidate owns its name and compiled Pattern, so
// these are `const` (not constexpr) arrays; Pattern::literal keeps the signature a compile-time-checked value.
const sc::Candidate k_world_sys[] = {
    sc::Candidate::rip_relative("world-sys", sc::Pattern::literal("48 8B 0D ?? ?? ?? ??"), 3, 7),
};
const sc::Candidate k_equip_stride[] = {
    sc::Candidate::direct("equip-stride", sc::Pattern::literal("48 6B C0 ?? 48 03 ??")),
};

const an::Anchor k_anchors[] = {
    {
        .label = "audio_vtable",
        .kind = an::AnchorKind::VtableIdentity,
        .mangled = ".?AVGameAudioEffect@engine@@",
    },
    {
        .label = "world_system",
        .kind = an::AnchorKind::RipGlobal,
        .site = k_world_sys,
    },
    {
        .label = "equip_stride",
        .kind = an::AnchorKind::CodeOperand,
        .site = k_equip_stride,
        .operand_kind = sc::OperandKind::Immediate,
        .operand_index = 2,
    },
    {
        .label = "fallback_off",
        .kind = an::AnchorKind::Manual,
        .manual_value = 0x1C8,
    },
};

an::ResolvedAnchor report[std::size(k_anchors)];
const std::size_t n = an::resolve_all(k_anchors, report);
```

A `RipGlobal` anchor scans `Pages::Readable` by default, which reaches a `Direct` rung that resolves a plain global address in `.rdata` / `.data`. When every rung of a `RipGlobal` ladder anchors on an in-image instruction (a RIP-relative reference whose pattern is code), set `.pages = sc::Pages::Executable` on the anchor. A coincidental byte twin in a data page then cannot alias the site and demote a unique resolve to a fail-closed ambiguity. A manifest persists this non-default policy as `pages = executable`. An absent key remains `Readable` for compatibility. `CodeOperand` needs no such knob. `read_code_constant` scans code bytes and verifies that its final resolved site is execute-readable before it decodes.

For `CodeOperand`, `byte_width = 0` preserves the decoded value and 1 through 8 narrows a non-RIP constant to its low-order bytes before sign-extension. A value above 8 is malformed and fails before the scan. RIP-relative memory operands always resolve to their absolute target, so the width does not narrow that address.

A `Pages::Readable` scan follows the Readable authority rule of `scan::Pages` in [scan.hpp](../../../include/DetourModKit/scan.hpp). The anchor trust layer is stricter: `VtableIdentity`, `RipGlobal`, `CodeOperand`, and `StringXref` require their common scope to stay inside one reserved allocation regardless of page class. They re-check that boundary after validators and witness construction, because uniqueness depends on the whole searched range. Use a narrow module or allocation `Region`. Cross-module quorum evidence remains supported through explicit `ExportName::export_module` members. A refusal reaches an anchor caller as `AnchorStatus::Failed`, because `ResolvedAnchor` carries no error code.

`resolve_all` writes one `ResolvedAnchor` (`{label, kind, status, value, domain, witness}`) for each of the first `min(anchors.size(), out.size())` inputs and returns that count. `value` is meaningful only when `status == AnchorStatus::Resolved`. `domain` distinguishes a code site, data address, vtable address, and scalar so a mutation gate can reject an incompatible binding. `witness` is the semantic-site evidence a resolved entry carries beyond its value (see below). The `label` view borrows the source anchor's storage. The scope defaults to `Region::host()`. Pass an explicit `Region` (for example `Region::module_named("engine.dll")`) when the targets live in a separate module.

For startup tables whose anchors are independent, `resolve_all_parallel` resolves the same report through a fork-join worker pool:

```cpp
const std::size_t n = an::resolve_all_parallel(k_anchors, report, game_region, /*max_workers=*/4);
```

Each anchor still goes through the single-anchor `resolve` path, so backend failures, validators, quorum checks, and result ordering match `resolve_all`. The parallel resolver is opt-in, because validators can run concurrently. Use the serial `resolve_all` when a validator context is order-dependent or must be externally serialized.

## The drift report

The `ResolvedAnchor[]` array *is* the drift report. Walk it once at init to log what resolved, what failed, and what is pinned and therefore at risk:

```cpp
for (std::size_t i = 0; i < n; ++i)
{
    const auto &r = report[i];
    if (r.status != an::AnchorStatus::Resolved)
        log().warning("anchor {}: {}", r.label, an::anchor_status_to_string(r.status));
    else if (r.kind == an::AnchorKind::Manual)
        log().warning("anchor {}: pinned literal {:#x} (cannot self-heal)", r.label, r.value);
    else
        log().info("anchor {}: {:#x}", r.label, r.value);
}
```

Every backend already fails closed, so a missing constant surfaces as `AnchorStatus::Failed` (no value invented), and `Manual` anchors stand out as the ones a future patch can silently break.

`anchor::assess_quality(report)` rolls the same `ResolvedAnchor[]` into an `AnchorQuality` summary in one pass (no re-resolve): how many resolved, failed, are pinned `Manual` literals that cannot self-heal (`manual_at_risk`), or are corroborated quorums (the strongest evidence). It is a cheap, allocation-free way to gate "is this manifest healthy enough to run?" or to log a one-line robustness snapshot per build. The same summary is what `diagnostics::collect(drift_report, anchor_report)` folds into its `Snapshot.anchor_quality` field.

## Gating a feature on drift quality

Telemetry alone only describes health. `anchor::evaluate_gate` turns it into a decision. Startup can then safe-disable a feature when its anchors did not resolve well enough, instead of a patch of the game on addresses the manifest did not verify:

```cpp
// Resolve only the anchors this one feature depends on into its own report...
an::ResolvedAnchor report[std::size(camera_anchors)]{};
const std::size_t n = an::resolve_all(camera_anchors, report);

// ...then gate it. The default policy fails closed: every resolvable anchor must heal, zero failures.
switch (an::evaluate_gate(std::span{report, n}))
{
case an::GateVerdict::Pass:
    enable_camera_tweak();
    break;
case an::GateVerdict::Degraded:
    log().warning("camera tweak: pinned offset at risk");
    enable_camera_tweak();
    break;
case an::GateVerdict::Fail:
    log().error("camera tweak disabled: signatures drifted");
    break;
}
```

Because the gate reads a report (or a sub-span of one), feature-granular gating is only a matter of which anchors you resolve into which report. One primitive serves both a whole-manifest health check and a per-feature kill switch.

In a `GatePolicy`, `min_resolved_ratio` is the fraction of *resolvable* anchors that must resolve. The unsupported `CallArgHome` kind is not in the denominator, so a forward-compatible declaration never lowers the score. `max_failed` is a hard cap on `Failed` + `QuorumAmbiguous` + `QuorumNotIndependent`. `manual_at_risk_degrades` decides whether any `Manual` entry, in any status, downgrades `Pass` to `Degraded`. A cosmetic overlay can afford a lower ratio than a frame-time camera patch that writes a live pointer, so hold one policy per feature. An empty report or a report with only unsupported anchors has nothing assessable and returns `Degraded`, never a false `Pass`.

## Anchor fingerprints

`anchor::anchor_fingerprint(anchor)` hashes only an anchor's *resolution evidence*: its `AnchorKind` plus the inputs that backend uses.

- `VtableIdentity`: the mangled name.
- `RipGlobal` / `CodeOperand`: the compiled-Pattern bytes plus wildcard mask and decode parameters, and the non-default `RipGlobal` page class.
- `StringXref`: the literal and shape flags.
- `ExportName`: the module and export name.
- `Manual`: the literal.

It deliberately excludes the resolved address. `Pages::Readable` is omitted from a `RipGlobal` fingerprint to preserve existing baselines. `Pages::Executable` is folded because it changes the resolution policy. A candidate's cosmetic `name` and the anchor's `label` are excluded too, because neither changes which address resolves.

`scan::Pattern` keeps no source AOB text, so a byte rung contributes its compiled byte and wildcard-mask spans, result offset, and bounded-jump gaps. The rung also contributes its mode and its walk-back or RIP decode parameters. The fingerprint therefore needs no re-parse of AOB text.

The point is a diffable identity that is stable when only the address drifts. Persist a fingerprint next to each resolved value, and on the next game version a manifest diff can tell two cases apart:

- **Same evidence, new address.** The fingerprint matches but the resolved value moved. This is expected drift the anchor self-healed, nothing to do.
- **New evidence path.** The fingerprint changed, so the signature itself was rewritten (a new pattern, a renamed type, a different string). This is the entry to re-review.

A `Quorum` combines all member fingerprints order-independently (a reorder of `quorum_members` does not change the result) and folds in the effective vote threshold, agreement mode, and tolerance. A null member contributes a fixed sentinel. `CallArgHome` has no resolvable evidence yet, so its fingerprint reflects only the kind. The result is a 64-bit FNV-1a hash, stable across runs and builds on a given platform, a diff key rather than a cryptographic digest. The function reads only the anchor's declarative views, resolves nothing, and allocates nothing.

### Trust fingerprints and live-image identity

`anchor::anchor_trust_fingerprint(anchor, scope_identity)` is the scope-bound counterpart to the definition fingerprint. The definition fingerprint is stable across every load of the same declaration. The trust fingerprint additionally folds a `scan::ImageIdentity` (`scan::image_identity(range)`: the module's PE timestamp, `SizeOfImage`, and section-table digest, none of which move under ASLR). A remap with a different build identity changes the trust key even though the definition is unchanged, and ASLR alone never does. For an `ExportName` the declared `export_module` is replaced by the effective `scope_identity`, so an empty (scope-inherited) module and an explicit spelling of the same effective module fold to one trust key. Persist it beside the definition fingerprint to tell a signature rewrite (definition changed) apart from an image build change under a stable declaration (only the trust key changed).

A resolved report also carries a `ResolvedWitness` in `ResolvedAnchor::witness`, populated only on `AnchorStatus::Resolved`:

- `image` - the `scan::ImageIdentity` of the module that owns the resolved address. Absent for a `Scalar` (a code operand or `Manual` literal, which is a constant rather than a location), an unresolved entry, or a non-module synthetic address. Resolution captures each module-backed evidence owner before its backend walk and captures the address-domain value owner before validation. Every key and its mapping class are re-checked after commit and witness construction. A scope-backed member also propagates its single-allocation obligation through a `Quorum`. The witness copies the accepted value-owner key rather than a resample of it. Four conditions return `AnchorStatus::Failed` with value 0 and no witness: an unreadable module identity, an image or synthetic class transition, an allocation split, or a flagged same-base replacement. The last is a replacement whose PE layout identity differs from the captured one, found by a validator or between two members of a `Quorum`. Two limits are worth a plain statement. The replacement check is layout-identity equality, so a replacement that reproduces the captured timestamp, `SizeOfImage`, and section-table digest is indistinguishable from the original here. Use `evidence` below for content, which is what an in-place patch moves. And the comparison is between snapshots taken at the recorded points (before the backend walk, before validation, after commit, after witness construction), not a continuous watch. It proves the identity held across those points, not that nothing happened between them.
- `source` - the normalized `PhysicalSource` that produced the value (`ByteSignature`, `StringLiteral`, `TypeIdentity`, `ExportTable`, `CodeOperand`, `ManualPin`, or `Corroborated`).
- `operand_kind` - for a `CodeOperand`, which operand field was decoded.
- `completeness` - `Complete` on a resolved entry (a truncated or unauthoritative sweep fails closed to `Failed`, so a trusted value is never resolved over a partial view).
- `evidence` - the literal bytes of the span the winning byte-pattern rung matched, captured during that match. Present only when a `RipGlobal` anchor wins on a `Direct` or RIP-relative rung, the one path that returns the span it matched. Evidence is absent when a rung wins through a structure instead (RTTI vtable, string xref), and absent for the `VtableIdentity`, `StringXref`, `ExportName`, `Manual`, and `Quorum` kinds. It is also absent for `CodeOperand`, which locates through a byte pattern but returns a decoded `Scalar` rather than the site. `scan::WinningEvidence` in `scan.hpp` owns the content-versus-layout contract and the same-traversal capture guarantee, and the [AOB signatures guide](../../misc/aob-signatures.md) covers the immutable sweep snapshot behind a RIP-relative winner.

## Per-game scan profile

A `ScanProfile` (in `anchor.hpp`) is a plain value with per-game scan tuning for every anchor in a profiled resolve, and no hidden global state. No `Anchor` field overrides the profile's deny-list or candidate order.

- `default_broad_string_xref` turns on the broad string-xref sweep for every `StringXref` anchor, even one with `xref_broad_match = false`. It never turns the sweep off. `anchor::apply_profile` folds this into a `scan::StringRefQuery`.
- `candidate_order` is a `scan::CandidateOrder` that reuses the scan module's ordering policy. `UniqueFirst` promotes the unique-only text tiers (RTTI and string xref) and anchored byte patterns ahead of looser byte fallbacks. `anchor::resolve_with_profile` applies it to `RipGlobal` (through the request's `order` field) and to `CodeOperand` (by a build of a local reordered ladder via `scan::order_candidates`), so the caller's static candidate table is never mutated.
- `deny_backend` is a per-`AnchorKind` deny-list.

Resolve one anchor with `anchor::resolve_with_profile`, or a table with `anchor::resolve_all_with_profile`. Use `resolve_all_with_profile_parallel` when the profile-aware table is safe to dispatch concurrently. A denied backend fails *closed* (status `Failed`, value 0), never a silent replacement by a different, possibly-wrong backend. Quorum members use the same profile, so a denied member fails and casts no vote. Candidate order and the broad string-xref sweep default also apply to each member. The plain `resolve` / `resolve_all` are equivalent to a resolve with an empty profile.

## Re-heal on a validation miss

Resolution is idempotent and side-effect-free, so the registry keeps no hidden state. The resolved value lives in the `ResolvedAnchor` you hold. When a later sanity check shows a cached value has gone stale, re-run `resolve` on that one anchor:

```cpp
if (!still_valid(cached.value))
    cached = an::resolve(k_anchors[idx]); // fresh resolve; fail closed on miss
```

## Scope

Like the underlying resolvers, the registry defaults to the host EXE and accepts an explicit `Region`. Scope is load-bearing for correctness, not only ergonomics. The same vtable name or instruction shape can exist in several loaded modules. Pass the game module's range when the target lives in a separate DLL.
