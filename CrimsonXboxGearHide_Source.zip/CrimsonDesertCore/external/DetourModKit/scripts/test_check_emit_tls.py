#!/usr/bin/env python3
"""Regression tests for the callback-path symbol filters."""

import importlib.util
import io
import subprocess
import sys
from contextlib import redirect_stderr
from pathlib import Path


SCRIPT = Path(__file__).resolve().parent / "check_emit_tls.py"
SPEC = importlib.util.spec_from_file_location("check_emit_tls", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def expect_offenders(output: str, expected: int) -> None:
    offenders = MODULE.find_offenders(output)
    if len(offenders) != expected:
        raise AssertionError(f"expected {expected} offender(s), got {offenders}")


def mid_adapter_symbols(owner: str, indices=None) -> str:
    return "\n".join(
        f"lib.a:{owner}:0000 T void DetourModKit::detail::mid_adapter<{index}ull>(safetyhook::Context64&)"
        for index in (range(MODULE.MID_ADAPTER_COUNT) if indices is None else indices)
    )


def test_template_control_symbol_is_rejected() -> None:
    expect_offenders(
        "lib.a:diagnostics.cpp.obj:0000 D __emutls_v._ZN12DetourModKit15EventDispatcherIiE5depthE\n",
        1,
    )


def test_out_of_line_helper_import_is_rejected() -> None:
    expect_offenders("lib.a:event_dispatcher.cpp.obj:         U __emutls_get_address\n", 1)


def test_input_delivery_tls_import_is_rejected() -> None:
    expect_offenders("lib.a:input_delivery_scope.cpp.obj:     U __emutls_get_address\n", 1)


def test_xinput_callback_tls_imports_are_rejected() -> None:
    output = "\n".join(
        f"lib.a:{name}.cpp.{suffix}: U __emutls_get_address"
        for name in ("input_intercept", "xinput_route_probe", "xinput_raw_scope")
        for suffix in ("obj", "o")
    )
    expect_offenders(output, 6)


def test_xinput_callback_tls_control_symbols_are_rejected() -> None:
    output = "\n".join(
        f"lib.a:{name}.cpp.obj:0000 D __emutls_{kind}.depth"
        for name in ("input_intercept", "xinput_route_probe", "xinput_raw_scope")
        for kind in ("v", "t")
    )
    expect_offenders(output, 6)


def test_backend_retention_tls_import_is_rejected() -> None:
    expect_offenders("libsafetyhook.a:inline_hook.cpp.obj:    U __emutls_get_address\n", 1)


def test_backend_trap_transaction_tls_is_rejected() -> None:
    expect_offenders(
        "libsafetyhook.a:os.windows.cpp.obj:    U __emutls_get_address\n"
        "libsafetyhook.a:os.windows.cpp.obj:0000 D __emutls_v._ZN10safetyhook31g_instruction_cache_flush_traceE\n",
        2,
    )


def test_unrelated_tls_is_out_of_scope() -> None:
    expect_offenders("lib.a:worker.cpp.obj:0000 D __emutls_v._ZN6worker5depthE\n", 0)


def test_unrelated_import_is_out_of_scope() -> None:
    expect_offenders("lib.a:worker.cpp.obj:         U __emutls_get_address\n", 0)


def test_input_gate_pthread_identity_is_rejected() -> None:
    expect_offenders("lib.a:input.cpp.obj:                 U pthread_self\n", 1)


def test_input_callback_pthread_identity_is_rejected() -> None:
    output = "\n".join(
        f"lib.a:{name}.cpp.obj: U {prefix}pthread_self"
        for name in ("input_delivery_scope", "input_intercept", "xinput_route_probe", "xinput_raw_scope")
        for prefix in ("", "__imp_")
    )
    expect_offenders(output, 8)


def test_unrelated_pthread_identity_is_out_of_scope() -> None:
    expect_offenders("lib.a:worker.cpp.obj:                 U pthread_self\n", 0)


def test_mid_adapter_accessor_indirection_is_rejected() -> None:
    output = mid_adapter_symbols("hook.cpp.obj")
    output += "\nlib.a:hook.cpp.obj: U DetourModKit::detail::mid_adapter_slots()\n"
    offenders = MODULE.find_mid_adapter_indirection(output)
    if offenders != ["lib.a:hook.cpp.obj: U DetourModKit::detail::mid_adapter_slots()"]:
        raise AssertionError(f"mid-adapter accessor call was not rejected: {offenders}")


def test_mid_adapter_owner_with_direct_access_is_accepted() -> None:
    output = mid_adapter_symbols("mid_hook_adapter.cpp.obj")
    offenders = MODULE.find_mid_adapter_indirection(output)
    if offenders:
        raise AssertionError(f"direct mid-adapter access was rejected: {offenders}")


def test_missing_adapter_definitions_are_rejected() -> None:
    output = "lib.a:hook.cpp.obj: U DetourModKit::detail::mid_adapter_slots()\n"
    offenders = MODULE.find_mid_adapter_indirection(output)
    if len(offenders) != 1 or "no mid-hook adapter definitions" not in offenders[0]:
        raise AssertionError(f"zero adapter definitions were not rejected: {offenders}")


def test_wrong_adapter_definition_count_is_rejected() -> None:
    short_count = MODULE.MID_ADAPTER_COUNT - 1
    output = mid_adapter_symbols("mid_hook_adapter.cpp.obj", range(short_count))
    offenders = MODULE.find_mid_adapter_indirection(output)
    expected = [f"mid-hook adapter definition count is {short_count}, expected {MODULE.MID_ADAPTER_COUNT}"]
    if offenders != expected:
        raise AssertionError(f"short adapter table was not rejected: {offenders}")


def test_split_adapter_ownership_is_rejected() -> None:
    half = MODULE.MID_ADAPTER_COUNT // 2
    output = mid_adapter_symbols("hook.cpp.obj", range(half))
    output += "\n" + mid_adapter_symbols("mid_hook_adapter.cpp.obj", range(half, MODULE.MID_ADAPTER_COUNT))
    offenders = MODULE.find_mid_adapter_indirection(output)
    if offenders != ["mid-hook adapters span 2 objects, expected one"]:
        raise AssertionError(f"split adapter ownership was not rejected: {offenders}")


def test_main_scans_every_archive() -> None:
    calls = []
    original_argv = sys.argv
    original_run = MODULE.subprocess.run
    original_which = MODULE.shutil.which

    def fake_run(args, **_kwargs):
        archive = args[-1]
        calls.append(archive)
        output = ""
        if archive == "backend.a":
            output = "backend.a:inline_hook.cpp.obj: U __emutls_get_address\n"
        return subprocess.CompletedProcess(args, 0, output, "")

    try:
        sys.argv = ["check_emit_tls.py", "library.a", "backend.a", "--nm", "fake-nm"]
        MODULE.shutil.which = lambda _tool: "fake-nm"
        MODULE.subprocess.run = fake_run
        errors = io.StringIO()
        with redirect_stderr(errors):
            code = MODULE.main()
    finally:
        sys.argv = original_argv
        MODULE.subprocess.run = original_run
        MODULE.shutil.which = original_which

    if code != 1 or calls != ["library.a", "backend.a"] or "inline_hook.cpp.obj" not in errors.getvalue():
        raise AssertionError(f"second archive was not enforced: code={code}, calls={calls}, errors={errors.getvalue()}")


def main() -> int:
    tests = [value for name, value in sorted(globals().items()) if name.startswith("test_") and callable(value)]
    for test in tests:
        test()
    print(f"emit-TLS checker self-test passed ({len(tests)} cases).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
