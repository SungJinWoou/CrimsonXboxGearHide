/**
 * @file drift_manifest.cpp
 * @brief Durable serialization of self-heal drift reports.
 */

#include "DetourModKit/detail/drift_manifest.hpp"

#include "internal/utf8_conversion.hpp"

#include <charconv>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <string>

namespace DetourModKit
{
    namespace rtti
    {
        namespace
        {
            constexpr std::string_view MANIFEST_HEADER = "# DetourModKit drift manifest v1";
            constexpr char FIELD_SEP = '\t';

            // Stable round-trip tokens for the Rtti-block heal ErrorCodes, deliberately distinct from the verbose
            // human-readable Error::message() text (which is for logs): a manifest must parse back even if the log
            // wording is reworded, so the token strings are frozen independently of the enumerator spellings.
            // A drift entry's error is meaningful only when ok == false, and heal_report only ever writes Ok (the
            // healed default) or one of the three Rtti-block heal codes. Give each a distinct token (including Ok)
            // so the ErrorCode round-trips exactly rather than a successful entry's Ok collapsing to a failure token.
            // The default arm still maps any unexpected code to BadDescriptor so a malformed producer never emits an
            // untokenizable field.
            [[nodiscard]] std::string_view heal_error_token(ErrorCode error) noexcept
            {
                switch (error)
                {
                case ErrorCode::Ok:
                    return "Ok";
                case ErrorCode::BadDescriptor:
                    return "BadDescriptor";
                case ErrorCode::HealNoMatch:
                    return "NoMatch";
                case ErrorCode::HealAmbiguous:
                    return "Ambiguous";
                default:
                    return "BadDescriptor";
                }
            }

            [[nodiscard]] bool parse_heal_error(std::string_view token, ErrorCode &out) noexcept
            {
                if (token == "Ok")
                {
                    out = ErrorCode::Ok;
                    return true;
                }
                if (token == "BadDescriptor")
                {
                    out = ErrorCode::BadDescriptor;
                    return true;
                }
                if (token == "NoMatch")
                {
                    out = ErrorCode::HealNoMatch;
                    return true;
                }
                if (token == "Ambiguous")
                {
                    out = ErrorCode::HealAmbiguous;
                    return true;
                }
                return false;
            }

            /**
             * @brief Appends a name without exposing record delimiters to the manifest grammar.
             * @param out The manifest buffer to append to.
             * @param name The unescaped name.
             */
            void append_escaped_name(std::string &out, std::string_view name)
            {
                for (const char c : name)
                {
                    switch (c)
                    {
                    case '\t':
                        out.append("\\t");
                        break;
                    case '\n':
                        out.append("\\n");
                        break;
                    case '\r':
                        out.append("\\r");
                        break;
                    case '\\':
                        out.append("\\\\");
                        break;
                    default:
                        out.push_back(c);
                        break;
                    }
                }
            }

            /**
             * @brief Decodes an escaped name field.
             * @param field The encoded field.
             * @param out Receives the decoded name.
             * @return False for a truncated or unknown escape.
             */
            [[nodiscard]] bool unescape_name(std::string_view field, std::string &out)
            {
                out.clear();
                out.reserve(field.size());
                for (std::size_t i = 0; i < field.size(); ++i)
                {
                    const char c = field[i];
                    if (c != '\\')
                    {
                        out.push_back(c);
                        continue;
                    }
                    if (++i >= field.size())
                    {
                        return false;
                    }
                    switch (field[i])
                    {
                    case 't':
                        out.push_back('\t');
                        break;
                    case 'n':
                        out.push_back('\n');
                        break;
                    case 'r':
                        out.push_back('\r');
                        break;
                    case '\\':
                        out.push_back('\\');
                        break;
                    default:
                        return false;
                    }
                }
                return true;
            }

            // Parses a decimal (possibly negative) offset that must span the whole field.
            [[nodiscard]] bool parse_offset(std::string_view field, std::ptrdiff_t &out) noexcept
            {
                if (field.empty())
                {
                    return false;
                }
                const char *const begin = field.data();
                const char *const end = field.data() + field.size();
                const auto result = std::from_chars(begin, end, out);
                return result.ec == std::errc{} && result.ptr == end;
            }

            // Fail-closed manifest error: a code from the unified ErrorCategory::Manifest block, tagged with the
            // module label. Error construction never allocates, so this is safe on any path.
            [[nodiscard]] std::unexpected<Error> manifest_error(ErrorCode code) noexcept
            {
                return std::unexpected(Error{code, "rtti::drift_manifest"});
            }
        } // anonymous namespace

        std::string serialize_drift_report(std::span<const DriftEntry> entries)
        {
            std::string out;
            out.append(MANIFEST_HEADER.data(), MANIFEST_HEADER.size());
            out.push_back('\n');
            for (const DriftEntry &entry : entries)
            {
                append_escaped_name(out, entry.name);
                out.push_back(FIELD_SEP);
                out.append(std::to_string(entry.nominal_offset));
                out.push_back(FIELD_SEP);
                out.append(std::to_string(entry.healed_offset));
                out.push_back(FIELD_SEP);
                out.append(std::to_string(entry.delta));
                out.push_back(FIELD_SEP);
                out.push_back(entry.ok ? '1' : '0');
                out.push_back(FIELD_SEP);
                const std::string_view token = heal_error_token(entry.error);
                out.append(token.data(), token.size());
                out.push_back('\n');
            }
            return out;
        }

        Result<std::vector<DriftRecord>> parse_drift_report(std::string_view text)
        {
            std::vector<DriftRecord> records;
            bool header_seen = false;
            std::size_t pos = 0;
            while (pos <= text.size())
            {
                const std::size_t newline = text.find('\n', pos);
                std::string_view line =
                    (newline == std::string_view::npos) ? text.substr(pos) : text.substr(pos, newline - pos);
                pos = (newline == std::string_view::npos) ? text.size() + 1 : newline + 1;

                // Strip a trailing CR (CRLF input) and skip blank lines.
                if (!line.empty() && line.back() == '\r')
                {
                    line.remove_suffix(1);
                }
                if (line.empty())
                {
                    continue;
                }

                if (!header_seen)
                {
                    if (line != MANIFEST_HEADER)
                    {
                        return manifest_error(ErrorCode::MissingHeader);
                    }
                    header_seen = true;
                    continue;
                }

                // Split into exactly six tab-separated fields; any other count is malformed.
                std::string_view fields[6];
                std::size_t field_count = 0;
                std::size_t field_pos = 0;
                bool too_many = false;
                while (true)
                {
                    const std::size_t sep = line.find(FIELD_SEP, field_pos);
                    const std::string_view field = (sep == std::string_view::npos)
                                                       ? line.substr(field_pos)
                                                       : line.substr(field_pos, sep - field_pos);
                    if (field_count >= 6)
                    {
                        too_many = true;
                        break;
                    }
                    fields[field_count++] = field;
                    if (sep == std::string_view::npos)
                    {
                        break;
                    }
                    field_pos = sep + 1;
                }
                if (too_many || field_count != 6)
                {
                    return manifest_error(ErrorCode::MalformedLine);
                }

                DriftRecord record;
                if (!unescape_name(fields[0], record.name))
                {
                    return manifest_error(ErrorCode::MalformedLine);
                }
                if (!parse_offset(fields[1], record.nominal_offset) || !parse_offset(fields[2], record.healed_offset) ||
                    !parse_offset(fields[3], record.delta))
                {
                    return manifest_error(ErrorCode::MalformedLine);
                }
                if (fields[4] == "1")
                {
                    record.ok = true;
                }
                else if (fields[4] == "0")
                {
                    record.ok = false;
                }
                else
                {
                    return manifest_error(ErrorCode::MalformedLine);
                }
                if (!parse_heal_error(fields[5], record.error))
                {
                    return manifest_error(ErrorCode::MalformedLine);
                }
                records.push_back(std::move(record));
            }

            if (!header_seen)
            {
                return manifest_error(ErrorCode::MissingHeader);
            }
            return records;
        }

        Result<void> write_drift_report_to_file(const std::string &path, std::span<const DriftEntry> entries)
        {
            // A narrow stream open decodes through the ANSI code page on both toolchains, so the UTF-8 path opens in
            // its wide form. Ill-formed input fails before the open truncates any file.
            const std::wstring wide_path = DetourModKit::detail::widen_utf8(path);
            if (wide_path.empty())
            {
                return manifest_error(ErrorCode::FileOpenFailed);
            }
            // Binary mode so the '\n' line endings written here are not translated to
            // CRLF; the parser tolerates either, but a stable on-disk form is clearer.
            std::ofstream file(std::filesystem::path(wide_path), std::ios::binary | std::ios::trunc);
            if (!file)
            {
                return manifest_error(ErrorCode::FileOpenFailed);
            }
            const std::string text = serialize_drift_report(entries);
            file.write(text.data(), static_cast<std::streamsize>(text.size()));
            // Close explicitly instead of leaning on the destructor. The final buffered write and the OS-level flush
            // both happen inside close(), so a failure that only surfaces there (disk full on the last block, a
            // delayed network-filesystem error) sets failbit here where it can be reported; the destructor would
            // swallow it. flush() alone forces the buffer out but cannot observe a close-time error.
            file.flush();
            file.close();
            // A failbit/badbit set after the write, flush, or close means the stream opened but the bytes did not all
            // land (disk full, an I/O error). Report that distinctly from the open failure above so a caller can tell
            // a truncated manifest from one that was never created.
            if (!file)
            {
                return manifest_error(ErrorCode::FileWriteFailed);
            }
            return {};
        }

        Result<std::vector<DriftRecord>> read_drift_report_from_file(const std::string &path)
        {
            const std::wstring wide_path = DetourModKit::detail::widen_utf8(path);
            if (wide_path.empty())
            {
                return manifest_error(ErrorCode::FileOpenFailed);
            }
            std::ifstream file(std::filesystem::path(wide_path), std::ios::binary);
            if (!file)
            {
                // An open failure (missing file, lock, permission, or a directory) is distinct from a
                // present-but-corrupt manifest: the latter flows through parse_drift_report and reports MissingHeader /
                // MalformedLine.
                return manifest_error(ErrorCode::FileOpenFailed);
            }
            const std::string text((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
            return parse_drift_report(text);
        }
    } // namespace rtti
} // namespace DetourModKit
