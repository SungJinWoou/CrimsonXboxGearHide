/**
 * @file hook.cpp
 * @brief This TU implements hook lifecycle: install verbs, RAII handle teardown, and the VMT surface.
 */

#include "DetourModKit/hook.hpp"

#include "internal/hook_backend.hpp"
#include "internal/hook_backend_visit.hpp"
#include "internal/hook_coordinator.hpp"
#include "internal/hook_emission.hpp"
#include "internal/hook_fault_boundary.hpp"
#include "internal/hook_ledger.hpp"
#include "internal/hook_patch_witness.hpp"
#include "internal/hook_publication.hpp"
#include "internal/lifecycle_context.hpp"

#include "internal/drain_backoff.hpp"
#include "internal/memory_guarded.hpp"
#include "internal/mid_hook_adapter.hpp"
#include "internal/scan_pages.hpp"

#include "DetourModKit/diagnostics.hpp"
#include "DetourModKit/format.hpp"
#include "DetourModKit/logger.hpp"

#include "platform.hpp"
#include "x86_decode.hpp"

#include <windows.h>

#include <intrin.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <expected>
#include <format>
#include <functional>
#include <limits>
#include <memory>
#include <mutex>
#include <new>
#include <optional>
#include <shared_mutex>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

namespace DetourModKit::detail
{
    namespace
    {
        /// The sentence that names the first refusal of an idle proof, or an empty sentence for a clean proof.
        struct IdleRefusalSentence
        {
            std::array<char, 96> text{};
            std::size_t size{0};

            [[nodiscard]] std::string_view view() const noexcept { return {text.data(), size}; }
        };

        /// Names the thread and the check of @p refusal. A teardown warning appends the sentence after its reason.
        [[nodiscard]] IdleRefusalSentence describe_idle_refusal(const safetyhook::IdleRefusal &refusal) noexcept
        {
            IdleRefusalSentence sentence{};
            const auto write = [&sentence, &refusal](std::format_string<std::uint32_t> format) noexcept
            {
                try
                {
                    const auto written = std::format_to_n(
                        sentence.text.data(),
                        static_cast<std::ptrdiff_t>(sentence.text.size()),
                        format,
                        std::uint32_t{refusal.thread_id}
                    );
                    sentence.size = std::min(static_cast<std::size_t>(written.size), sentence.text.size());
                }
                catch (...)
                {
                    sentence.size = 0;
                }
            };
            switch (refusal.check)
            {
            case safetyhook::IdleRefusalCheck::None:
                break;
            case safetyhook::IdleRefusalCheck::InstructionPointerInRange:
                write(" Thread {} runs inside the retired code.");
                break;
            case safetyhook::IdleRefusalCheck::ReturnSiteOnStack:
                write(" Thread {} can still return into the retired code.");
                break;
            case safetyhook::IdleRefusalCheck::SuspensionFailed:
                write(" Thread {} did not suspend.");
                break;
            case safetyhook::IdleRefusalCheck::ContextFailed:
                write(" The context of thread {} is not readable.");
                break;
            case safetyhook::IdleRefusalCheck::ThreadWalkFailed:
                write(" The thread walk failed.");
                break;
            case safetyhook::IdleRefusalCheck::ThreadLimit:
                write(" The process has more threads than one idle pass holds.");
                break;
            case safetyhook::IdleRefusalCheck::CoordinatorUnavailable:
                write(" The process coordinator was unavailable.");
                break;
            }
            return sentence;
        }
    } // namespace

#if defined(DMK_ENABLE_TEST_SEAMS)
    namespace
    {
        std::atomic<std::uint64_t> s_hook_impl_destructions{0};
    } // namespace

    std::atomic<std::size_t> g_backend_toggle_exception_catches{0};

    std::uint64_t hook_impl_destruction_count_for_test() noexcept
    {
        return s_hook_impl_destructions.load(std::memory_order_relaxed);
    }

    void note_hook_impl_destruction_for_test() noexcept
    {
        s_hook_impl_destructions.fetch_add(1, std::memory_order_relaxed);
    }

    // The test-only acquire_hook_self_ref() override lets the suite drive the otherwise-unreachable acquire failure
    // branch. The override must SetLastError before a nullptr return to satisfy error.hpp's `detail = GetLastError()`
    // contract.
    HMODULE (*g_hook_module_ref_override)() noexcept = nullptr;

    // Overrides the byte witness Hook::enable() takes after the backend reports a successful patch. The suite can then
    // drive the negative branch a real backend does not produce on demand.
    bool (*g_hook_enable_witness_override)(bool) noexcept = nullptr;
    // Runs after a managed backend disable returns or throws and before DMK witnesses its target bytes.
    void (*g_hook_backend_disable_probe)() noexcept = nullptr;
    // Overrides whether ~Hook attempts backend disable. A false return or exception models a pre-mutation failure.
    // It leaves the target patched. Post-process after a completed disable makes the pin unobservable.
    bool (*g_hook_teardown_restore_override)() = nullptr;
    // Fires at each inline/mid publication step after that step's state is visible. It is not noexcept on purpose.
    // A probe exception exercises the same rollback as a real bad_alloc.
    void (*g_hook_publish_probe)(HookPublishStep) = nullptr;
    // HookTogglePublicationOrder.* owns this proof seam.
    void (*g_hook_toggle_publication_probe)(bool, bool, bool, bool) noexcept = nullptr;
    // Fires at the first operation boundary after one mutation entry passes its loader-lock veto.
    void (*g_hook_post_loader_veto_probe)(HookLoaderEntry) noexcept = nullptr;
    // Withholds the position claim from inline_at and mid_at, so every install is fresh and every new cell is
    // unclaimable. The residue budget proofs need positions that no successor takes.
    std::atomic<bool> g_hook_position_claims_refused_for_test{false};
    // This probe fires after the vtable pre-count and before the guarded snapshot capture.
    void (*g_vmt_before_capture_probe)() noexcept = nullptr;
    // This probe fires after the captured slot count becomes fixed and before the backend sizes its clone.
    void (*g_vmt_before_backend_clone_probe)() noexcept = nullptr;
    // This probe fires after VMT validation and before the guarded atomic publication attempt.
    void (*g_vmt_before_publish_probe)(void *) noexcept = nullptr;
    // This probe fires after the VMT object gate release and before the leak warning reaches the logger.
    void (*g_vmt_teardown_warning_probe)() noexcept = nullptr;

    // Arms the backend's post-commit transaction seam for one target, or disarms it with nullptr. The backend can
    // return an error over a fully committed patch. enable() and disable() reconcile that exact state. This translation
    // unit forwards the seam because only it names the backend.
    void set_backend_reprotect_failure_target(void *target) noexcept
    {
        safetyhook::g_trap_restore_failure_override.store(
            static_cast<std::uint8_t *>(target),
            std::memory_order_release
        );
    }

    // Arms a backend bad_alloc after transaction setup but before its mutation callback, or immediately after that
    // callback. trap_threads still restores protections and removes its trap before it rethrows into DMK's boundary.
    void set_backend_toggle_exception_for_test(void *target, bool after_mutation) noexcept
    {
        if (target == nullptr)
        {
            safetyhook::g_trap_exception_stage_override.store(
                safetyhook::TrapExceptionStage::NONE,
                std::memory_order_release
            );
            safetyhook::g_trap_exception_target_override.store(nullptr, std::memory_order_relaxed);
            return;
        }

        g_backend_toggle_exception_catches.store(0, std::memory_order_relaxed);
        safetyhook::g_trap_exception_target_override.store(
            static_cast<std::uint8_t *>(target),
            std::memory_order_relaxed
        );
        safetyhook::g_trap_exception_stage_override.store(
            after_mutation ? safetyhook::TrapExceptionStage::AFTER_MUTATION
                           : safetyhook::TrapExceptionStage::BEFORE_MUTATION,
            std::memory_order_release
        );
    }

    /// Reports how many managed backend exceptions the current test arm reached and contained.
    std::size_t backend_toggle_exception_catches_for_test() noexcept
    {
        return g_backend_toggle_exception_catches.load(std::memory_order_relaxed);
    }

    void set_backend_trap_transaction_hold_for_test(bool hold) noexcept
    {
        if (hold)
        {
            safetyhook::g_trap_transaction_reached.store(false, std::memory_order_relaxed);
        }
        safetyhook::g_trap_transaction_hold.store(hold, std::memory_order_release);
    }

    bool backend_trap_transaction_reached_for_test() noexcept
    {
        return safetyhook::g_trap_transaction_reached.load(std::memory_order_acquire);
    }

    std::size_t backend_trap_protect_calls_for_test() noexcept
    {
        return safetyhook::g_trap_protect_calls.load(std::memory_order_relaxed);
    }

    std::size_t backend_idle_pass_calls_for_test() noexcept
    {
        return safetyhook::g_idle_pass_calls.load(std::memory_order_relaxed);
    }

    std::size_t backend_idle_snapshot_walks_for_test() noexcept
    {
        return safetyhook::g_idle_pass_snapshot_walks.load(std::memory_order_relaxed);
    }

    void fail_backend_next_thread_lookup_for_test(bool fail) noexcept
    {
        safetyhook::g_next_thread_lookup_failure.store(fail);
    }

    bool backend_idle_pass_for_test(void *begin, void *end) noexcept
    {
        const std::array<safetyhook::AddressRange, 1> ranges{{{
            static_cast<std::uint8_t *>(begin),
            static_cast<std::uint8_t *>(end),
        }}};
        try
        {
            const std::expected<bool, safetyhook::OsError> idle = safetyhook::threads_idle_outside(ranges, {});
            return idle.has_value() && *idle;
        }
        catch (...)
        {
            return false;
        }
    }

    void set_backend_gateway_park_for_test(bool park) noexcept
    {
        safetyhook::set_route_park_for_test(
            park ? safetyhook::RouteParkStage::AT_ENTRY : safetyhook::RouteParkStage::NONE
        );
    }

    bool backend_gateway_park_reached_for_test() noexcept
    {
        return safetyhook::route_park_reached_for_test();
    }

    BackendIdleRefusal
    backend_idle_refusal_for_test(void *begin, void *end, const void *site_base, std::uint8_t site_offset) noexcept
    {
        const std::array<safetyhook::AddressRange, 1> ranges{{{
            static_cast<std::uint8_t *>(begin),
            static_cast<std::uint8_t *>(end),
        }}};
        safetyhook::ReturnSites sites{};
        sites.code = static_cast<const std::uint8_t *>(site_base);
        sites.offsets[0] = site_offset;
        sites.count = site_base != nullptr ? 1 : 0;
        const std::array<const safetyhook::ReturnSites *, 1> lists{&sites};
        BackendIdleRefusal result{};
        safetyhook::IdleRefusal refusal{};
        try
        {
            const std::expected<bool, safetyhook::OsError> idle =
                safetyhook::threads_idle_outside(ranges, lists, &refusal);
            result.idle = idle.has_value() && *idle;
        }
        catch (...)
        {
            return result;
        }
        result.thread_id = refusal.thread_id;
        const IdleRefusalSentence sentence = describe_idle_refusal(refusal);
        std::ranges::copy(sentence.view(), result.sentence.begin());
        result.sentence_size = sentence.size;
        return result;
    }

    void retire_backend_trap_runtime_for_test() noexcept
    {
        safetyhook::retire_trap_runtime_for_test();
    }

    TrapTransactionOutcome drive_backend_trap_transaction_for_test(
        void *from,
        void *to,
        std::size_t len,
        const std::function<void()> &run_fn
    ) noexcept
    {
        try
        {
            safetyhook::reset_trap_restore_trace_for_test();
            const std::expected<void, safetyhook::OsError> result = safetyhook::trap_threads(
                static_cast<std::uint8_t *>(from),
                static_cast<std::uint8_t *>(to),
                len,
                run_fn
            );
            return result ? TrapTransactionOutcome::Restored : TrapTransactionOutcome::ReportedFailure;
        }
        catch (...)
        {
            return TrapTransactionOutcome::Threw;
        }
    }

    void set_backend_trap_change_failure_target_for_test(void *segment_address) noexcept
    {
        safetyhook::g_trap_change_failure_override.store(
            static_cast<std::uint8_t *>(segment_address),
            std::memory_order_release
        );
    }

    void set_backend_trap_segment_restore_failure_target_for_test(void *segment_address) noexcept
    {
        safetyhook::g_trap_segment_restore_failure_override.store(
            static_cast<std::uint8_t *>(segment_address),
            std::memory_order_release
        );
    }

    std::size_t backend_trap_restore_trace_size_for_test() noexcept
    {
        return safetyhook::trap_restore_trace_size_for_test();
    }

    void *backend_trap_restore_trace_address_for_test(std::size_t index) noexcept
    {
        return safetyhook::trap_restore_trace_address_for_test(index);
    }

    void reset_backend_instruction_flush_trace_for_test() noexcept
    {
        safetyhook::reset_instruction_cache_flush_trace_for_test();
    }

    void set_backend_instruction_flush_failure_call_for_test(std::size_t call) noexcept
    {
        safetyhook::g_instruction_cache_flush_failure_call.store(call, std::memory_order_release);
    }

    std::size_t backend_instruction_flush_trace_size_for_test() noexcept
    {
        return safetyhook::instruction_cache_flush_trace_size_for_test();
    }

    BackendInstructionFlushObservation backend_instruction_flush_trace_for_test(std::size_t index) noexcept
    {
        const safetyhook::InstructionCacheFlushObservation observation =
            safetyhook::instruction_cache_flush_trace_for_test(index);
        return BackendInstructionFlushObservation{
            .address = observation.address,
            .size = observation.size,
            .protect_calls_before = observation.protect_calls_before,
            .succeeded = observation.succeeded,
        };
    }

    void force_backend_ff_hook_for_test(bool force) noexcept
    {
        safetyhook::force_ff_hook_for_test(force);
    }

    std::size_t backend_instruction_boundary_trace_size_for_test() noexcept
    {
        return safetyhook::instruction_boundary_trace_size_for_test();
    }

    std::array<std::size_t, 2> backend_instruction_boundary_trace_for_test(std::size_t index) noexcept
    {
        const safetyhook::InstructionBoundary boundary = safetyhook::instruction_boundary_trace_for_test(index);
        return {
            boundary.original_offset,
            boundary.trampoline_offset,
        };
    }

    std::uint8_t backend_last_inline_error_type_for_test() noexcept
    {
        return safetyhook::last_inline_hook_error_type_for_test();
    }

    void *backend_non_executable_transaction_marker_for_test() noexcept
    {
        return safetyhook::non_executable_transaction_marker_for_test();
    }

    void omit_backend_relay_cell_for_test(bool omit) noexcept
    {
        safetyhook::omit_relay_cell_for_test(omit);
    }

    void set_backend_coordinator_refusal_for_test(unsigned refusal) noexcept
    {
        safetyhook::g_coordinator_refusal_for_test.store(refusal);
    }

    BackendCoordinatorCounts backend_coordinator_counts_for_test() noexcept
    {
        const safetyhook::ProcessCoordinatorSnapshot snapshot = safetyhook::process_coordinator_snapshot_for_test();
        return BackendCoordinatorCounts{
            .live = snapshot.live,
            .retained = snapshot.retained,
            .vacant = snapshot.vacant,
            .free = snapshot.bytes == 0 ? 0 : safetyhook::PROCESS_ROUTE_CAPACITY - snapshot.live - snapshot.retained,
        };
    }

    struct BackendProbe
    {
        std::variant<safetyhook::InlineHook, safetyhook::MidHook> backend;
    };

    BackendProbe *create_backend_probe_for_test(
        BackendProbeKind kind,
        void *target,
        void *destination,
        std::string_view position_name
    ) noexcept
    {
        try
        {
            const std::shared_ptr<safetyhook::Allocator> &allocator = hook::backend_allocator();
            const safetyhook::PositionClaim claim = safetyhook::PositionClaim::from_name(position_name);
            if (kind == BackendProbeKind::Mid)
            {
                auto created = safetyhook::MidHook::create(
                    allocator,
                    target,
                    reinterpret_cast<safetyhook::MidHookFn>(destination),
                    safetyhook::MidHook::StartDisabled,
                    claim
                );
                return created ? new BackendProbe{std::move(*created)} : nullptr;
            }
            const auto flags = static_cast<safetyhook::InlineHook::Flags>(
                safetyhook::InlineHook::StartDisabled |
                (kind == BackendProbeKind::Routed ? safetyhook::InlineHook::RoutedExternal : 0)
            );
            auto created = safetyhook::InlineHook::create(allocator, target, destination, flags, claim);
            return created ? new BackendProbe{std::move(*created)} : nullptr;
        }
        catch (...)
        {
            return nullptr;
        }
    }

    bool drive_backend_probe_for_test(BackendProbe *probe, BackendProbeOperation operation) noexcept
    {
        return backend_value_or(
            probe->backend,
            false,
            [operation](auto &backend) noexcept -> bool
            {
                using Backend = std::remove_reference_t<decltype(backend)>;
                switch (operation)
                {
                case BackendProbeOperation::Enable:
                    return try_backend_enable(backend);
                case BackendProbeOperation::Disable:
                    return try_backend_disable(backend);
                case BackendProbeOperation::Bypass:
                    return backend.bypass();
                case BackendProbeOperation::Resume:
                    return backend.resume();
                case BackendProbeOperation::Vacate:
                    return backend.vacate();
                case BackendProbeOperation::Reset:
                    backend.reset();
                    return true;
                case BackendProbeOperation::MoveAssign:
                    backend = Backend{};
                    return true;
                case BackendProbeOperation::RetainRoute:
                    backend.retain_route();
                    return true;
                case BackendProbeOperation::ObserveRouteEntries:
                    return backend.observe_route_entries() == 0;
                }
                return false;
            }
        );
    }

    BackendProbeState backend_probe_state_for_test(const BackendProbe *probe) noexcept
    {
        return backend_value_or(
            probe->backend,
            BackendProbeState{},
            [](const auto &backend) noexcept
            {
                bool stub_freed = false;
                if constexpr (std::is_same_v<std::remove_cvref_t<decltype(backend)>, safetyhook::MidHook>)
                {
                    stub_freed = backend.stub_freed();
                }
                return BackendProbeState{
                    .valid = static_cast<bool>(backend),
                    .enabled = backend.enabled(),
                    .claimed = backend.claimed(),
                    .bypassed = backend.bypassed(),
                    .trampoline = backend.trampoline().data(),
                    .relay_slot = backend.relay_slot_for_test(),
                    .relay_cell = backend.relay_cell_for_test(),
                    .route_retained = backend.route_retained(),
                    .stub_freed = stub_freed,
                    .retention_reason = backend.route_retention_reason(),
                };
            }
        );
    }

    void destroy_backend_probe_for_test(BackendProbe *probe) noexcept
    {
        delete probe;
    }

    namespace
    {
        // One-byte targets for the filler records. Their patches overlap no hook target, so they change no layer
        // count and no top() answer.
        std::array<std::uint8_t, safetyhook::PROCESS_ROUTE_CAPACITY> s_coordinator_fill_keys{};
        std::size_t s_coordinator_fill_count{0};
    } // namespace

    std::size_t fill_backend_coordinator_for_test(std::size_t count) noexcept
    {
        safetyhook::ProcessCoordinator coordinator;
        std::size_t added = 0;
        while (coordinator && added < count && s_coordinator_fill_count < s_coordinator_fill_keys.size())
        {
            std::uint8_t *const key = &s_coordinator_fill_keys[s_coordinator_fill_count];
            if (!coordinator.add(key, 1, {key, key + 1}, {}, nullptr, {}))
            {
                break;
            }
            ++s_coordinator_fill_count;
            ++added;
        }
        return added;
    }

    void clear_backend_coordinator_fill_for_test() noexcept
    {
        safetyhook::ProcessCoordinator coordinator;
        while (s_coordinator_fill_count != 0)
        {
            coordinator.remove(&s_coordinator_fill_keys[--s_coordinator_fill_count]);
        }
    }
#endif
} // namespace DetourModKit::detail

namespace DetourModKit
{
    // File-local helpers live at DetourModKit scope, outside namespace hook. A bare `detail::` therefore resolves to
    // DetourModKit::detail, the memory/x86/platform engine. A hook::detail subnamespace otherwise shadows it and
    // breaks the unqualified lookup.
    namespace
    {
        /**
         * @brief Takes a counted reference on this module for an install path and honors the test override.
         * @details On failure the primitive restores the thread's last-error, so the caller can read GetLastError()
         *          immediately after a null return.
         */
        [[nodiscard]] HMODULE acquire_hook_self_ref() noexcept
        {
#if defined(DMK_ENABLE_TEST_SEAMS)
            if (auto *override_fn = DetourModKit::detail::g_hook_module_ref_override)
            {
                return override_fn();
            }
#endif
            return DetourModKit::detail::acquire_module_ref(diagnostics::ModulePinReason::Hook);
        }

        /// Names the chain position that a request with @p name claims and leaves behind (`[B-105]`).
        [[nodiscard]] safetyhook::PositionClaim position_claim_for(std::string_view name) noexcept
        {
#if defined(DMK_ENABLE_TEST_SEAMS)
            if (DetourModKit::detail::g_hook_position_claims_refused_for_test.load(std::memory_order_acquire))
            {
                return {};
            }
#endif
            return safetyhook::PositionClaim::from_name(name);
        }

        /// Logs that an install took the vacated position of an earlier generation.
        void note_position_claim(std::string_view name, std::uintptr_t target) noexcept
        {
            (void)log().try_log(
                LogLevel::Info,
                "hook: '{}' at 0x{:0{}X} claimed a vacated position.",
                name,
                target,
                sizeof(std::uintptr_t) * 2
            );
        }
        /// Reports whether the foreign-inline-hook preflight found a present redirect and its destination.
        enum class PrehookState : std::uint8_t
        {
            NotHooked,
            HookedBySameModule,
            HookedByOtherModule
        };

        struct PrehookDetection
        {
            PrehookState state{PrehookState::NotHooked};
            std::uintptr_t jmp_destination{0};
        };

        /// Releases a module reference automatically unless ownership is handed to a hook Impl.
        class ModuleRefGuard
        {
        public:
            explicit ModuleRefGuard(HMODULE module) noexcept : m_module(module) {}

            ~ModuleRefGuard() noexcept { detail::release_module_ref(m_module, diagnostics::ModulePinReason::Hook); }

            ModuleRefGuard(const ModuleRefGuard &) = delete;
            ModuleRefGuard &operator=(const ModuleRefGuard &) = delete;
            ModuleRefGuard(ModuleRefGuard &&) = delete;
            ModuleRefGuard &operator=(ModuleRefGuard &&) = delete;

            [[nodiscard]] HMODULE release() noexcept { return std::exchange(m_module, nullptr); }

            [[nodiscard]] HMODULE get() const noexcept { return m_module; }

        private:
            HMODULE m_module{nullptr};
        };

        /// Returns a claimed mid-adapter slot to the pool unless the install transaction commits it to an Impl.
        class MidAdapterSlotGuard
        {
        public:
            explicit MidAdapterSlotGuard(std::size_t index) noexcept : m_index(index) {}

            // The guard is safe without a rundown because it fires only before hook arm. No adapter entry occurred.
            // Once the Impl owns the slot, teardown runs its rundown instead.
            ~MidAdapterSlotGuard() noexcept { detail::release_mid_adapter_slot(m_index); }

            MidAdapterSlotGuard(const MidAdapterSlotGuard &) = delete;
            MidAdapterSlotGuard &operator=(const MidAdapterSlotGuard &) = delete;
            MidAdapterSlotGuard(MidAdapterSlotGuard &&) = delete;
            MidAdapterSlotGuard &operator=(MidAdapterSlotGuard &&) = delete;

            [[nodiscard]] std::size_t release() noexcept
            {
                return std::exchange(m_index, detail::MID_ADAPTER_CAPACITY);
            }

        private:
            std::size_t m_index{detail::MID_ADAPTER_CAPACITY};
        };

        /**
         * @brief Decodes an initial inline-hook redirect at @p target_address and returns its destination.
         * @details Recognizes three redirect shapes that a foreign hook plants over a prologue. These shapes are E9
         *          rel32, FF 25 [rip+disp32], and 48 B8 imm64 plus FF E0. Returns nullopt for any other prologue.
         */
        std::optional<std::uintptr_t> decode_prehook_destination(std::uintptr_t target_address) noexcept
        {
            std::array<std::uint8_t, 2> opcode{};
            if (!detail::guarded_read_bytes(target_address, opcode.data(), opcode.size()))
            {
                return std::nullopt;
            }

            // EB (jmp rel8) reaches at most +/-127 bytes. This range is too short to land in a foreign hook stub. An
            // initial 0xEB is ordinary code and deliberately does not match.
            if (opcode[0] == 0xE9)
            {
                return detail::decode_e9_rel32(target_address);
            }
            if (opcode[0] == 0xFF && opcode[1] == 0x25)
            {
                return detail::decode_ff25_indirect(target_address);
            }
            if (opcode[0] == 0x48 && opcode[1] == 0xB8)
            {
                return detail::decode_mov_rax_imm64_jmp_rax(target_address);
            }
            return std::nullopt;
        }

        /// Detects whether @p target_address is already inline-hooked and classifies the module that owns the redirect.
        PrehookDetection detect_existing_inline_hook(std::uintptr_t target_address) noexcept
        {
            PrehookDetection result;
            if (target_address == 0)
            {
                return result;
            }
            const auto destination_opt = decode_prehook_destination(target_address);
            if (!destination_opt)
            {
                return result;
            }
            const auto destination = *destination_opt;
            result.jmp_destination = destination;

            HMODULE target_module = nullptr;
            HMODULE dest_module = nullptr;
            if (!GetModuleHandleExW(
                    GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                    reinterpret_cast<LPCWSTR>(target_address),
                    &target_module
                ))
            {
                target_module = nullptr;
            }
            if (!GetModuleHandleExW(
                    GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                    reinterpret_cast<LPCWSTR>(destination),
                    &dest_module
                ))
            {
                dest_module = nullptr;
            }
            result.state = (dest_module != nullptr && target_module == dest_module) ? PrehookState::HookedBySameModule
                                                                                    : PrehookState::HookedByOtherModule;
            return result;
        }

        /// PrologueRisk classifies the target's first byte during inline or mid preflight.
        enum class PrologueRisk : std::uint8_t
        {
            None,
            // Prologue::Fail refuses a 0xCC int3 or 0xCD int n.
            Breakpoint,
            // Every policy refuses an unreadable first byte.
            Unreadable
        };

        // An initial rel32 call is left to the backend, which relocates it or fails typed. An unreadable first byte
        // stays a distinct fail-closed result because the target can change after window validation.
        PrologueRisk classify_prologue_risk(std::uintptr_t target_address) noexcept
        {
            if (target_address == 0)
            {
                return PrologueRisk::None;
            }
            std::uint8_t first_byte = 0;
            if (!detail::guarded_read_bytes(target_address, &first_byte, sizeof(first_byte)))
            {
                return PrologueRisk::Unreadable;
            }
            switch (first_byte)
            {
            case 0xCC:
            case 0xCD:
                return PrologueRisk::Breakpoint;
            default:
                return PrologueRisk::None;
            }
        }

        /// Returns a human-readable fragment for a flagged prologue risk in diagnostic log lines.
        [[nodiscard]] std::string_view prologue_risk_description(PrologueRisk risk) noexcept
        {
            switch (risk)
            {
            case PrologueRisk::Breakpoint:
                return "a breakpoint (0xCC/0xCD)";
            case PrologueRisk::Unreadable:
                return "an unreadable byte";
            case PrologueRisk::None:
                return "an unremarkable byte";
            }
            return "an unremarkable byte";
        }

        /// Names the allocator's verdict so a log line separates an exhausted window from a refused commit.
        [[nodiscard]] std::string_view allocator_error_description(safetyhook::Allocator::Error error) noexcept
        {
            switch (error)
            {
            case safetyhook::Allocator::Error::BAD_VIRTUAL_ALLOC:
                return "VirtualAlloc refused the request";
            case safetyhook::Allocator::Error::NO_MEMORY_IN_RANGE:
                return "no free region within +/-2 GB of the target";
            }
            return "an unlisted allocator verdict";
        }

        // These formatters preserve each backend reason in the diagnostic log after failures map to
        // ErrorCode::BackendFailed.
        std::string backend_error_string(const safetyhook::InlineHook::Error &err)
        {
            const int type_int = static_cast<int>(err.type);
            const auto ip_str = format::format_address(reinterpret_cast<std::uintptr_t>(err.ip));
            switch (err.type)
            {
            case safetyhook::InlineHook::Error::BAD_ALLOCATION:
                return std::format(
                    "InlineHook backend error ({}): bad allocation ({})",
                    type_int,
                    allocator_error_description(err.allocator_error)
                );
            case safetyhook::InlineHook::Error::FAILED_TO_DECODE_INSTRUCTION:
                return std::format(
                    "InlineHook backend error ({}): failed to decode instruction at {}",
                    type_int,
                    ip_str
                );
            case safetyhook::InlineHook::Error::SHORT_JUMP_IN_TRAMPOLINE:
                return std::format("InlineHook backend error ({}): short jump in trampoline at {}", type_int, ip_str);
            case safetyhook::InlineHook::Error::IP_RELATIVE_INSTRUCTION_OUT_OF_RANGE:
                return std::format(
                    "InlineHook backend error ({}): IP-relative instruction out of range at {}",
                    type_int,
                    ip_str
                );
            case safetyhook::InlineHook::Error::UNSUPPORTED_INSTRUCTION_IN_TRAMPOLINE:
                return std::format(
                    "InlineHook backend error ({}): unsupported instruction in trampoline at {}",
                    type_int,
                    ip_str
                );
            case safetyhook::InlineHook::Error::FAILED_TO_UNPROTECT:
                return std::format("InlineHook backend error ({}): failed to unprotect memory at {}", type_int, ip_str);
            case safetyhook::InlineHook::Error::NOT_ENOUGH_SPACE:
                return std::format(
                    "InlineHook backend error ({}): prologue too short for the hook at {}",
                    type_int,
                    ip_str
                );
            case safetyhook::InlineHook::Error::FAILED_TO_REGISTER_UNWIND:
                return std::format(
                    "InlineHook backend error ({}): the platform refused unwind metadata for the routed "
                    "wrapper at {}",
                    type_int,
                    ip_str
                );
            case safetyhook::InlineHook::Error::ROUTE_RETENTION_EXHAUSTED:
                return std::format(
                    "InlineHook backend error ({}): the routed retention ceiling refused the permanent "
                    "chain for {}",
                    type_int,
                    ip_str
                );
            case safetyhook::InlineHook::Error::FAILED_TO_FLUSH_INSTRUCTION_CACHE:
                return std::format(
                    "InlineHook backend error ({}): failed to flush the instruction cache at {}",
                    type_int,
                    ip_str
                );
            case safetyhook::InlineHook::Error::COORDINATION_UNAVAILABLE:
                return std::format(
                    "InlineHook backend error ({}): process coordination is unavailable at {}",
                    type_int,
                    ip_str
                );
            case safetyhook::InlineHook::Error::LAYER_CONFLICT:
                return std::format(
                    "InlineHook backend error ({}): a newer participant owns the target at {}",
                    type_int,
                    ip_str
                );
            case safetyhook::InlineHook::Error::NON_EXECUTABLE_TRANSACTION_UNAVAILABLE:
                return std::format(
                    "InlineHook backend error ({}): a non-executable patch transaction is unavailable at {}",
                    type_int,
                    ip_str
                );
            default:
                return std::format("InlineHook backend error ({}): unknown error type", type_int);
            }
        }

        std::string backend_error_string(const safetyhook::MidHook::Error &err)
        {
            const int type_int = static_cast<int>(err.type);
            switch (err.type)
            {
            case safetyhook::MidHook::Error::BAD_ALLOCATION:
                return std::format(
                    "MidHook backend error ({}): bad allocation ({})",
                    type_int,
                    allocator_error_description(err.allocator_error)
                );
            case safetyhook::MidHook::Error::BAD_INLINE_HOOK:
                return std::format(
                    "MidHook backend error ({}): bad underlying inline hook. {}",
                    type_int,
                    backend_error_string(err.inline_hook_error)
                );
            default:
                return std::format("MidHook backend error ({}): unknown error type", type_int);
            }
        }

        /**
         * @brief Serializes VMT object-vptr transitions.
         * @details A namespace-scope VmtHook can outlive ordinary hook statics. The mutex uses never-destroyed
         *          storage (`[B-47]`).
         */
        [[nodiscard]] std::mutex &vmt_object_mutex() noexcept
        {
            alignas(std::mutex) static unsigned char storage[sizeof(std::mutex)];
            static std::mutex *const gate = ::new (static_cast<void *>(storage)) std::mutex();
            return *gate;
        }

        /**
         * @brief Acquires the VMT object gate and returns an unowned lock if the OS mutex acquisition fails.
         * @details Callers fail closed on an unowned lock. A restore without the gate races another object-vptr
         *          transition.
         */
        [[nodiscard]] std::unique_lock<std::mutex> acquire_vmt_object_lock() noexcept
        {
            try
            {
                return std::unique_lock<std::mutex>(vmt_object_mutex());
            }
            catch (...)
            {
                return std::unique_lock<std::mutex>{};
            }
        }

        // Decides whether @p slot_value, the first qword of a vtable slot, resembles a callable function body. A 0x00
        // first byte marks an uninitialized page. Bytes 0xCC/0xCD are int3/int padding. Bytes 0xC2/0xC3 are bare RETs.
        // An EB/E9 same-module jump is a stub, such as an incremental-link ILT entry or a patched slot. Its clone makes
        // the new "original" a forwarder. MSVC adjustor thunks start with byte 0x48 and pass. Tail calls to a foreign
        // module pass. The reads use fault guards.
        bool looks_like_function_vmt_slot(std::uintptr_t slot_value) noexcept
        {
            if (slot_value == 0)
            {
                return false;
            }
            std::uint8_t first_byte = 0;
            if (!detail::guarded_read_bytes(slot_value, &first_byte, sizeof(first_byte)))
            {
                return false;
            }
            switch (first_byte)
            {
            case 0x00:
            case 0xCC:
            case 0xCD:
            case 0xC2:
            case 0xC3:
                return false;
            default:
                break;
            }

            if (first_byte == 0xEB || first_byte == 0xE9)
            {
                HMODULE slot_module = nullptr;
                HMODULE jmp_module = nullptr;
                if (GetModuleHandleExW(
                        GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                        reinterpret_cast<LPCWSTR>(slot_value),
                        &slot_module
                    ) == 0)
                {
                    return false;
                }
                const std::optional<std::uintptr_t> jmp_target =
                    (first_byte == 0xE9) ? detail::decode_e9_rel32(slot_value) : detail::decode_eb_rel8(slot_value);
                if (!jmp_target)
                {
                    return false;
                }
                if (GetModuleHandleExW(
                        GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                        reinterpret_cast<LPCWSTR>(*jmp_target),
                        &jmp_module
                    ) == 0)
                {
                    return false;
                }
                if (slot_module == jmp_module)
                {
                    return false;
                }
            }
            return true;
        }

        // SafetyHook sizes a clone through an executable check for each slot target. This module-owned code address
        // fixes that answer after DMK counts the captured words. The detached clone receives the captured function
        // pointers before any host object can observe it.
        void vmt_snapshot_executable_marker() noexcept {}

        /**
         * @brief Counts callable slots from the object's current vptr, guarded and capped at
         *        @ref detail::MAX_VMT_SLOTS.
         * @note The result bounds the guarded capture in @ref clone_vmt_snapshot. It is not the clone's slot count:
         *       the backend derives that from the captured snapshot, which is the only bound a slot write respects.
         */
        [[nodiscard]] std::optional<std::size_t> count_vmt_method_slots(std::uintptr_t vptr) noexcept
        {
            std::size_t count = 0;
            for (;;)
            {
                if (count >= detail::MAX_VMT_SLOTS)
                {
                    return std::nullopt;
                }
                if (count > (std::numeric_limits<std::uintptr_t>::max() - vptr) / sizeof(std::uintptr_t))
                {
                    return std::nullopt;
                }

                const std::uintptr_t slot_address = vptr + (count * sizeof(std::uintptr_t));
                const std::optional<std::uintptr_t> slot = detail::guarded_read<std::uintptr_t>(slot_address);
                if (!slot)
                {
                    return std::nullopt;
                }
                // detail::is_executable_address classifies the slot from VirtualQuery page state alone (B-66): the
                // backend's executable query parses the owning module's PE headers unguarded and faults the host
                // when that header page is unreadable. Lifecycle.VmtUnreadableModuleHeader pins the contract.
                if (!detail::is_executable_address(*slot))
                {
                    return count;
                }
                ++count;
            }
        }

        /**
         * @struct DetachedVmtBackend
         * @brief Stores a backend clone that no host object points at yet and the facts its publisher needs.
         * @details method_count matches the clone the backend allocated, not the caller's pre-count. It is the only
         *          bound between a caller's index and an unchecked slot write.
         */
        struct DetachedVmtBackend
        {
            safetyhook::VmtHook backend;
            std::uintptr_t cloned_vptr_base{0};
            std::size_t method_count{0};
        };

        /**
         * @brief Clones an owned, count-normalized vtable snapshot. The backend remains unattached to any object.
         * @return The detached backend, InvalidObject on a bad prefix/capture/empty table, or BackendFailed.
         */
        [[nodiscard]] Result<DetachedVmtBackend> clone_vmt_snapshot(std::uintptr_t vptr, std::size_t slot_budget)
        {
            constexpr std::size_t header_count = safetyhook::VMT_HEADER;
            constexpr std::uintptr_t header_bytes = header_count * sizeof(std::uintptr_t);
            if (vptr < header_bytes)
            {
                return std::unexpected(Error{ErrorCode::InvalidObject, "hook::vmt_for", vptr});
            }

            // The final zero is a private non-executable sentinel for the backend slot walk.
            std::vector<std::uintptr_t> snapshot(header_count + slot_budget + 1, 0);
            const std::uintptr_t snapshot_source = vptr - header_bytes;
            const std::size_t snapshot_bytes = (header_count + slot_budget) * sizeof(std::uintptr_t);
            if (!detail::guarded_read_bytes(snapshot_source, snapshot.data(), snapshot_bytes))
            {
                return std::unexpected(Error{ErrorCode::InvalidObject, "hook::vmt_for", snapshot_source});
            }

            // Walk the captured words again rather than trust slot_budget. The budget came from foreign memory a
            // moment earlier. The backend sizes its clone from THIS buffer. The two can disagree if the vtable changes
            // between those steps. The backend bounds-checks no slot write, and hook_method admits any index below the
            // count published here. A count for slots absent from the clone therefore causes an out-of-bounds write.
            std::size_t cloned_slots = 0;
            // Page-state classification only; see count_vmt_method_slots (B-66).
            while (cloned_slots < slot_budget && detail::is_executable_address(snapshot[header_count + cloned_slots]))
            {
                ++cloned_slots;
            }
            if (cloned_slots == 0)
            {
                return std::unexpected(Error{ErrorCode::InvalidObject, "hook::vmt_for", vptr});
            }
            // Terminate the counted run so no later step can reach past it.
            snapshot[header_count + cloned_slots] = 0;

            // The captured pointer words are stable, but the execute protections of the pages they name are not. If a
            // target loses execute permission between the walk above and SafetyHook's walk, the backend can allocate
            // fewer slots than method_count permits. Give the backend an equally-sized run of a module-owned marker,
            // then restore the captured pointers into its detached clone before publication.
            std::vector<std::uintptr_t> backend_snapshot = snapshot;
            const std::uintptr_t executable_marker = reinterpret_cast<std::uintptr_t>(&vmt_snapshot_executable_marker);
            std::fill_n(
                backend_snapshot.begin() + static_cast<std::ptrdiff_t>(header_count),
                cloned_slots,
                executable_marker
            );
#if defined(DMK_ENABLE_TEST_SEAMS)
            if (auto *probe = DetourModKit::detail::g_vmt_before_backend_clone_probe)
            {
                probe();
            }
#endif
            auto *surrogate_vptr = reinterpret_cast<std::uint8_t **>(backend_snapshot.data() + header_count);
            auto created = safetyhook::VmtHook::create(static_cast<void *>(&surrogate_vptr));
            if (!created)
            {
                return std::unexpected(Error{ErrorCode::BackendFailed, "hook::vmt_for", vptr});
            }

            safetyhook::VmtHook backend = std::move(created.value());
            const std::uintptr_t cloned_vptr_base = reinterpret_cast<std::uintptr_t>(surrogate_vptr);
            std::copy_n(
                snapshot.data() + header_count,
                cloned_slots,
                reinterpret_cast<std::uintptr_t *>(cloned_vptr_base)
            );
            // Erase the stack surrogate from the backend before it leaves scope. Real host objects are published and
            // restored only through DMK's guarded swaps, so the backend never retains a foreign object pointer.
            backend.remove(static_cast<void *>(&surrogate_vptr));
            return DetachedVmtBackend{std::move(backend), cloned_vptr_base, cloned_slots};
        }

        [[nodiscard]] bool
        publish_vmt_object_word(void *object, std::uintptr_t expected, std::uintptr_t replacement) noexcept
        {
#if defined(DMK_ENABLE_TEST_SEAMS)
            if (auto *probe = DetourModKit::detail::g_vmt_before_publish_probe)
            {
                probe(object);
            }
#endif
            return detail::guarded_compare_exchange_word(
                reinterpret_cast<std::uintptr_t>(object),
                expected,
                replacement
            );
        }

        /// Resolves a hook Target to an absolute address, through scan::resolve for a deferred OwnedScanRequest.
        Result<std::uintptr_t> resolve_target(const hook::Target &target) noexcept
        {
            if (const Address *absolute = std::get_if<Address>(&target))
            {
                return absolute->raw();
            }
            const auto *request = std::get_if<scan::OwnedScanRequest>(&target);
            if (request == nullptr)
            {
                return std::unexpected(Error{ErrorCode::InvalidTargetAddress, "hook::resolve_target"});
            }
            // scan::resolve can allocate and throw. This helper is noexcept, so it contains the exception and reports
            // an Error instead of host termination.
            try
            {
                Result<scan::Hit> hit = scan::resolve(request->view());
                if (!hit)
                {
                    return std::unexpected(hit.error());
                }
                return hit->address.raw();
            }
            catch (const std::bad_alloc &)
            {
                return std::unexpected(Error{ErrorCode::OutOfMemory, "hook::resolve_target"});
            }
            catch (...)
            {
                return std::unexpected(Error{ErrorCode::Unknown, "hook::resolve_target"});
            }
        }

        /// ReservedTarget contains the resolved target and its ledger id from @ref preflight_target.
        struct PreflightResult
        {
            std::uintptr_t address{0};
            std::uint64_t ledger_id{0};
        };

        /**
         * @brief Resolves, validates, checks, and reserves a ledger slot for an inline or mid hook target.
         * @return The target address and its reserved ledger id, or the Error that fails the install.
         * @details Waits until the reservation is first in the target queue. Backend patches for one target
         *          follow creation order. On success, the caller owns the returned ledger id. Commit it before handle
         *          publication, or roll it back through HookLedger::release_hook.
         */
        Result<PreflightResult> preflight_target(
            const hook::Target &target,
            const hook::Options &options,
            std::string_view name,
            const char *where
        ) noexcept
        {
            Result<std::uintptr_t> resolved = resolve_target(target);
            if (!resolved)
            {
                return std::unexpected(resolved.error());
            }
            const std::uintptr_t address = *resolved;
            if (address == 0)
            {
                return std::unexpected(Error{ErrorCode::InvalidTargetAddress, where});
            }

            // The backend capability floor runs before any reservation, so a refusal needs no rollback.
            // Options::prologue does not alter this check. Prologue::Relocate must not authorize an unreadable
            // prologue.
            const detail::TargetWindowResult window = detail::validate_backend_steal_window(address);
            if (window.verdict != detail::TargetWindowVerdict::Ok)
            {
                (void)log().try_log(
                    LogLevel::Warning,
                    "hook: '{}' refused target 0x{:0{}X}: {}.",
                    name,
                    address,
                    sizeof(std::uintptr_t) * 2,
                    detail::target_window_description(window.verdict)
                );
                return std::unexpected(
                    Error{
                        window.verdict == detail::TargetWindowVerdict::Unreadable ? ErrorCode::ReadFaulted
                                                                                  : ErrorCode::TargetPrologueUnsafe,
                        where,
                        window.detail
                    }
                );
            }

            // try_reserve_hook folds the same-kit duplicate check and the id record into one locked step, so a
            // concurrent same-target install cannot slip between them.
            const detail::HookLedger::Reservation reservation =
                detail::HookLedger::instance().try_reserve_hook(address, options.fail_if_already_hooked);
            if (reservation.status == detail::HookLedger::ReserveStatus::OutOfMemory)
            {
                // The ledger allocation failed. Fail closed instead of an install of a live but unledgered hook.
                return std::unexpected(Error{ErrorCode::OutOfMemory, where, address});
            }
            if (reservation.status == detail::HookLedger::ReserveStatus::AlreadyHooked)
            {
                return std::unexpected(Error{ErrorCode::TargetAlreadyHookedByThisKit, where, address});
            }

            if (reservation.preexisting)
            {
                // If this install layers on a same-kit hook, warn and continue.
                (void)log().try_log(
                    LogLevel::Warning,
                    "hook: '{}' layers on a hook this kit already placed at 0x{:0{}X}. The layers retire "
                    "in any order.",
                    name,
                    address,
                    sizeof(std::uintptr_t) * 2
                );
            }
            else
            {
                // Consult the foreign-JMP heuristic. On a strict refusal, roll back the reservation before failure.
                const PrehookDetection prehook = detect_existing_inline_hook(address);
                if (prehook.state == PrehookState::HookedByOtherModule)
                {
                    if (options.fail_if_already_hooked)
                    {
                        (void)detail::HookLedger::instance().release_hook(address, reservation.id);
                        return std::unexpected(Error{ErrorCode::TargetAlreadyHookedByAnotherModule, where, address});
                    }
                    (void)log().try_log(
                        LogLevel::Warning,
                        "hook: '{}' detects another module's inline hook at target 0x{:0{}X} "
                        "(JMP -> 0x{:0{}X}). The new hook layers on top.",
                        name,
                        address,
                        sizeof(std::uintptr_t) * 2,
                        prehook.jmp_destination,
                        sizeof(std::uintptr_t) * 2
                    );
                }
            }

            // Prologue preflight is independent of the layer checks. An unhooked target can still start with a call
            // thunk or patched int3. On a Fail-policy refusal, roll back the reservation before failure.
            const PrologueRisk risk = classify_prologue_risk(address);
            if (risk == PrologueRisk::Unreadable)
            {
                (void)detail::HookLedger::instance().release_hook(address, reservation.id);
                return std::unexpected(Error{ErrorCode::ReadFaulted, where, address});
            }
            if (risk == PrologueRisk::Breakpoint)
            {
                if (options.prologue == hook::Prologue::Fail)
                {
                    (void)detail::HookLedger::instance().release_hook(address, reservation.id);
                    return std::unexpected(Error{ErrorCode::TargetPrologueUnsafe, where, address});
                }
                (void)log().try_log(
                    LogLevel::Warning,
                    "hook: '{}' target 0x{:0{}X} begins with {}. Installation continues under the "
                    "Relocate prologue policy.",
                    name,
                    address,
                    sizeof(std::uintptr_t) * 2,
                    prologue_risk_description(risk)
                );
            }
            return PreflightResult{address, reservation.id};
        }

        using detail::apply_backend;
        using detail::backend_value_or;
        using detail::emit_lifecycle;
        using detail::inline_trampoline;
        using detail::PatchWitness;
        using detail::RemovalPopulationState;
        using detail::try_backend_disable;
        using detail::witness_description;
        using detail::witness_of;
        using detail::witness_permits_write;

        /**
         * @brief Runs the teardown backend disable and reports the later owner of the target bytes.
         * @details The witness is taken whatever the disable reported, because the two disagree in both directions.
         *          The byte class is the complete verdict. Only @ref PatchWitness::Original authorizes backend
         *          destruction.
         * @param refusal Receives the coordinator refusal of a failed disable.
         */
        template <class BackendVariant>
        [[nodiscard]] PatchWitness
        run_teardown_restore(BackendVariant &backend, DetourModKit::detail::CoordinatorRefusal &refusal) noexcept
        {
            // Classify before the restore, so foreign bytes are refused rather than overwritten.
            const PatchWitness before = witness_of(backend);
            if (!witness_permits_write(before))
            {
                return before;
            }

#if defined(DMK_ENABLE_TEST_SEAMS)
            // A false result or exception models a pre-mutation failure because it suppresses the backend call. The
            // witness below reconciles real backend exceptions after try_backend_disable contains them.
            bool run_restore = true;
            try
            {
                if (auto *override_fn = DetourModKit::detail::g_hook_teardown_restore_override)
                {
                    run_restore = override_fn();
                }
            }
            catch (...)
            {
                run_restore = false;
            }
            if (run_restore)
#endif
            {
                (void)backend_value_or(
                    backend,
                    false,
                    [&refusal](auto &one) noexcept { return try_backend_disable(one, &refusal); }
                );
            }
            const PatchWitness after = witness_of(backend);
            if (after == PatchWitness::Original)
            {
                // The byte witness proves the target cannot reach this trampoline. Clear a stale backend flag so its
                // destructor cannot retry the caught operation outside this noexcept containment boundary.
                (void)apply_backend(backend, [](auto &one) noexcept { one.reconcile_enabled(false); });
            }
            return after;
        }

        /**
         * @brief Bounds the wait for route entrants, displaced callees, and unresolved continuations.
         */
        constexpr auto ROUTE_DRAIN_TIMEOUT = std::chrono::seconds{1};

        /**
         * @brief Waits for the backend route to empty, or reports that proof of an empty route timed out.
         * @details The zero read that ends the wait proves the mid stub unreachable (`[B-108]`).
         * @note A false return never licenses reclamation. The caller must retain the backend.
         */
        template <class BackendVariant> [[nodiscard]] bool drain_backend_route(BackendVariant &backend) noexcept
        {
            return DetourModKit::detail::drain_until_zero(
                [&backend]() noexcept
                {
                    return backend_value_or(
                        backend,
                        std::size_t{1},
                        [](auto &one) noexcept { return one.observe_route_entries(); }
                    );
                },
                std::chrono::steady_clock::now() + ROUTE_DRAIN_TIMEOUT
            );
        }

        /**
         * @brief Switches the relay of a counted hook off and proves its detour idle within the route bound
         *        (`[B-106]`).
         * @return Null when the detour drained, or a phrase that completes the pin warning.
         */
        template <class BackendVariant>
        [[nodiscard]] const char *drain_counted_hook(BackendVariant &backend, const hook::CountedThunk &thunk) noexcept
        {
            const std::array<safetyhook::AddressRange, 1> ranges{thunk.range};
            if (hook::detail::current_thread_returns_into(ranges))
            {
                return "the teardown runs inside its own counted detour";
            }
            if (!DetourModKit::detail::switch_backend(backend, false))
            {
                return "the backend cannot switch its relay off";
            }
            std::array<const safetyhook::ReturnSites *, hook::COUNTED_HELPER_SITE_LISTS> sites{};
            for (std::size_t i = 0; i < thunk.helper_site_lists; ++i)
            {
                sites[i] = &thunk.helper_sites[i];
            }
            const std::array<hook::detail::CountedBlock *, 1> blocks{thunk.block};
            const hook::detail::CountedDrain drained = hook::detail::drain_counted(
                ranges,
                std::span<const safetyhook::ReturnSites *const>{sites.data(), thunk.helper_site_lists},
                blocks,
                std::chrono::steady_clock::now() + ROUTE_DRAIN_TIMEOUT
            );
            return drained.idle ? nullptr : "a counted call stayed inside its detour past the drain bound";
        }

        /**
         * @brief Pins a backend whose detour can stay reachable: it leaks the Impl and keeps its module reference.
         * @details A caller that holds the target install-serialization slot passes @p ledger, and the helper
         *          releases the slot. The creation-order entry stays, so is_target_hooked still reports the hooked
         *          target. Hook::Impl is private to Hook, so each ~Hook phase helper deduces the Impl type as a
         *          template parameter.
         * @param reason A string literal that completes the warning sentence.
         */
        template <class HookImpl>
        hook::TeardownOutcome pin_backend_with_live_detour(
            std::unique_ptr<HookImpl> &impl,
            detail::HookLedger *ledger,
            const std::string &name,
            std::uintptr_t target,
            std::uint64_t ledger_id,
            diagnostics::HookKind kind,
            const char *reason
        ) noexcept
        {
            diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::HookManager);
            (void)impl.release();
            if (ledger != nullptr)
            {
                ledger->release_target_slot(target, ledger_id);
            }
            (void)log().try_log(
                LogLevel::Warning,
                "hook: '{}' at 0x{:0{}X} leaked its backend during teardown, so its detour stays reachable: {}.",
                name,
                target,
                sizeof(std::uintptr_t) * 2,
                reason
            );
            emit_lifecycle(
                name,
                ledger_id,
                kind,
                diagnostics::HookTransition::Removed,
                RemovalPopulationState{
                    .remains_live = true,
                }
            );
            return hook::TeardownOutcome::Pinned;
        }

        /// Names why a layer retires by bypass in place of a restore.
        struct RetirementCause
        {
            /// The newer hooks of this kit, or zero when @ref detail proves the newer layer.
            std::size_t newer_layers{0};
            /// The byte witness or coordinator text, or empty for a claimed position.
            std::string_view detail{};
        };

        /// The outcome of the teardown restore.
        enum class TeardownRestore : std::uint8_t
        {
            Restored,
            Pinned,
            /// A newer layer, foreign bytes, or unreadable bytes refused the restore. The hook retires by bypass.
            Retire,
        };

        /**
         * @brief Restores the target prologue under the process coordinator, or decides how the hook retires.
         * @details The caller holds the target install-serialization slot. The helper releases it after a pin. A
         *          Retire outcome fills @p cause and, before it releases the coordinator, leaves a bypassed mid route
         *          closed and reopens any other.
         */
        template <class HookImpl>
        [[nodiscard]] TeardownRestore restore_target_or_pin_backend(
            std::unique_ptr<HookImpl> &impl,
            detail::HookLedger &ledger,
            const std::string &name,
            std::uintptr_t target,
            std::uint64_t ledger_id,
            diagnostics::HookKind kind,
            RetirementCause &cause
        ) noexcept
        {
            // Close the backend-owned route before restore, so admitted callers stay counted across the generated
            // stub. For an Unwaitable self-owned mid teardown, drain_route_or_retain_backend skips the drain and
            // retains the route. The helper takes the process coordinator before it closes the route, because the
            // coordinator wait export can be this closed route. A refused coordinator leaves the route open. The
            // backend disable then acquires the coordinator itself and closes the route, or it refuses the restore.
            std::optional<safetyhook::ProcessCoordinator> coordinator{std::in_place};
            if (*coordinator)
            {
                (void)apply_backend(impl->backend, [](auto &backend) noexcept { backend.begin_route_rundown(); });
            }
            // Disable the backend here instead of in ~Impl. Its backend destructor discards a failed disable and
            // reclaims storage regardless. Only a prologue at its original bytes authorizes backend destruction.
            // Foreign and Indeterminate bytes write nothing (see run_teardown_restore) and retire the hook.
            DetourModKit::detail::CoordinatorRefusal refusal = DetourModKit::detail::CoordinatorRefusal::None;
            const PatchWitness restore = run_teardown_restore(impl->backend, refusal);
            // Bytes that are not this hook's own, or a coordinator that saw a newer participant, mean that a restore
            // can clobber another layer. Only an own patch after a failed or thrown restore keeps the pin.
            const bool newer_participant = refusal == DetourModKit::detail::CoordinatorRefusal::LayerConflict;
            if (restore == PatchWitness::Foreign || restore == PatchWitness::Indeterminate ||
                (restore == PatchWitness::OwnedPatch && newer_participant))
            {
                // Retirement takes the coordinator again, and its wait export can be this route. A bypassed route
                // stays closed, so no caller enters the tombstoned adapter before the drain.
                const bool bypassed = impl->bypassed;
                (void)apply_backend(
                    impl->backend,
                    [bypassed](auto &backend) noexcept
                    { bypassed ? backend.finish_route_rundown() : backend.cancel_route_rundown(); }
                );
                coordinator.reset();
                cause.detail = restore == PatchWitness::OwnedPatch
                                   ? DetourModKit::detail::coordinator_refusal_description(refusal)
                                   : witness_description(restore);
                return TeardownRestore::Retire;
            }
            if (restore != PatchWitness::Original)
            {
                // A pin keeps the route state from before teardown, so a bypassed route stays closed.
                const bool bypassed = impl->bypassed;
                (void)apply_backend(
                    impl->backend,
                    [bypassed](auto &backend) noexcept
                    { bypassed ? backend.finish_route_rundown() : backend.cancel_route_rundown(); }
                );
                coordinator.reset();
                // The target can still dispatch through this trampoline. Pin the Impl to keep its pages mapped. Book
                // the leak and keep the creation-order entry, so is_target_hooked stays true.
                diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::HookManager);
                (void)impl.release();
                ledger.release_target_slot(target, ledger_id);
                const std::string_view refusal_text = DetourModKit::detail::coordinator_refusal_description(refusal);
                (void)log().try_log(
                    LogLevel::Warning,
                    "hook: '{}' at 0x{:0{}X} did not restore its target's prologue during teardown ({}{}{}). "
                    "Teardown leaked the backend, so the possibly reachable trampoline stays mapped. The target "
                    "remains tracked as hooked.",
                    name,
                    target,
                    sizeof(std::uintptr_t) * 2,
                    witness_description(restore),
                    refusal_text.empty() ? "" : ", ",
                    refusal_text
                );
                emit_lifecycle(
                    name,
                    ledger_id,
                    kind,
                    diagnostics::HookTransition::Removed,
                    RemovalPopulationState{
                        .remains_live = true,
                    }
                );
                return TeardownRestore::Pinned;
            }
            (void)apply_backend(impl->backend, [](auto &backend) noexcept { backend.finish_route_rundown(); });
            coordinator.reset();
            return TeardownRestore::Restored;
        }

        /**
         * @brief Retires a hook that cannot restore. It switches the hook off, drains a mid route, and vacates the
         *        position for a later generation of the same hook name.
         * @details The caller holds the target install-serialization slot. The helper releases it and keeps the
         *          creation-order entry, because the position stays in the target's chain. A drained position reaches
         *          no image code, so the module reference goes. The residue books HookResidue under the
         *          diagnostics::LeakSubsystem contract. Over the residue budget, a fresh layer keeps the pin.
         */
        template <class HookImpl>
        hook::TeardownOutcome retire_by_vacate(
            std::unique_ptr<HookImpl> &impl,
            detail::HookLedger &ledger,
            const std::string &name,
            std::uintptr_t target,
            std::uint64_t ledger_id,
            diagnostics::HookKind kind,
            bool was_active,
            DetourModKit::detail::MidRundown mid_rundown,
            bool has_mid_slot,
            std::size_t mid_slot,
            RetirementCause cause
        ) noexcept
        {
            const bool claimed = DetourModKit::detail::backend_claimed(impl->backend);
            if (!claimed && !DetourModKit::detail::residue_fits_budget(impl->backend))
            {
                // Same route-state rule as the pin in restore_target_or_pin_backend.
                (void)apply_backend(
                    impl->backend,
                    [was_active](auto &backend) noexcept
                    { was_active ? backend.cancel_route_rundown() : backend.finish_route_rundown(); }
                );
                return pin_backend_with_live_detour(
                    impl,
                    &ledger,
                    name,
                    target,
                    ledger_id,
                    kind,
                    "the target or the process route registry reached the residue budget"
                );
            }

            // A mid route drains while CLOSING, because a CLOSED route admits bypass traffic that holds entries. The
            // coordinator and the stack query come first, because either can call an export that this route hooks.
            bool drained = true;
            if (has_mid_slot)
            {
                const bool caller_owns_route = backend_value_or(
                    impl->backend,
                    true,
                    [](const auto &backend) noexcept { return backend.caller_owns_route(); }
                );
                const safetyhook::ProcessCoordinator coordinator;
                (void)apply_backend(impl->backend, [](auto &backend) noexcept { backend.begin_route_rundown(); });
                drained = mid_rundown == DetourModKit::detail::MidRundown::Drained && !caller_owns_route &&
                          DetourModKit::detail::drain_closing_route(
                              impl->backend,
                              DetourModKit::detail::CLOSING_DRAIN_TICK_BUDGET
                          );
                (void)apply_backend(impl->backend, [](auto &backend) noexcept { backend.finish_route_rundown(); });
            }
            drained =
                drained &&
                (!has_mid_slot ||
                 DetourModKit::detail::drain_mid_adapter_entries(DetourModKit::detail::mid_adapter_slots()[mid_slot]));
            if (!drained)
            {
                // A thread can still be inside the detour. The closed route stays closed.
                return pin_backend_with_live_detour(
                    impl,
                    &ledger,
                    name,
                    target,
                    ledger_id,
                    kind,
                    "a callback or route entrant did not drain before the bypass"
                );
            }
            if (!DetourModKit::detail::switch_backend(impl->backend, false))
            {
                return pin_backend_with_live_detour(
                    impl,
                    &ledger,
                    name,
                    target,
                    ledger_id,
                    kind,
                    "the backend cannot switch its relay off"
                );
            }

            const HMODULE self_ref = static_cast<HMODULE>(impl->self_ref);
            const bool vacated = DetourModKit::detail::vacate_backend(impl->backend);
            if (vacated)
            {
                impl.reset();
                if (has_mid_slot)
                {
                    DetourModKit::detail::release_mid_adapter_slot(mid_slot);
                }
            }
            else
            {
                // The cell stays Owned, so no successor takes this position. The bypassed backend reaches no image
                // code, so only the Impl leaks.
                (void)impl.release();
            }
            if (!claimed || !vacated)
            {
                diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::HookResidue);
            }
            ledger.release_target_slot(target, ledger_id);
            if (claimed)
            {
                (void)log().try_log(
                    LogLevel::Info,
                    "hook: '{}' at 0x{:0{}X} retired its claimed position{}.",
                    name,
                    target,
                    sizeof(std::uintptr_t) * 2,
                    vacated ? "" : ", which stays owned because the vacate was refused"
                );
            }
            else if (cause.newer_layers != 0)
            {
                (void)log().try_log(
                    LogLevel::Info,
                    "hook: '{}' at 0x{:0{}X} retired by bypass under {} newer layer(s). Its position {}.",
                    name,
                    target,
                    sizeof(std::uintptr_t) * 2,
                    cause.newer_layers,
                    vacated ? "stays for a later generation" : "stays owned because the vacate was refused"
                );
            }
            else
            {
                (void)log().try_log(
                    LogLevel::Info,
                    "hook: '{}' at 0x{:0{}X} retired by bypass under a newer layer: {}. Its position {}.",
                    name,
                    target,
                    sizeof(std::uintptr_t) * 2,
                    cause.detail,
                    vacated ? "stays for a later generation" : "stays owned because the vacate was refused"
                );
            }
            DetourModKit::detail::release_module_ref(self_ref, diagnostics::ModulePinReason::Hook);
            emit_lifecycle(
                name,
                ledger_id,
                kind,
                diagnostics::HookTransition::Removed,
                RemovalPopulationState{
                    .was_active = was_active,
                }
            );
            return hook::TeardownOutcome::Vacated;
        }

        /**
         * @brief Drains the restored route, or retains it and pins the backend while a caller can still return
         *        through it.
         * @details The caller holds the target install-serialization slot. The helper releases it on a false return.
         * @return True when the route drained, or false when the helper pinned the backend.
         */
        template <class HookImpl>
        [[nodiscard]] bool drain_route_or_retain_backend(
            std::unique_ptr<HookImpl> &impl,
            detail::HookLedger &ledger,
            const std::string &name,
            std::uintptr_t target,
            std::uint64_t ledger_id,
            diagnostics::HookKind kind,
            bool was_active,
            DetourModKit::detail::MidRundown mid_rundown
        ) noexcept
        {
            // A callback frame resolves through mid_rundown. Otherwise only a displaced call can return into this
            // route from the caller stack. A hook from inline_at publishes no gateway, and a mid gateway reaches its
            // stub without a wrapper call.
            const bool caller_owns_route = backend_value_or(
                impl->backend,
                true,
                [](const auto &backend) noexcept { return backend.caller_owns_route(); }
            );
            const bool route_drained = mid_rundown != DetourModKit::detail::MidRundown::Drained ||
                                       (!caller_owns_route && drain_backend_route(impl->backend));

            if (mid_rundown != DetourModKit::detail::MidRundown::Drained || !route_drained)
            {
                // A nonlocal exit can abandon its entry. Retention keeps the same lifetime as an unresolved entrant.
                const char *blocked_stage =
                    mid_rundown == DetourModKit::detail::MidRundown::Unwaitable
                        ? "teardown cannot wait on the caller's callback"
                    : mid_rundown == DetourModKit::detail::MidRundown::Expired ? "the callback drain expired"
                    : caller_owns_route ? "an unresolved continuation or nonlocal exit "
                                          "has a possible return on the caller stack"
                                        : "an unresolved continuation or nonlocal exit did not drain";
                // A live record refuses every older layer on this target.
                (void)apply_backend(impl->backend, [](auto &backend) noexcept { backend.retain_route(); });
                diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::HookManager);
                (void)impl.release();
                (void)ledger.release_hook(target, ledger_id);
                (void)log().try_log(
                    LogLevel::Warning,
                    "hook: '{}' at 0x{:0{}X} retained its backend because {}. "
                    "The target is restored. The backend and module references remain pinned.",
                    name,
                    target,
                    sizeof(std::uintptr_t) * 2,
                    blocked_stage
                );
                emit_lifecycle(
                    name,
                    ledger_id,
                    kind,
                    diagnostics::HookTransition::Removed,
                    RemovalPopulationState{
                        .was_active = was_active,
                    }
                );
                return false;
            }
            return true;
        }

        /**
         * @brief Retains the route and pins the backend when the bounded drain expires with a thread inside the
         *        adapter body.
         * @details The caller holds the target install-serialization slot. The helper releases it.
         */
        template <class HookImpl>
        void retain_backend_for_busy_adapter(
            std::unique_ptr<HookImpl> &impl,
            detail::HookLedger &ledger,
            const std::string &name,
            std::uintptr_t target,
            std::uint64_t ledger_id,
            diagnostics::HookKind kind,
            bool was_active
        ) noexcept
        {
            // The adapter_entries counter is the slot-reuse authority, so the slot and stub stay retained. The target
            // holds its original bytes, so release_hook drops the ledger entry.
            (void)apply_backend(impl->backend, [](auto &backend) noexcept { backend.retain_route(); });
            diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::HookManager);
            (void)impl.release();
            (void)ledger.release_hook(target, ledger_id);
            (void)log().try_log(
                LogLevel::Warning,
                "hook: mid hook '{}' at 0x{:0{}X} was torn down while a thread can still be inside its adapter "
                "body past its bounded drain. The target was restored, but the backend and adapter slot are "
                "pinned so that thread can return through its stub.",
                name,
                target,
                sizeof(std::uintptr_t) * 2
            );
            emit_lifecycle(
                name,
                ledger_id,
                kind,
                diagnostics::HookTransition::Removed,
                RemovalPopulationState{
                    .was_active = was_active,
                }
            );
        }

        /**
         * @brief Finishes a restored backend that release_backend tore down, then releases its adapter slot, ledger
         *        entry, and module reference.
         * @details A caller that holds the target install-serialization slot passes @p ledger, and the helper releases
         *          it. A retained route keeps the Impl, the adapter slot, and the module reference pinned, except a
         *          residue that reaches no image code (`[B-108]`).
         */
        template <class HookImpl>
        hook::TeardownOutcome reclaim_restored_backend(
            std::unique_ptr<HookImpl> &impl,
            detail::HookLedger *ledger,
            const std::string &name,
            std::uintptr_t target,
            std::uint64_t ledger_id,
            bool has_mid_slot,
            std::size_t mid_slot
        ) noexcept
        {
            // release_module_ref calls FreeLibrary, which takes the loader lock. release_hook releases the target
            // install-serialization slot before that call, which prevents a lock-order inversion against a DllMain
            // install parked on this slot. The caller still executes this module's code and the host holds its own
            // load reference, so this release is never the terminal one.
            const HMODULE self_ref = static_cast<HMODULE>(impl->self_ref);
            // The route verdict must outlive the Impl, so the helper reads it first.
            const bool route_retained = backend_value_or(
                impl->backend,
                false,
                [](const auto &backend) noexcept { return backend.route_retained(); }
            );
            const char *const retention_reason = backend_value_or(
                impl->backend,
                "route idle proof refused",
                [](const auto &backend) noexcept { return backend.route_retention_reason(); }
            );
            const DetourModKit::detail::IdleRefusalSentence refusal =
                DetourModKit::detail::describe_idle_refusal(backend_value_or(
                    impl->backend,
                    safetyhook::IdleRefusal{},
                    [](const auto &backend) noexcept { return backend.idle_refusal(); }
                ));
            // A raw hook that failed the idle proof keeps only its trampoline in allocator memory. A mid hook with a
            // freed stub keeps only its gateway and trampoline (`[B-108]`). The restored target and the switched-off
            // relay or route reach no image code, so the residue releases every reference.
            const auto *const inline_backend = std::get_if<safetyhook::InlineHook>(&impl->backend);
            const auto *const mid_backend = std::get_if<safetyhook::MidHook>(&impl->backend);
            const bool trampoline_residue =
                route_retained && inline_backend != nullptr &&
                inline_backend->route_retention_cause() == safetyhook::RouteRetentionReason::IdleProofFailed;
            const bool route_residue =
                route_retained && mid_backend != nullptr && mid_backend->stub_freed() &&
                (mid_backend->route_retention_cause() == safetyhook::RouteRetentionReason::IdleProofFailed ||
                 mid_backend->route_retention_cause() == safetyhook::RouteRetentionReason::EntryHeld);
            const bool residue = trampoline_residue || route_residue;
            const bool pin_references = route_retained && !residue;
            if (pin_references)
            {
                // A retained route preserves every provider reference.
                (void)impl.release();
                diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::HookManager);
            }
            else
            {
                impl.reset();
            }
            if (residue)
            {
                diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::HookResidue);
            }
            if (has_mid_slot && !pin_references)
            {
                DetourModKit::detail::release_mid_adapter_slot(mid_slot);
            }
            if (ledger != nullptr)
            {
                (void)ledger->release_hook(target, ledger_id);
            }
            if (pin_references)
            {
                (void)log().try_log(
                    LogLevel::Warning,
                    "hook: '{}' at 0x{:0{}X} retained its executable route at teardown. "
                    "The module reference remains held. Reason: {}.{}",
                    name,
                    target,
                    sizeof(std::uintptr_t) * 2,
                    retention_reason,
                    refusal.view()
                );
            }
            if (residue)
            {
                (void)log().try_log(
                    LogLevel::Info,
                    "hook: '{}' at 0x{:0{}X} restored its target and kept its {}: {}.{}",
                    name,
                    target,
                    sizeof(std::uintptr_t) * 2,
                    route_residue ? "route" : "trampoline",
                    retention_reason,
                    refusal.view()
                );
            }
            if (pin_references)
            {
                return hook::TeardownOutcome::Pinned;
            }
            DetourModKit::detail::release_module_ref(self_ref, diagnostics::ModulePinReason::Hook);
            return hook::TeardownOutcome::Restored;
        }

#if defined(DMK_ENABLE_TEST_SEAMS)
        /** @brief Fires the publication probe after @p step is complete. */
        void note_publish_step(DetourModKit::detail::HookPublishStep step)
        {
            if (auto *probe = DetourModKit::detail::g_hook_publish_probe)
            {
                probe(step);
            }
        }
#endif

        /**
         * @brief Checks the backend steal window immediately before the patch and releases @p ledger_id on failure.
         * @details The self-reference acquire takes the loader lock exactly when another thread can complete an unload.
         * @warning This check narrows the window but does not close it (see hook_fault_boundary.hpp). It provides error
         *          attribution, not a safety property.
         */
        std::optional<Error>
        revalidate_before_patch(std::uintptr_t target, std::uint64_t ledger_id, const char *where) noexcept
        {
            const detail::TargetWindowResult window = detail::validate_backend_steal_window(target);
            if (window.verdict == detail::TargetWindowVerdict::Ok)
            {
                return std::nullopt;
            }
            (void)DetourModKit::detail::HookLedger::instance().release_hook(target, ledger_id);
            return Error{
                window.verdict == detail::TargetWindowVerdict::Unreadable ? ErrorCode::ReadFaulted
                                                                          : ErrorCode::TargetPrologueUnsafe,
                where,
                window.detail
            };
        }

        /// Runs the inline_at entry checks, then resolves and reserves the target through @ref preflight_target.
        [[nodiscard]] Result<PreflightResult>
        preflight_inline_request(const hook::InlineRequest &request, const void *detour) noexcept
        {
            if (std::optional<Error> vetoed = hook::refuse_on_loader_lock("hook::inline_at"))
            {
                return std::unexpected(*vetoed);
            }
#if defined(DMK_ENABLE_TEST_SEAMS)
            hook::note_loader_veto_passed(DetourModKit::detail::HookLoaderEntry::InlineAt);
#endif
            if (request.name.empty())
            {
                return std::unexpected(Error{ErrorCode::InvalidArg, "hook::inline_at"});
            }
            if (detour == nullptr)
            {
                return std::unexpected(Error{ErrorCode::InvalidDetourFunction, "hook::inline_at"});
            }
            return preflight_target(request.target, request.options, request.name, "hook::inline_at");
        }

        /// Runs the mid_at entry checks, then resolves and reserves the target through @ref preflight_target.
        [[nodiscard]] Result<PreflightResult>
        preflight_mid_request(const hook::MidRequest &request, hook::MidHookFn detour) noexcept
        {
            if (std::optional<Error> vetoed = hook::refuse_on_loader_lock("hook::mid_at"))
            {
                return std::unexpected(*vetoed);
            }
#if defined(DMK_ENABLE_TEST_SEAMS)
            hook::note_loader_veto_passed(DetourModKit::detail::HookLoaderEntry::MidAt);
#endif
            if (request.name.empty())
            {
                return std::unexpected(Error{ErrorCode::InvalidArg, "hook::mid_at"});
            }
            if (detour == nullptr)
            {
                return std::unexpected(Error{ErrorCode::InvalidDetourFunction, "hook::mid_at"});
            }
            return preflight_target(request.target, request.options, request.name, "hook::mid_at");
        }

        /// Claims a mid-adapter slot for mid_at and rolls back the @p ledger_id reservation on failure.
        [[nodiscard]] Result<std::size_t>
        claim_mid_adapter_slot_or_roll_back_reservation(std::uintptr_t target, std::uint64_t ledger_id) noexcept
        {
            const DetourModKit::detail::MidSlotClaim claim = DetourModKit::detail::claim_mid_adapter_slot();
            if (claim.status == DetourModKit::detail::MidSlotClaimStatus::EntryIndexUnavailable)
            {
                (void)DetourModKit::detail::HookLedger::instance().release_hook(target, ledger_id);
                return std::unexpected(Error{ErrorCode::SystemCallFailed, "hook::mid_at", claim.system_error});
            }
            if (claim.status != DetourModKit::detail::MidSlotClaimStatus::Claimed)
            {
                (void)DetourModKit::detail::HookLedger::instance().release_hook(target, ledger_id);
                return std::unexpected(Error{ErrorCode::MidHookCapacityExhausted, "hook::mid_at", target});
            }
            return claim.index;
        }

        /**
         * @brief Applies the VmtOptions policy of VmtHook::apply_to to the object's current vptr.
         * @details The caller holds the VMT object gate and the handle's method mutex. The caller resolves a vptr at
         *          its own clone base first, so a clone base here belongs to another VmtHook.
         * @return The refusal to return, or nullopt when the apply proceeds.
         */
        [[nodiscard]] std::optional<Error> check_vmt_apply_options(
            const hook::VmtOptions &options,
            std::uintptr_t current_vptr,
            std::string_view name,
            const void *object
        ) noexcept
        {
            if (options.fail_if_already_hooked || options.fail_on_non_function_pointer)
            {
                if (options.fail_if_already_hooked)
                {
                    if (DetourModKit::detail::HookLedger::instance().is_vmt_clone_base(current_vptr))
                    {
                        return Error{ErrorCode::HookAlreadyExists, "hook::vmt_apply", current_vptr};
                    }
                }
                if (options.fail_on_non_function_pointer)
                {
                    const std::optional<std::uintptr_t> slot0 =
                        DetourModKit::detail::guarded_read<std::uintptr_t>(current_vptr);
                    if (!slot0)
                    {
                        return Error{ErrorCode::InvalidObject, "hook::vmt_apply", current_vptr};
                    }
                    if (!looks_like_function_vmt_slot(*slot0))
                    {
                        return Error{ErrorCode::InvalidObject, "hook::vmt_apply", *slot0};
                    }
                }
            }
            else if (DetourModKit::detail::HookLedger::instance().is_vmt_clone_base(current_vptr))
            {
                // The permissive default permits a chain on a clone that another same-kit VmtHook owns. This copies its
                // hooked slots into the "original" snapshot of the applying handle, which creates a silent double hook.
                // Proceed per contract but warn.
                (void)log().try_log(
                    LogLevel::Warning,
                    "hook::vmt_apply: VMT hook '{}' targets object 0x{:0{}X} with vptr 0x{:0{}X}. Another DMK VMT "
                    "hook owns that clone. That clone's hooked slots become this hook's "
                    "original. Set VmtOptions::fail_if_already_hooked to refuse instead.",
                    name,
                    reinterpret_cast<std::uintptr_t>(object),
                    sizeof(std::uintptr_t) * 2,
                    current_vptr,
                    sizeof(std::uintptr_t) * 2
                );
            }
            return std::nullopt;
        }

        /**
         * @brief Applies the VmtOptions policy of vmt_for to the object's current vptr.
         * @details The caller holds the VMT object gate.
         * @return The refusal to return, or nullopt when the clone proceeds.
         */
        [[nodiscard]] std::optional<Error> check_vmt_for_options(
            const hook::VmtOptions &options,
            std::uintptr_t current_vptr,
            std::string_view name,
            const void *object
        ) noexcept
        {
            if (options.fail_if_already_hooked || options.fail_on_non_function_pointer)
            {
                if (options.fail_if_already_hooked &&
                    DetourModKit::detail::HookLedger::instance().is_vmt_clone_base(current_vptr))
                {
                    return Error{ErrorCode::HookAlreadyExists, "hook::vmt_for", current_vptr};
                }
                if (options.fail_on_non_function_pointer)
                {
                    const std::optional<std::uintptr_t> slot0 =
                        DetourModKit::detail::guarded_read<std::uintptr_t>(current_vptr);
                    if (!slot0)
                    {
                        return Error{ErrorCode::InvalidObject, "hook::vmt_for", current_vptr};
                    }
                    if (!looks_like_function_vmt_slot(*slot0))
                    {
                        return Error{ErrorCode::InvalidObject, "hook::vmt_for", *slot0};
                    }
                }
            }
            else if (DetourModKit::detail::HookLedger::instance().is_vmt_clone_base(current_vptr))
            {
                // For the permissive default, see the associated warning in check_vmt_apply_options. vmt_for creates
                // a fresh clone, so it needs no own-clone-base exclusion here.
                (void)log().try_log(
                    LogLevel::Warning,
                    "hook::vmt_for: VMT hook '{}' targets object 0x{:0{}X} with vptr 0x{:0{}X}. Another DMK VMT hook "
                    "owns that clone. That clone's hooked slots become this hook's "
                    "original. Set VmtOptions::fail_if_already_hooked to refuse instead.",
                    name,
                    reinterpret_cast<std::uintptr_t>(object),
                    sizeof(std::uintptr_t) * 2,
                    current_vptr,
                    sizeof(std::uintptr_t) * 2
                );
            }
            return std::nullopt;
        }

        /**
         * @brief Counts the callable slots that bound the vmt_for snapshot capture.
         * @details The caller holds the VMT object gate and the process coordinator (`[B-66]`).
         * @return A nonzero slot budget, or InvalidObject.
         */
        [[nodiscard]] Result<std::size_t>
        count_vmt_clone_budget(std::uintptr_t current_vptr, const void *object) noexcept
        {
            const std::optional<std::size_t> slot_budget = count_vmt_method_slots(current_vptr);
            if (!slot_budget)
            {
                return std::unexpected(
                    Error{ErrorCode::InvalidObject, "hook::vmt_for", reinterpret_cast<std::uintptr_t>(object)}
                );
            }
            // An engaged zero found no callable slot. The clone is unusable by construction.
            if (*slot_budget == 0)
            {
                return std::unexpected(Error{ErrorCode::InvalidObject, "hook::vmt_for", current_vptr});
            }
            return *slot_budget;
        }

        void log_vmt_coordinator_refusal(std::string_view name, const void *object) noexcept
        {
            (void)log().try_log(
                LogLevel::Warning,
                "hook::vmt_for: refused VMT hook '{}' on object 0x{:0{}X}: process coordinator unavailable or "
                "timed out.",
                name,
                reinterpret_cast<std::uintptr_t>(object),
                sizeof(std::uintptr_t) * 2
            );
        }

        /**
         * @brief Logs the created VMT hook and emits its Created event.
         * @details The caller must not hold the VMT object gate.
         */
        void
        report_vmt_hook_created(std::string_view created_name, std::uint64_t ledger_id, const void *object) noexcept
        {
            // This post-commit log is best-effort. Contain a format bad_alloc (see hook_method_raw).
            try
            {
                log().info(
                    "hook::vmt_for: created VMT hook '{}' on object {}.",
                    created_name,
                    format::format_address(reinterpret_cast<std::uintptr_t>(object))
                );
            }
            catch (...)
            {
            }
            emit_lifecycle(created_name, ledger_id, diagnostics::HookKind::Vmt, diagnostics::HookTransition::Created);
        }
    } // namespace

    namespace detail
    {
        BackendCoordinatorHold::BackendCoordinatorHold() noexcept
        {
            static_assert(
                sizeof(safetyhook::ProcessCoordinator) <= STORAGE_BYTES &&
                    alignof(safetyhook::ProcessCoordinator) <= alignof(void *),
                "BackendCoordinatorHold storage must fit the backend coordinator"
            );
            auto *const coordinator = ::new (static_cast<void *>(m_storage)) safetyhook::ProcessCoordinator();
            m_constructed = true;
            m_held = static_cast<bool>(*coordinator);
        }

        BackendCoordinatorHold::~BackendCoordinatorHold() noexcept
        {
            release();
        }

        void BackendCoordinatorHold::release() noexcept
        {
            if (!m_constructed)
            {
                return;
            }
            std::launder(reinterpret_cast<safetyhook::ProcessCoordinator *>(m_storage))->~ProcessCoordinator();
            m_constructed = false;
            m_held = false;
        }
    } // namespace detail

    namespace hook
    {
#if defined(DMK_ENABLE_TEST_SEAMS)
        Hook::Impl::~Impl() noexcept
        {
            DetourModKit::detail::note_hook_impl_destruction_for_test();
        }
#endif

        const std::shared_ptr<safetyhook::Allocator> &backend_allocator() noexcept
        {
            // Never-destroyed storage (`[B-47]`). The declaration states why the hold is never released. The backend
            // allocates its allocator, so a first-use failure publishes the latched empty hold (`[B-91]`).
            // Lifecycle.BackendAllocatorFirstUseOomFailsClosed pins the latch.
            alignas(
                std::shared_ptr<safetyhook::Allocator>
            ) static unsigned char storage[sizeof(std::shared_ptr<safetyhook::Allocator>)];
            static const std::shared_ptr<safetyhook::Allocator> *const allocator =
                []() noexcept -> const std::shared_ptr<safetyhook::Allocator> *
            {
                try
                {
                    return ::new (static_cast<void *>(storage))
                        std::shared_ptr<safetyhook::Allocator>(safetyhook::Allocator::global());
                }
                catch (...)
                {
                    return ::new (static_cast<void *>(storage)) std::shared_ptr<safetyhook::Allocator>();
                }
            }();
            return *allocator;
        }

        Hook::GateSlot &Hook::gate_slot() noexcept
        {
            return *std::launder(reinterpret_cast<GateSlot *>(m_gate_storage));
        }

        const Hook::GateSlot &Hook::gate_slot() const noexcept
        {
            return *std::launder(reinterpret_cast<const GateSlot *>(m_gate_storage));
        }

        // Hook is the RAII handle for one inline or mid hook.
        Hook::Hook(std::unique_ptr<Impl> impl, std::shared_ptr<CallGate> gate) noexcept : m_impl(std::move(impl))
        {
            ::new (static_cast<void *>(m_gate_storage)) GateSlot(std::move(gate));
        }

        Hook::Hook(Hook &&other) noexcept : m_impl(std::move(other.m_impl))
        {
            // std::atomic is not movable. exchange leaves the source's gate empty, so a moved-from handle is fully
            // disengaged and fails closed.
            ::new (static_cast<void *>(m_gate_storage))
                GateSlot(other.gate_slot().exchange(nullptr, std::memory_order_acq_rel));
        }

        Hook &Hook::operator=(Hook &&other) noexcept
        {
            if (this != &other)
            {
                // Adopt the current hook into a temporary whose ~Hook runs the loader-lock-aware teardown. A
                // concurrent call() that pinned this handle's gate keeps the old trampoline alive until it returns.
                Hook discard(std::move(*this));
                m_impl = std::move(other.m_impl);
                gate_slot().store(
                    other.gate_slot().exchange(nullptr, std::memory_order_acq_rel),
                    std::memory_order_release
                );
            }
            return *this;
        }

        Hook::~Hook() noexcept
        {
            (void)detail::HookAccess::teardown(*this, detail::CountedDrainProof::Required);
        }

        TeardownOutcome detail::HookAccess::teardown(
            Hook &hook,
            CountedDrainProof proof,
            std::vector<DeferredRestore> *deferred
        ) noexcept
        {
            std::unique_ptr<Hook::Impl> &impl = hook.m_impl;
            // Take the gate reference out for the complete teardown. A pinned caller keeps the gate alive through its
            // own reference. A null callable below makes a late caller fail closed. The slot itself is never
            // destroyed, so a call() that races this teardown reads a valid null word.
            std::shared_ptr<Hook::CallGate> gate = hook.gate_slot().exchange(nullptr, std::memory_order_acq_rel);
            if (!impl)
            {
                return TeardownOutcome::Empty;
            }

            // Tombstone the mid-hook adapter before any teardown decision below. A late entrant exits at the adapter's
            // second live check. A pinned stub then becomes inert instead of a call to a destroyed owner. Inline hooks
            // have no slot. Their detour is the user function.
            const std::size_t mid_slot = impl->mid_slot;
            const bool has_mid_slot = mid_slot < DetourModKit::detail::MID_ADAPTER_CAPACITY;
            if (has_mid_slot)
            {
                DetourModKit::detail::mid_adapter_slots()[mid_slot].live.store(false, std::memory_order_seq_cst);
            }

            // Loader-lock leaf discipline forbids a prologue restore, a drain, or backend destruction under the loader
            // lock. Each can deadlock, so leak the Impl instead. The detour stays reachable, so its module reference
            // stays held.
            if (!DetourModKit::detail::blocking_teardown_permitted())
            {
                diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::HookManager);
                (void)impl.release();
                return TeardownOutcome::Pinned;
            }

            const DetourModKit::detail::MidRundown mid_rundown =
                has_mid_slot
                    ? DetourModKit::detail::run_down_mid_slot(DetourModKit::detail::mid_adapter_slots()[mid_slot])
                    : DetourModKit::detail::MidRundown::Drained;

            const std::uintptr_t target = impl->target;
            const std::uint64_t ledger_id = impl->ledger_id;
            const diagnostics::HookKind kind =
                impl->is_inline ? diagnostics::HookKind::Inline : diagnostics::HookKind::Mid;
            // Capture the armed state before the gate block below forces status to Disabled. Otherwise, the Removed
            // emission leaves the enable armed unit on the tally forever.
            const bool was_active = impl->status.load(std::memory_order_acquire) == HookState::Active;
            // Copy the name out before reset() destroys its storage. The copy can throw under OOM inside a noexcept
            // destructor, so contain it and degrade to an empty name.
            std::string name;
            try
            {
                name = impl->name;
            }
            catch (...)
            {
            }

            // Serialize with any in-flight call() through the shared gate. A caller that owns the lock drains to
            // completion. A caller with only a pin reads the null callable under the same mutex and returns the
            // inactive default.
            if (gate)
            {
                std::unique_lock<std::recursive_mutex> guard = hook.acquire_call_lock(gate.get());
                if (!guard.owns_lock())
                {
                    // An unowned guard makes restore safety unprovable. Leak the backend instead of a free of a
                    // trampoline that a guarded caller can still use.
                    diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::HookManager);
                    (void)impl.release();
                    return TeardownOutcome::Pinned;
                }
                gate->callable = nullptr;
                impl->status.store(HookState::Disabled, std::memory_order_release);
            }

            // A counted detour drains before the layer decision, so the wait holds no ledger slot (`[B-106]`).
            if (impl->counted && proof == CountedDrainProof::Required)
            {
                if (const char *const blocked = drain_counted_hook(impl->backend, *impl->counted))
                {
                    return pin_backend_with_live_detour(impl, nullptr, name, target, ledger_id, kind, blocked);
                }
            }

            // Decide restore or retirement under this target's install-serialization slot. The slot makes the
            // decision atomic against a concurrent same-target install. Only the newest layer restores. A newer layer
            // relocated this hook's jump, so a lower layer and a claimed position retire by bypass (`[B-104]`).
            auto &ledger = DetourModKit::detail::HookLedger::instance();
            const std::size_t newer = ledger.acquire_target_slot(target, ledger_id);
            if (newer == DetourModKit::detail::HookLedger::SLOT_UNAVAILABLE)
            {
                return pin_backend_with_live_detour(
                    impl,
                    &ledger,
                    name,
                    target,
                    ledger_id,
                    kind,
                    "the hook ledger cannot decide the layer order"
                );
            }
            if (newer > 0 || DetourModKit::detail::backend_claimed(impl->backend))
            {
                return retire_by_vacate(
                    impl,
                    ledger,
                    name,
                    target,
                    ledger_id,
                    kind,
                    was_active,
                    mid_rundown,
                    has_mid_slot,
                    mid_slot,
                    RetirementCause{.newer_layers = newer}
                );
            }

            RetirementCause cause{};
            const TeardownRestore restore =
                restore_target_or_pin_backend(impl, ledger, name, target, ledger_id, kind, cause);
            if (restore == TeardownRestore::Pinned)
            {
                return TeardownOutcome::Pinned;
            }
            if (restore == TeardownRestore::Retire)
            {
                return retire_by_vacate(
                    impl,
                    ledger,
                    name,
                    target,
                    ledger_id,
                    kind,
                    was_active,
                    mid_rundown,
                    has_mid_slot,
                    mid_slot,
                    cause
                );
            }

            if (!drain_route_or_retain_backend(impl, ledger, name, target, ledger_id, kind, was_active, mid_rundown))
            {
                return TeardownOutcome::Pinned;
            }

            if (has_mid_slot &&
                !DetourModKit::detail::drain_mid_adapter_entries(DetourModKit::detail::mid_adapter_slots()[mid_slot]))
            {
                retain_backend_for_busy_adapter(impl, ledger, name, target, ledger_id, kind, was_active);
                return TeardownOutcome::Pinned;
            }

            // The reserved capacity keeps the push free of allocation.
            const bool defer = deferred != nullptr && deferred->size() < deferred->capacity();
            if (DetourModKit::detail::release_backend(impl->backend, defer))
            {
                (void)ledger.release_hook(target, ledger_id);
                deferred->push_back(
                    DeferredRestore{
                        .impl = std::move(impl),
                        .name = std::move(name),
                        .was_active = was_active,
                    }
                );
                return TeardownOutcome::Deferred;
            }
            const TeardownOutcome reclaimed =
                reclaim_restored_backend(impl, &ledger, name, target, ledger_id, has_mid_slot, mid_slot);
            emit_lifecycle(
                name,
                ledger_id,
                kind,
                diagnostics::HookTransition::Removed,
                RemovalPopulationState{
                    .was_active = was_active,
                }
            );
            return reclaimed;
        }

        TeardownOutcome detail::HookAccess::finish_deferred_restore(DeferredRestore &restore) noexcept
        {
            const std::uintptr_t target = restore.impl->target;
            const std::uint64_t ledger_id = restore.impl->ledger_id;
            const std::size_t mid_slot = restore.impl->mid_slot;
            const diagnostics::HookKind kind =
                restore.impl->is_inline ? diagnostics::HookKind::Inline : diagnostics::HookKind::Mid;
            const TeardownOutcome reclaimed = reclaim_restored_backend(
                restore.impl,
                nullptr,
                restore.name,
                target,
                ledger_id,
                mid_slot < DetourModKit::detail::MID_ADAPTER_CAPACITY,
                mid_slot
            );
            emit_lifecycle(
                restore.name,
                ledger_id,
                kind,
                diagnostics::HookTransition::Removed,
                RemovalPopulationState{
                    .was_active = restore.was_active,
                }
            );
            return reclaimed;
        }

        Hook::operator bool() const noexcept
        {
            return m_impl != nullptr;
        }

        std::string_view Hook::name() const noexcept
        {
            return m_impl ? std::string_view{m_impl->name} : std::string_view{};
        }

        bool Hook::is_enabled() const noexcept
        {
            const std::shared_ptr<CallGate> gate = gate_slot().load(std::memory_order_acquire);
            if (!gate)
            {
                return false;
            }
            std::unique_lock<std::recursive_mutex> guard = acquire_call_lock(gate.get());
            if (!guard.owns_lock() || !m_impl)
            {
                return false;
            }
            // Both the published state and the reconciled backend view must agree. The gate serializes this read
            // with every backend flag update.
            return m_impl->status.load(std::memory_order_acquire) == HookState::Active &&
                   backend_value_or(
                       m_impl->backend,
                       false,
                       [](auto &backend) noexcept { return static_cast<bool>(backend) && backend.enabled(); }
                   );
        }

        void *Hook::original_address() const noexcept
        {
            // The original<Fn>() path uses no gate or atomic shared-pointer load. The caller guarantees that the hook
            // outlives the call.
            return m_impl ? inline_trampoline(m_impl->backend) : nullptr;
        }

        std::shared_ptr<Hook::CallGate> Hook::pin_call_gate() const noexcept
        {
            // Copy the gate reference atomically into a strong local. call() can then keep the trampoline and mutex
            // alive across a concurrent teardown that drops the handle's own reference.
            return gate_slot().load(std::memory_order_acquire);
        }

        std::unique_lock<std::recursive_mutex> Hook::acquire_call_lock(CallGate *gate) const noexcept
        {
            try
            {
                return std::unique_lock<std::recursive_mutex>(gate->mutex);
            }
            catch (...)
            {
                // recursive_mutex::lock can throw std::system_error. Fail closed: an unowned lock makes call()
                // return the inactive default.
                return std::unique_lock<std::recursive_mutex>{};
            }
        }

        void *Hook::active_trampoline(CallGate *gate) const noexcept
        {
            // Every writer publishes gate->callable under the mutex the caller already holds, so this observes the
            // live trampoline or nullptr, never a stale pointer.
            return gate->callable;
        }

        void Hook::release() noexcept
        {
            if (!m_impl)
            {
                return;
            }
            // Leak the backend hook intentionally: it stays installed for the process lifetime and the ledger entry
            // stays so is_target_hooked still reports it. A gate clear disengages the handle, which matches the
            // moved-from contract. The ledger records it like every defensive pin in ~Hook.
            diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::HookManager);
            (void)m_impl.release();
            gate_slot().store(nullptr, std::memory_order_release);
        }

        Result<Hook> detail::HookAccess::install_inline(
            InlineRequest request,
            std::uintptr_t target,
            std::uint64_t ledger_id,
            void *destination,
            std::optional<CountedThunk> counted
        )
        {
            const std::shared_ptr<safetyhook::Allocator> &allocator = backend_allocator();
            if (!allocator)
            {
                (void)DetourModKit::detail::HookLedger::instance().release_hook(target, ledger_id);
                return std::unexpected(Error{ErrorCode::AllocatorNotAvailable, "hook::inline_at"});
            }
            ModuleRefGuard self_ref(acquire_hook_self_ref());
            if (self_ref.get() == nullptr)
            {
                // Capture the acquire's last-error before release_hook can clobber it (error.hpp documents
                // SystemCallFailed's detail = GetLastError()).
                const DWORD acquire_error = ::GetLastError();
                (void)DetourModKit::detail::HookLedger::instance().release_hook(target, ledger_id);
                return std::unexpected(Error{ErrorCode::SystemCallFailed, "hook::inline_at", acquire_error});
            }
            if (const std::optional<Error> stale = revalidate_before_patch(target, ledger_id, "hook::inline_at"))
            {
                return std::unexpected(*stale);
            }
            try
            {
                // StartDisabled makes this an install transaction. The detour stays unreachable while the fallible
                // steps below publish the caller state. No fault boundary wraps this code. See
                // hook_fault_boundary.hpp.
                auto created = safetyhook::InlineHook::create(
                    allocator,
                    reinterpret_cast<void *>(target),
                    destination,
                    safetyhook::InlineHook::StartDisabled,
                    position_claim_for(request.name)
                );
                if (!created)
                {
                    log().error(
                        "hook::inline_at: backend create failed for '{}' at {}: {}",
                        request.name,
                        format::format_address(target),
                        backend_error_string(created.error())
                    );
                    (void)DetourModKit::detail::HookLedger::instance().release_hook(target, ledger_id);
                    return std::unexpected(Error{ErrorCode::BackendFailed, "hook::inline_at", target});
                }
                auto backend_hook = std::move(created.value());
#if defined(DMK_ENABLE_TEST_SEAMS)
                note_publish_step(DetourModKit::detail::HookPublishStep::BackendCreated);
#endif
                const bool claimed = backend_hook.claimed();
                auto impl = std::make_unique<Hook::Impl>(
                    std::move(backend_hook),
                    std::move(request.name),
                    target,
                    ledger_id,
                    HookState::Disabled
                );
                impl->bypassed = claimed;
                impl->counted = counted;
#if defined(DMK_ENABLE_TEST_SEAMS)
                note_publish_step(DetourModKit::detail::HookPublishStep::ImplConstructed);
#endif
                // The gate starts null-callable, exactly as disable() leaves it. enable() publishes the
                // trampoline once the target is armed.
                auto gate = std::make_shared<Hook::CallGate>();
#if defined(DMK_ENABLE_TEST_SEAMS)
                note_publish_step(DetourModKit::detail::HookPublishStep::GatePublished);
#endif
                const std::string_view created_name = impl->name;
                if (!DetourModKit::detail::HookLedger::instance().commit_hook(target, ledger_id))
                {
                    (void)DetourModKit::detail::HookLedger::instance().release_hook(target, ledger_id);
                    return std::unexpected(Error{ErrorCode::OutOfMemory, "hook::inline_at", target});
                }
                log().info(
                    "hook::inline_at: created inline hook '{}' at {} (disabled).",
                    created_name,
                    format::format_address(target)
                );
                if (claimed)
                {
                    note_position_claim(created_name, target);
                }
#if defined(DMK_ENABLE_TEST_SEAMS)
                note_publish_step(DetourModKit::detail::HookPublishStep::LedgerCommitted);
#endif
                emit_lifecycle(
                    created_name,
                    ledger_id,
                    diagnostics::HookKind::Inline,
                    diagnostics::HookTransition::Created
                );
                // Hand the module reference to the Impl only after completion of every fallible setup step.
                impl->self_ref = self_ref.release();
                return make(std::move(impl), std::move(gate));
            }
            catch (const std::bad_alloc &)
            {
                (void)DetourModKit::detail::HookLedger::instance().release_hook(target, ledger_id);
                return std::unexpected(Error{ErrorCode::OutOfMemory, "hook::inline_at", target});
            }
            catch (...)
            {
                (void)DetourModKit::detail::HookLedger::instance().release_hook(target, ledger_id);
                return std::unexpected(Error{ErrorCode::UnknownError, "hook::inline_at", target});
            }
        }

        namespace detail
        {
            Result<Hook> inline_at_raw(InlineRequest request, void *detour)
            {
                Result<PreflightResult> preflight = preflight_inline_request(request, detour);
                if (!preflight)
                {
                    return std::unexpected(preflight.error());
                }
                return HookAccess::install_inline(
                    std::move(request),
                    preflight->address,
                    preflight->ledger_id,
                    detour,
                    std::nullopt
                );
            }

            Result<Hook> inline_at_counted(InlineRequest request, CountedInstall install)
            {
                Result<PreflightResult> preflight = preflight_inline_request(request, install.entry);
                if (!preflight)
                {
                    return std::unexpected(preflight.error());
                }
                const std::expected<CountedThunkShape, const char *> shape = inspect_counted_thunk(install.entry);
                if (!shape || install.block == nullptr)
                {
                    log().error(
                        "hook::inline_at: the counted thunk of '{}' has a shape that the drain proof cannot cover: {}.",
                        request.name,
                        shape ? "it has no counters" : shape.error()
                    );
                    (void)DetourModKit::detail::HookLedger::instance().release_hook(
                        preflight->address,
                        preflight->ledger_id
                    );
                    return std::unexpected(Error{ErrorCode::InvalidDetourFunction, "hook::inline_at"});
                }
                if (shape->helper_calls != 0)
                {
                    log().warning(
                        "hook::inline_at: the counted thunk of '{}' calls {} helper(s) outside its counted window, so "
                        "its drain also reads thread stacks. A stale stack copy of a helper return can keep a "
                        "retirement Busy.",
                        request.name,
                        shape->helper_calls
                    );
                }
                CountedThunk thunk = shape->thunk;
                thunk.block = install.block;
                return HookAccess::install_inline(
                    std::move(request),
                    preflight->address,
                    preflight->ledger_id,
                    thunk.range.begin,
                    thunk
                );
            }
        } // namespace detail

        Result<Hook> mid_at(MidRequest request, MidHookFn detour)
        {
            Result<PreflightResult> preflight = preflight_mid_request(request, detour);
            if (!preflight)
            {
                return std::unexpected(preflight.error());
            }
            const std::uintptr_t target = preflight->address;
            // Every failure path below rolls back this reservation. Success commits it after all fallible setup.
            const std::uint64_t ledger_id = preflight->ledger_id;

            const std::shared_ptr<safetyhook::Allocator> &allocator = backend_allocator();
            if (!allocator)
            {
                (void)DetourModKit::detail::HookLedger::instance().release_hook(target, ledger_id);
                return std::unexpected(Error{ErrorCode::AllocatorNotAvailable, "hook::mid_at"});
            }
            ModuleRefGuard self_ref(acquire_hook_self_ref());
            if (self_ref.get() == nullptr)
            {
                // Capture the acquire's last-error before release_hook can clobber it (see inline_at_raw).
                const DWORD acquire_error = ::GetLastError();
                (void)DetourModKit::detail::HookLedger::instance().release_hook(target, ledger_id);
                return std::unexpected(Error{ErrorCode::SystemCallFailed, "hook::mid_at", acquire_error});
            }
            if (const std::optional<Error> stale = revalidate_before_patch(target, ledger_id, "hook::mid_at"))
            {
                return std::unexpected(*stale);
            }
            // One adapter exists per live mid hook. MidAdapterSlotGuard releases the slot on every failure path below.
            // No adapter entry occurred because StartDisabled leaves the target unpatched until enable().
            const Result<std::size_t> claim = claim_mid_adapter_slot_or_roll_back_reservation(target, ledger_id);
            if (!claim)
            {
                return std::unexpected(claim.error());
            }
            const std::size_t slot_index = *claim;
            MidAdapterSlotGuard slot_guard(slot_index);
            DetourModKit::detail::MidAdapterSlot &slot = DetourModKit::detail::mid_adapter_slots()[slot_index];
            slot.target.store(target, std::memory_order_relaxed);
            slot.detour.store(detour, std::memory_order_relaxed);
            slot.contained_exceptions.store(0, std::memory_order_relaxed);
            // Publish the callback before the adapter address reaches the backend.
            slot.live.store(true, std::memory_order_release);
            try
            {
                // This is the StartDisabled install transaction. See inline_at_raw and hook_fault_boundary.hpp. The
                // destination is the pool slot_index adapter, a real void(safetyhook::Context&).
                auto created = safetyhook::MidHook::create(
                    allocator,
                    reinterpret_cast<void *>(target),
                    DetourModKit::detail::MID_ADAPTER_TABLE[slot_index],
                    safetyhook::MidHook::StartDisabled,
                    position_claim_for(request.name)
                );
                if (!created)
                {
                    log().error(
                        "hook::mid_at: backend create failed for '{}' at {}: {}",
                        request.name,
                        format::format_address(target),
                        backend_error_string(created.error())
                    );
                    (void)DetourModKit::detail::HookLedger::instance().release_hook(target, ledger_id);
                    return std::unexpected(Error{ErrorCode::BackendFailed, "hook::mid_at", target});
                }
                auto backend_hook = std::move(created.value());
#if defined(DMK_ENABLE_TEST_SEAMS)
                note_publish_step(DetourModKit::detail::HookPublishStep::BackendCreated);
#endif
                const bool claimed = backend_hook.claimed();
                auto impl = std::make_unique<Hook::Impl>(
                    std::move(backend_hook),
                    std::move(request.name),
                    target,
                    ledger_id,
                    HookState::Disabled
                );
                impl->bypassed = claimed;
#if defined(DMK_ENABLE_TEST_SEAMS)
                note_publish_step(DetourModKit::detail::HookPublishStep::ImplConstructed);
#endif
                // A mid hook gate is null-callable for life. It still serializes enable, disable, and teardown.
                auto gate = std::make_shared<Hook::CallGate>();
#if defined(DMK_ENABLE_TEST_SEAMS)
                note_publish_step(DetourModKit::detail::HookPublishStep::GatePublished);
#endif
                const std::string_view created_name = impl->name;
                if (!DetourModKit::detail::HookLedger::instance().commit_hook(target, ledger_id))
                {
                    (void)DetourModKit::detail::HookLedger::instance().release_hook(target, ledger_id);
                    return std::unexpected(Error{ErrorCode::OutOfMemory, "hook::mid_at", target});
                }
                log().info(
                    "hook::mid_at: created mid hook '{}' at {} (disabled).",
                    created_name,
                    format::format_address(target)
                );
                if (claimed)
                {
                    note_position_claim(created_name, target);
                }
#if defined(DMK_ENABLE_TEST_SEAMS)
                note_publish_step(DetourModKit::detail::HookPublishStep::LedgerCommitted);
#endif
                emit_lifecycle(
                    created_name,
                    ledger_id,
                    diagnostics::HookKind::Mid,
                    diagnostics::HookTransition::Created
                );
                // Hand the module reference and adapter slot to the Impl. Teardown owns both after this point.
                impl->self_ref = self_ref.release();
                impl->mid_slot = slot_guard.release();
                return Hook(std::move(impl), std::move(gate));
            }
            catch (const std::bad_alloc &)
            {
                (void)DetourModKit::detail::HookLedger::instance().release_hook(target, ledger_id);
                return std::unexpected(Error{ErrorCode::OutOfMemory, "hook::mid_at", target});
            }
            catch (...)
            {
                (void)DetourModKit::detail::HookLedger::instance().release_hook(target, ledger_id);
                return std::unexpected(Error{ErrorCode::UnknownError, "hook::mid_at", target});
            }
        }

        Result<std::vector<InstallOutcome>> install_all(std::span<const HookSpec> table) noexcept
        {
            if (std::optional<Error> vetoed = refuse_on_loader_lock("hook::install_all"))
            {
                return std::unexpected(*vetoed);
            }
#if defined(DMK_ENABLE_TEST_SEAMS)
            note_loader_veto_passed(DetourModKit::detail::HookLoaderEntry::InstallAll);
#endif
            // InstallRollback removes a partial install newest-first, so every layered row restores. A vector's
            // front-to-back destruction leaves lower rows as residue. InstallRollback handles mandatory misses and
            // exceptions unless commit() moves the rows out.
            class InstallRollback
            {
            public:
                InstallRollback() = default;
                InstallRollback(const InstallRollback &) = delete;
                InstallRollback &operator=(const InstallRollback &) = delete;
                ~InstallRollback()
                {
                    while (!m_rows.empty())
                    {
                        m_rows.pop_back();
                    }
                }

                [[nodiscard]] std::vector<InstallOutcome> &rows() noexcept { return m_rows; }
                [[nodiscard]] std::vector<InstallOutcome> commit() noexcept { return std::move(m_rows); }

            private:
                std::vector<InstallOutcome> m_rows;
            };

            try
            {
                InstallRollback rollback;
                rollback.rows().reserve(table.size());
                for (const HookSpec &spec : table)
                {
                    // The OwnedScanRequest copy preserves the caller table entries for install_all. Each row's Options
                    // value carries its install policy.
                    Target target = spec.m_target;
                    Result<Hook> installed = std::holds_alternative<InlineDetour>(spec.m_detour)
                                                 ? detail::inline_at_raw(
                                                       InlineRequest{spec.m_name, std::move(target), spec.m_options},
                                                       std::get<InlineDetour>(spec.m_detour).fn
                                                   )
                                                 : mid_at(
                                                       MidRequest{spec.m_name, std::move(target), spec.m_options},
                                                       std::get<MidHookFn>(spec.m_detour)
                                                   );

                    if (!installed && spec.m_severity == Severity::Mandatory)
                    {
                        // Fail fast: ~InstallRollback unhooks every already-installed row newest-first before the
                        // error propagates.
                        return std::unexpected(installed.error());
                    }
                    rollback.rows().push_back(InstallOutcome{spec.m_name, spec.m_severity, std::move(installed)});
                }
                return rollback.commit();
            }
            catch (const std::bad_alloc &)
            {
                return std::unexpected(Error{ErrorCode::OutOfMemory, "hook::install_all"});
            }
            catch (...)
            {
                return std::unexpected(Error{ErrorCode::UnknownError, "hook::install_all"});
            }
        }

        bool is_target_hooked(Address target) noexcept
        {
            return DetourModKit::detail::HookLedger::instance().is_target_hooked(target.raw());
        }

        // VmtHook is the RAII handle for a cloned vtable and its object-level clone lifecycle.
        VmtHook::VmtHook(std::unique_ptr<Impl> impl) noexcept : m_impl(std::move(impl)) {}

        VmtHook::VmtHook(VmtHook &&other) noexcept : m_impl(std::move(other.m_impl)) {}

        VmtHook &VmtHook::operator=(VmtHook &&other) noexcept
        {
            if (this != &other)
            {
                VmtHook discard(std::move(*this));
                m_impl = std::move(other.m_impl);
            }
            return *this;
        }

        VmtHook::~VmtHook() noexcept
        {
            if (!m_impl)
            {
                return;
            }
            // Loader-lock leaf discipline requires an Impl leak instead of vptr restoration here. Its module reference
            // keeps the clone code pages mapped.
            if (!DetourModKit::detail::blocking_teardown_permitted())
            {
                diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::HookManager);
                (void)m_impl.release();
                return;
            }
            const std::uint64_t ledger_id = m_impl->ledger_id;
            // Copy the name out before reset destroys its storage. Contain an OOM exception and degrade to an empty
            // name (noexcept destructor).
            std::string name;
            try
            {
                name = m_impl->name;
            }
            catch (...)
            {
            }
            // Teardown restores every applied object before it releases the ledger entry per Hook::~Hook order. This
            // order prevents a race between a vmt_for or apply_to operation and clone removal.
            HMODULE self_ref = nullptr;
            {
                std::unique_lock<std::mutex> object_gate = acquire_vmt_object_lock();
                if (!object_gate.owns_lock())
                {
                    // Leak the Impl rather than restore vptrs without the gate.
                    diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::HookManager);
                    (void)m_impl.release();
                    return;
                }
                // Restore every object with known state. A different vptr can belong to a successor that recorded this
                // clone as its original. An unreadable or non-writable word is equally unsafe to overwrite.
                std::size_t unrestorable = 0;
                for (const auto &binding : m_impl->object_bindings)
                {
                    const DetourModKit::detail::ObjectWordResult word = DetourModKit::detail::validate_vmt_object_word(
                        reinterpret_cast<std::uintptr_t>(binding.object)
                    );
                    if (word.verdict != DetourModKit::detail::ObjectWordVerdict::Unreadable &&
                        word.vptr == binding.original_vptr)
                    {
                        continue;
                    }
                    if (word.verdict == DetourModKit::detail::ObjectWordVerdict::Ok &&
                        word.vptr == m_impl->cloned_vptr_base)
                    {
                        if (publish_vmt_object_word(binding.object, m_impl->cloned_vptr_base, binding.original_vptr))
                        {
                            continue;
                        }
                    }
                    ++unrestorable;
                }
                if (unrestorable > 0)
                {
                    const std::size_t object_count = m_impl->object_bindings.size();
                    diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::HookManager);
                    (void)m_impl.release();
                    object_gate.unlock();
#if defined(DMK_ENABLE_TEST_SEAMS)
                    if (auto *probe = DetourModKit::detail::g_vmt_teardown_warning_probe)
                    {
                        probe();
                    }
#endif
                    (void)log().try_log(
                        LogLevel::Warning,
                        "hook::~VmtHook: VMT hook '{}' destroyed while {} of its {} object(s) could "
                        "not be provably restored to their original vtable; leaked this clone to "
                        "avoid a vtable use-after-free. Destroy VMT hooks newest-first to restore "
                        "the original table.",
                        std::string_view{name},
                        unrestorable,
                        object_count
                    );
                    return;
                }
                self_ref = static_cast<HMODULE>(m_impl->self_ref);
                m_impl.reset();
            }
            // Release outside the object gate: FreeLibrary takes the loader lock, which must not nest inside the
            // process-wide VMT gate.
            DetourModKit::detail::release_module_ref(self_ref, diagnostics::ModulePinReason::Hook);
            DetourModKit::detail::HookLedger::instance().release_vmt(ledger_id);
            // A VMT hook is live from creation and has no enable/disable transition, so it is always counted armed.
            emit_lifecycle(
                name,
                ledger_id,
                diagnostics::HookKind::Vmt,
                diagnostics::HookTransition::Removed,
                RemovalPopulationState{
                    .was_active = true,
                }
            );
        }

        VmtHook::operator bool() const noexcept
        {
            return m_impl != nullptr;
        }

        std::string_view VmtHook::name() const noexcept
        {
            return m_impl ? std::string_view{m_impl->name} : std::string_view{};
        }

        Result<void> VmtHook::apply_to(void *object, VmtOptions options)
        {
            if (std::optional<Error> vetoed = refuse_on_loader_lock("hook::vmt_apply"))
            {
                return std::unexpected(*vetoed);
            }
#if defined(DMK_ENABLE_TEST_SEAMS)
            note_loader_veto_passed(DetourModKit::detail::HookLoaderEntry::VmtApply);
#endif
            if (!m_impl)
            {
                return std::unexpected(Error{ErrorCode::InvalidHookState, "hook::vmt_apply"});
            }
            if (object == nullptr)
            {
                return std::unexpected(Error{ErrorCode::InvalidObject, "hook::vmt_apply"});
            }
            std::unique_lock<std::mutex> object_gate = acquire_vmt_object_lock();
            if (!object_gate.owns_lock())
            {
                return std::unexpected(Error{ErrorCode::UnknownError, "hook::vmt_apply"});
            }
            // Exclusive write keeps the policy decision and guarded swap atomic against this handle's readers. The
            // process-wide object gate serializes the vptr transition against other DMK VMT handles.
            std::unique_lock<DetourModKit::detail::SrwSharedMutex> gate(m_impl->method_mutex);
            // Object-word validation is not a policy: every option set requires a capturable writable word, and the
            // later guarded compare-exchange closes a protection/unmap race.
            const DetourModKit::detail::ObjectWordResult word =
                DetourModKit::detail::validate_vmt_object_word(reinterpret_cast<std::uintptr_t>(object));
            if (word.verdict != DetourModKit::detail::ObjectWordVerdict::Ok)
            {
                return std::unexpected(Error{ErrorCode::InvalidObject, "hook::vmt_apply", word.detail});
            }
            const std::uintptr_t current_vptr = word.vptr;
            // Locate this object's restoration binding before any policy branch. Teardown restores from the
            // binding. Refusal is the only outcome that keeps every recorded original true.
            const auto binding = std::find_if(
                m_impl->object_bindings.begin(),
                m_impl->object_bindings.end(),
                [object](const auto &entry) -> bool { return entry.object == object; }
            );
            const bool already_tracked = binding != m_impl->object_bindings.end();
            if (current_vptr == m_impl->cloned_vptr_base)
            {
                if (!already_tracked)
                {
                    // This handle holds no original vptr for this object. A new binding records the clone base as its
                    // own original, and teardown then frees the clone below it.
                    return std::unexpected(Error{ErrorCode::HookAlreadyExists, "hook::vmt_apply", current_vptr});
                }
                // If the object already uses this handle's clone, every policy treats the apply as a no-op.
                return {};
            }
            else if (already_tracked && current_vptr != binding->original_vptr)
            {
                // Another actor moved the object off the recorded vptr, usually through a newer layer. A new
                // publication displaces state that this binding does not name.
                return std::unexpected(Error{ErrorCode::HookAlreadyExists, "hook::vmt_apply", current_vptr});
            }
            if (const std::optional<Error> refused =
                    check_vmt_apply_options(options, current_vptr, m_impl->name, object))
            {
                return std::unexpected(*refused);
            }
            // Reserve the restoration binding before publication. Capacity growth after publication can throw with
            // the object already on the clone but absent from the state that teardown needs.
            if (!already_tracked)
            {
                try
                {
                    m_impl->object_bindings.reserve(m_impl->object_bindings.size() + 1);
                }
                catch (const std::bad_alloc &)
                {
                    return std::unexpected(Error{ErrorCode::OutOfMemory, "hook::vmt_apply"});
                }
            }
            if (!publish_vmt_object_word(object, current_vptr, m_impl->cloned_vptr_base))
            {
                return std::unexpected(
                    Error{ErrorCode::InvalidObject, "hook::vmt_apply", reinterpret_cast<std::uintptr_t>(object)}
                );
            }
            if (!already_tracked)
            {
                // The reserved capacity guarantees that this push cannot throw.
                m_impl->object_bindings.push_back({object, current_vptr});
            }
            return {};
        }

        Result<void> VmtHook::remove_from(void *object)
        {
            if (std::optional<Error> vetoed = refuse_on_loader_lock("hook::vmt_remove"))
            {
                return std::unexpected(*vetoed);
            }
#if defined(DMK_ENABLE_TEST_SEAMS)
            note_loader_veto_passed(DetourModKit::detail::HookLoaderEntry::VmtRemove);
#endif
            if (!m_impl)
            {
                return std::unexpected(Error{ErrorCode::InvalidHookState, "hook::vmt_remove"});
            }
            if (object == nullptr)
            {
                return std::unexpected(Error{ErrorCode::InvalidObject, "hook::vmt_remove"});
            }
            std::unique_lock<std::mutex> object_gate = acquire_vmt_object_lock();
            if (!object_gate.owns_lock())
            {
                return std::unexpected(Error{ErrorCode::UnknownError, "hook::vmt_remove"});
            }
            // The exclusive write prevents a race between unapply and an original() snapshot reader during transition.
            std::unique_lock<DetourModKit::detail::SrwSharedMutex> gate(m_impl->method_mutex);
            const auto binding = std::find_if(
                m_impl->object_bindings.begin(),
                m_impl->object_bindings.end(),
                [object](const auto &entry) -> bool { return entry.object == object; }
            );
            if (binding == m_impl->object_bindings.end())
            {
                return {};
            }

            // Keep the full binding if a successor still outranks this clone. A later rollback can return it here.
            const DetourModKit::detail::ObjectWordResult word =
                DetourModKit::detail::validate_vmt_object_word(reinterpret_cast<std::uintptr_t>(object));
            if (word.verdict == DetourModKit::detail::ObjectWordVerdict::Ok && word.vptr == m_impl->cloned_vptr_base)
            {
                // The re-read below is the authority: an object already at its original restores nothing yet must
                // still release its binding.
                (void)publish_vmt_object_word(object, m_impl->cloned_vptr_base, binding->original_vptr);
            }

            const std::optional<std::uintptr_t> after =
                DetourModKit::detail::guarded_read<std::uintptr_t>(reinterpret_cast<std::uintptr_t>(object));
            if (after && *after == binding->original_vptr)
            {
                m_impl->object_bindings.erase(binding);
            }
            return {};
        }

        Result<void> VmtHook::hook_method_raw(std::size_t index, void *detour)
        {
            if (std::optional<Error> vetoed = refuse_on_loader_lock("hook::vmt_hook_method"))
            {
                return std::unexpected(*vetoed);
            }
#if defined(DMK_ENABLE_TEST_SEAMS)
            note_loader_veto_passed(DetourModKit::detail::HookLoaderEntry::VmtHookMethod);
#endif
            if (!m_impl)
            {
                return std::unexpected(Error{ErrorCode::InvalidHookState, "hook::vmt_hook_method"});
            }
            if (detour == nullptr)
            {
                return std::unexpected(Error{ErrorCode::InvalidArg, "hook::vmt_hook_method"});
            }
            {
                // The map insert and backend slot patch must be atomic against a concurrent original() snapshot reader.
                // That reader traverses this same map under the shared read.
                std::unique_lock<DetourModKit::detail::SrwSharedMutex> gate(m_impl->method_mutex);
                if (index >= m_impl->method_count)
                {
                    return std::unexpected(Error{ErrorCode::InvalidArg, "hook::vmt_hook_method", index});
                }
                if (m_impl->method_hooks.contains(index))
                {
                    // One method hook exists per slot. A second hook reads the first detour as the "original" and
                    // creates a silent mod chain.
                    return std::unexpected(Error{ErrorCode::MethodAlreadyHooked, "hook::vmt_hook_method", index});
                }
                auto node = m_impl->method_hooks.end();
                try
                {
                    // Allocate the map node before the backend stores the slot. No allocation can then fail over a
                    // live slot, and original() resolves from the instant a detour can run. The original comes from
                    // the clone, whose slot index matches the method index.
                    node = m_impl->method_hooks.try_emplace(index).first;
                    node->second.original = reinterpret_cast<void *const *>(m_impl->cloned_vptr_base)[index];
                    // A void* detour installs the same 8 bytes as a typed pointer. hook_method<Fn> vetted the ABI.
                    auto created = m_impl->backend.hook_method(index, detour);
                    if (!created)
                    {
                        m_impl->method_hooks.erase(node);
                        return std::unexpected(Error{ErrorCode::BackendFailed, "hook::vmt_hook_method", index});
                    }
                    node->second.backend = std::move(created.value());
                }
                catch (const std::bad_alloc &)
                {
                    if (node != m_impl->method_hooks.end())
                    {
                        m_impl->method_hooks.erase(node);
                    }
                    return std::unexpected(Error{ErrorCode::OutOfMemory, "hook::vmt_hook_method", index});
                }
                catch (...)
                {
                    if (node != m_impl->method_hooks.end())
                    {
                        m_impl->method_hooks.erase(node);
                    }
                    return std::unexpected(Error{ErrorCode::BackendFailed, "hook::vmt_hook_method", index});
                }
            }
            // This post-commit best-effort log contains a format bad_alloc, so it cannot flip a committed install into
            // a failure.
            try
            {
                log().info(
                    "hook::hook_method: hooked method index {} on VMT hook '{}'.",
                    index,
                    std::string_view{m_impl->name}
                );
            }
            catch (...)
            {
            }
            return {};
        }

        void *VmtHook::method_original_address(std::size_t index) const noexcept
        {
            if (!m_impl)
            {
                return nullptr;
            }
            // A shared read serializes the snapshot against exclusive writers. The copied pointer is then called
            // lock-free by contract (see original()).
            std::shared_lock<DetourModKit::detail::SrwSharedMutex> gate(m_impl->method_mutex);
            const auto it = m_impl->method_hooks.find(index);
            if (it == m_impl->method_hooks.end())
            {
                return nullptr;
            }
            return it->second.original;
        }

        Result<void> VmtHook::remove_method(std::size_t index)
        {
            if (std::optional<Error> vetoed = refuse_on_loader_lock("hook::vmt_remove_method"))
            {
                return std::unexpected(*vetoed);
            }
#if defined(DMK_ENABLE_TEST_SEAMS)
            note_loader_veto_passed(DetourModKit::detail::HookLoaderEntry::VmtRemoveMethod);
#endif
            if (!m_impl)
            {
                return std::unexpected(Error{ErrorCode::InvalidHookState, "hook::vmt_remove_method"});
            }
            {
                // An exclusive write runs the VmHook destructor when it erases the entry. The destructor restores the
                // cloned slot to its original pointer. That restore must not race an original() snapshot reader.
                std::unique_lock<DetourModKit::detail::SrwSharedMutex> gate(m_impl->method_mutex);
                const auto it = m_impl->method_hooks.find(index);
                if (it == m_impl->method_hooks.end())
                {
                    return std::unexpected(Error{ErrorCode::MethodNotFound, "hook::vmt_remove_method", index});
                }
                m_impl->method_hooks.erase(it);
            }
            // This post-commit log is best-effort. Contain a format bad_alloc.
            try
            {
                log().info(
                    "hook::remove_method: removed method index {} from VMT hook '{}'.",
                    index,
                    std::string_view{m_impl->name}
                );
            }
            catch (...)
            {
            }
            return {};
        }

        void VmtHook::release() noexcept
        {
            if (!m_impl)
            {
                return;
            }
            // Leak the cloned vtable intentionally. Applied objects keep the clone for the process lifetime. The ledger
            // entry stays so is_vmt_clone_base still recognizes the live clone base. HookManager records the leak.
            diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::HookManager);
            (void)m_impl.release();
        }

        Result<VmtHook> vmt_for(std::string name, void *object, VmtOptions options)
        {
            if (std::optional<Error> vetoed = refuse_on_loader_lock("hook::vmt_for"))
            {
                return std::unexpected(*vetoed);
            }
#if defined(DMK_ENABLE_TEST_SEAMS)
            note_loader_veto_passed(DetourModKit::detail::HookLoaderEntry::VmtFor);
#endif
            if (name.empty())
            {
                return std::unexpected(Error{ErrorCode::InvalidArg, "hook::vmt_for"});
            }
            if (object == nullptr)
            {
                return std::unexpected(Error{ErrorCode::InvalidObject, "hook::vmt_for"});
            }
            // Take the module reference before the process-wide VMT object gate. A rollback runs FreeLibrary, which
            // takes the loader lock and must not nest inside the gate per ~VmtHook lock order. Declare the guard first.
            // The gate then unlocks first, so the guard FreeLibrary call always runs outside it.
            ModuleRefGuard self_ref(acquire_hook_self_ref());
            if (self_ref.get() == nullptr)
            {
                // acquire_module_ref restores GetLastError() on failure (error.hpp documents the detail contract).
                return std::unexpected(Error{ErrorCode::SystemCallFailed, "hook::vmt_for", ::GetLastError()});
            }
            std::unique_lock<std::mutex> object_gate = acquire_vmt_object_lock();
            if (!object_gate.owns_lock())
            {
                return std::unexpected(Error{ErrorCode::UnknownError, "hook::vmt_for"});
            }
            // Object-word validation is not a policy (see apply_to).
            const DetourModKit::detail::ObjectWordResult word =
                DetourModKit::detail::validate_vmt_object_word(reinterpret_cast<std::uintptr_t>(object));
            if (word.verdict != DetourModKit::detail::ObjectWordVerdict::Ok)
            {
                return std::unexpected(Error{ErrorCode::InvalidObject, "hook::vmt_for", word.detail});
            }
            const std::uintptr_t current_vptr = word.vptr;
            if (const std::optional<Error> refused = check_vmt_for_options(options, current_vptr, name, object))
            {
                return std::unexpected(*refused);
            }
            // The slot walk and the clone classify method pages through VirtualQuery. The backend coordinator excludes
            // a trap window that holds such a page at PAGE_READWRITE, which ends the walk early and publishes a
            // truncated clone (`[B-66]`). HookBackendTrapWindow.VmtForWaitsForTheBackendTrapWindow pins the exclusion.
            DetourModKit::detail::BackendCoordinatorHold coordinator;
            if (!coordinator)
            {
                log_vmt_coordinator_refusal(name, object);
                return std::unexpected(Error{ErrorCode::BackendFailed, "hook::vmt_for", current_vptr});
            }
            const Result<std::size_t> slot_budget = count_vmt_clone_budget(current_vptr, object);
            if (!slot_budget)
            {
                return std::unexpected(slot_budget.error());
            }
#if defined(DMK_ENABLE_TEST_SEAMS)
            if (auto *probe = DetourModKit::detail::g_vmt_before_capture_probe)
            {
                probe();
            }
#endif
            try
            {
                Result<DetachedVmtBackend> cloned = clone_vmt_snapshot(current_vptr, *slot_budget);
                // The clone is complete, so release the coordinator before the ledger, the publication, and the
                // subscriber code below.
                coordinator.release();
                if (!cloned)
                {
                    return std::unexpected(cloned.error());
                }
                const std::uintptr_t cloned_vptr_base = cloned->cloned_vptr_base;
                auto impl = std::make_unique<VmtHook::Impl>(
                    std::move(cloned->backend),
                    std::move(name),
                    cloned_vptr_base,
                    cloned->method_count,
                    0
                );
                impl->object_bindings.push_back({object, current_vptr});
                const std::string_view created_name = impl->name;
                const std::optional<std::uint64_t> recorded =
                    DetourModKit::detail::HookLedger::instance().try_record_vmt(cloned_vptr_base);
                if (!recorded)
                {
                    return std::unexpected(Error{ErrorCode::OutOfMemory, "hook::vmt_for"});
                }
                impl->ledger_id = *recorded;
                // Publication is last: every allocation, binding, and ledger step completes before the guarded store
                // can expose the clone to host dispatch.
                if (!publish_vmt_object_word(object, current_vptr, cloned_vptr_base))
                {
                    DetourModKit::detail::HookLedger::instance().release_vmt(*recorded);
                    return std::unexpected(
                        Error{ErrorCode::InvalidObject, "hook::vmt_for", reinterpret_cast<std::uintptr_t>(object)}
                    );
                }
                // Release the gate BEFORE the log and lifecycle event: subscriber code must not run under the
                // process-wide VMT mutex (CP.22), because a reentrant subscriber self-deadlocks.
                object_gate.unlock();
                report_vmt_hook_created(created_name, *recorded, object);
                // Hand the module reference to the Impl only after completion of every fallible setup step.
                impl->self_ref = self_ref.release();
                return VmtHook(std::move(impl));
            }
            catch (const std::bad_alloc &)
            {
                return std::unexpected(Error{ErrorCode::OutOfMemory, "hook::vmt_for"});
            }
            catch (...)
            {
                return std::unexpected(Error{ErrorCode::UnknownError, "hook::vmt_for"});
            }
        }
    } // namespace hook
} // namespace DetourModKit
