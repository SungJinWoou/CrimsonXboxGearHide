#include "internal/async_logger.hpp"

#include "DetourModKit/diagnostics.hpp"

#include "internal/async_logger_queue.hpp"
#include "internal/lifecycle_context.hpp"
#include "platform.hpp"
#include "internal/win_file_stream.hpp"

#include <algorithm>
#include <condition_variable>
#include <cstdint>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <new>
#include <ostream>
#include <span>
#include <system_error>
#include <thread>
#include <type_traits>

namespace DetourModKit
{
    using detail::acquire_module_ref;
    using detail::LogMessage;
    using detail::release_module_ref;

    // The string pool, per-message record, and MPMC queue are implementation-only types that live in
    // DetourModKit::detail (see internal/async_logger_queue.hpp). Their out-of-line definitions are grouped in the
    // namespace block below; the AsyncLogger pimpl definitions that follow reach them through the using-declarations
    // above.
    namespace detail
    {
#if defined(DMK_ENABLE_TEST_SEAMS)
        // Lets tests drive the writer-detach-and-leak branch without entering the real loader lock.
        bool (*g_async_logger_loader_lock_override)() noexcept = nullptr;

        // AsyncLogger instances currently alive. The retention root is a self-reference, so "was this writer retained
        // or destroyed?" is otherwise unobservable from outside: a retained writer is reachable only from itself.
        std::atomic<std::size_t> g_async_logger_live_count_for_test{0};
#endif

        bool async_logger_must_not_block() noexcept
        {
#if defined(DMK_ENABLE_TEST_SEAMS)
            return !blocking_teardown_permitted(g_async_logger_loader_lock_override);
#else
            return !blocking_teardown_permitted();
#endif
        }

#if defined(DMK_ENABLE_TEST_SEAMS)
        // Test-only gates for deterministic shutdown interleavings.
        std::atomic<std::atomic<bool> *> g_async_logger_writer_gate{nullptr};
        std::atomic<std::atomic<bool> *> g_async_logger_producer_gate{nullptr};
        std::atomic<bool> g_async_logger_producer_waiting{false};
        std::atomic<bool> g_async_logger_flush_waiting{false};
        // Pauses a producer AFTER it increments m_pending_messages but BEFORE it publishes the queue slot, so a test
        // can hold the writer in the in-flight window (pending != 0, queue empty) and prove it parks rather than
        // busy-spinning.
        std::atomic<std::atomic<bool> *> g_async_logger_prepush_gate{nullptr};
        std::atomic<bool> g_async_logger_prepush_waiting{false};
        // Counts each entry into the writer's idle park branch, so a test can prove a producer preempted mid-publish
        // does not turn the idle path into an unbounded busy loop.
        std::atomic<std::atomic<size_t> *> g_async_logger_idle_park_counter{nullptr};
        // Counts each record drained through the writer's one-record progress floor. The floor keeps the writer live
        // when a batch reservation cannot be secured, so it is reached only on that path: a test proves both that a
        // refused reservation really did route through it, and that an ordinary configuration never does.
        std::atomic<std::atomic<size_t> *> g_async_logger_batch_floor_counter{nullptr};
        // Makes flush_with_timeout hold m_flush_mutex and spin until the gate clears, so a test can prove a
        // Drop-policy producer completes its enqueue without acquiring that control-plane mutex.
        std::atomic<std::atomic<bool> *> g_async_logger_flush_mutex_gate{nullptr};
        // Counts the final-producer wake-event signal in finish_producer, so a test can prove the parked stopping
        // writer was released by that signal rather than by its flush-interval timeout.
        std::atomic<std::atomic<size_t> *> g_async_logger_finish_wake_counter{nullptr};
        // Counts entry into the Block overflow branch after admission. This gives shutdown tests an exact handshake
        // for the retry phase instead of a timing guess.
        std::atomic<std::atomic<size_t> *> g_async_logger_block_entry_counter{nullptr};
        // Pauses a Block producer at the retry boundary. The deadline proof releases this gate after Stopping is
        // visible, and production establishes the deadline immediately after the release.
        std::atomic<std::atomic<bool> *> g_async_logger_block_entry_gate{nullptr};
        // Publishes the Block retry-loop start time from the producer thread for a scheduling-independent deadline
        // assertion. Nanoseconds use steady_clock's epoch only as an opaque common origin.
        std::atomic<std::atomic<std::int64_t> *> g_async_logger_block_start_ns{nullptr};
        // Runs after a batch has been formatted but before its final flush so a test can invalidate the sink at the
        // exact durability boundary.
        void (*g_async_logger_before_flush_probe)(WinFileStream &) noexcept = nullptr;
        // Replaces the record clock with a fixed epoch time in milliseconds, so a test can place records at chosen
        // milliseconds.
        std::atomic<std::atomic<std::int64_t> *> g_async_logger_record_time_override{nullptr};
#endif

        StringPool::StringPool() noexcept
        {
            std::lock_guard<std::mutex> lock(m_pool_mutex);
            grow_pool_locked();
        }

        void StringPool::grow_pool_locked() noexcept
        {
            Block *existing = m_head.load(std::memory_order_relaxed);
            size_t count = 0;
            for (Block *b = existing; b; b = b->next)
            {
                if (++count >= MEMORY_POOL_BLOCK_COUNT)
                {
                    return;
                }
            }

            // Block is over-aligned via its alignas(64) data member, so it must be allocated through the aligned
            // operator new; the plain overload is not required to honour an alignment stricter than
            // __STDCPP_DEFAULT_NEW_ALIGNMENT__ (typically 16 on x64), which would be alignment UB. The allocation is
            // also nothrow: this runs underneath the noexcept logging path, so on out-of-memory it must leave the pool
            // unchanged and let the caller fall back to a nothrow heap string (or drop the message) rather than let
            // std::bad_alloc escape and terminate.
            void *raw = ::operator new(sizeof(Block), std::align_val_t{alignof(Block)}, std::nothrow);
            if (!raw)
            {
                return;
            }
            Block *new_block = new (raw) Block();

            new_block->next = existing;
            new_block->free_list = nullptr;

            PoolSlot *slots = reinterpret_cast<PoolSlot *>(new_block->data);
            // Slot construction must not throw, otherwise a partially built block could leak with no unwinding under
            // this noexcept function. std::string's default constructor is noexcept, so the loop below is provably
            // no-throw.
            static_assert(
                std::is_nothrow_default_constructible_v<PoolSlot>,
                "PoolSlot must be nothrow-default-constructible so grow_pool_locked stays no-throw"
            );
            for (size_t i = 0; i < POOL_SLOTS_PER_BLOCK; ++i)
            {
                new (&slots[i]) PoolSlot();
                slots[i].next_free = (i + 1 < POOL_SLOTS_PER_BLOCK) ? &slots[i + 1] : nullptr;
            }
            new_block->free_list = &slots[0];

            m_head.store(new_block, std::memory_order_release);
        }

        StringPool &StringPool::instance() noexcept
        {
            // Constructed once into function-local static storage and never destroyed. A Meyers singleton would be
            // destroyed at static teardown and race late LogMessage destructors that call into deallocate()
            // (use-after-free under DLL unload and loader-lock teardown). A heap-allocated singleton (`*new
            // StringPool()`) would instead require a throwing operator new whose std::bad_alloc would escape this
            // noexcept accessor and terminate the host. Placement-new into static storage avoids both: the object lives
            // for the whole process, its destructor never runs, and construction performs no throwing allocation
            // because grow_pool_locked() is nothrow. The bounded block leak (at most MEMORY_POOL_BLOCK_COUNT blocks,
            // each a POOL_SLOTS_PER_BLOCK * sizeof(PoolSlot)-byte slot array) is released by the OS at process exit.
            alignas(StringPool) static unsigned char storage[sizeof(StringPool)];
            static StringPool *const pool = ::new (static_cast<void *>(storage)) StringPool();
            return *pool;
        }

        StringPool::PoolSlot *StringPool::claim_free_slot() noexcept
        {
            for (Block *b = m_head.load(std::memory_order_relaxed); b; b = b->next)
            {
                if (b->free_list)
                {
                    PoolSlot *slot = b->free_list;
                    b->free_list = slot->next_free;
                    return slot;
                }
            }
            return nullptr;
        }

        std::string *StringPool::allocate(size_t size) noexcept
        {
            if (size > MAX_POOLED_STRING_SIZE)
            {
                return new (std::nothrow) std::string();
            }

            std::lock_guard<std::mutex> lock(m_pool_mutex);

            PoolSlot *slot = claim_free_slot();
            if (!slot)
            {
                grow_pool_locked();
                slot = claim_free_slot();
            }

            if (slot)
            {
                slot->str.clear();
                return &slot->str;
            }

            return new (std::nothrow) std::string();
        }

        void StringPool::deallocate(std::string *ptr) noexcept
        {
            if (!ptr)
                return;

            std::lock_guard<std::mutex> lock(m_pool_mutex);

            for (Block *b = m_head.load(std::memory_order_relaxed); b; b = b->next)
            {
                const auto *block_begin = reinterpret_cast<const char *>(b->data);
                const auto *block_end = block_begin + POOL_SLOTS_PER_BLOCK * sizeof(PoolSlot);
                const auto *raw_ptr = reinterpret_cast<const char *>(ptr);

                if (raw_ptr >= block_begin && raw_ptr < block_end)
                {
                    auto offset = static_cast<size_t>(raw_ptr - block_begin);
                    PoolSlot *slot = reinterpret_cast<PoolSlot *>(b->data) + (offset / sizeof(PoolSlot));
                    slot->str.clear();
                    return_slot_locked(slot, b);
                    return;
                }
            }

            // Not a pool allocation: heap fallback. The delete is performed under m_pool_mutex to serialize with
            // concurrent deallocate() calls that walk the block list above. Without the lock, a concurrent deallocate
            // could see a partially updated free list. The lock does not prevent double-free of heap pointers (those
            // are not tracked); callers must ensure each pointer is deallocated exactly once. The cost is a single
            // free() call (or no-op for SSO-sized strings).
            delete ptr;
        }

        void StringPool::return_slot_locked(PoolSlot *slot, Block *block) noexcept
        {
            slot->next_free = block->free_list;
            block->free_list = slot;
        }

        // buffer is intentionally left uninitialized on this hot path (see async_logger_queue.hpp): only [0, length)
        // is written before any read, so zero-filling it every message would be wasted work.
        // NOLINTNEXTLINE(cppcoreguidelines-pro-type-member-init)
        LogMessage::LogMessage(LogLevel lvl, std::string_view msg) noexcept
            : level(lvl), timestamp(std::chrono::system_clock::now())
        {
#if defined(DMK_ENABLE_TEST_SEAMS)
            if (const auto *forced_time = g_async_logger_record_time_override.load(std::memory_order_acquire))
            {
                timestamp = std::chrono::system_clock::time_point{
                    std::chrono::milliseconds{forced_time->load(std::memory_order_acquire)}
                };
            }
#endif
            const size_t msg_size = std::min(msg.size(), MAX_VALID_LENGTH);

            if (msg_size <= MAX_INLINE_SIZE)
            {
                std::memcpy(buffer.data(), msg.data(), msg_size);
                length = msg_size;
            }
            else
            {
                overflow = StringPool::instance().allocate(msg_size);
                if (overflow)
                {
                    try
                    {
                        overflow->assign(msg.substr(0, msg_size));
                        length = overflow->size();
                    }
                    catch (...)
                    {
                        StringPool::instance().deallocate(overflow);
                        overflow = nullptr;
                        length = 0;
                        // The assign threw under OOM: mark the record failed so the producer drops and counts it
                        // rather than enqueuing a zero-length husk.
                        failed = true;
                    }
                }
                else
                {
                    // Overflow allocation failed (OOM): mark the record failed (not merely empty) so it is dropped
                    // and counted, never enqueued as an empty timestamped line.
                    length = 0;
                    failed = true;
                }
            }
        }

        LogMessage::~LogMessage() noexcept
        {
            reset();
        }

        // Move transfers ownership of the overflow pointer without touching the StringPool. Exactly one LogMessage
        // owns the pointer at any time, and only reset() (called by the eventual owner's destructor) returns it.
        // NOLINTNEXTLINE(cppcoreguidelines-pro-type-member-init) buffer is filled by the length-guarded memcpy below
        LogMessage::LogMessage(LogMessage &&other) noexcept
            : level(other.level), timestamp(other.timestamp), length(other.length), overflow(other.overflow),
              failed(other.failed)
        {
            if (length > 0 && !overflow)
            {
                std::memcpy(buffer.data(), other.buffer.data(), length);
            }
            other.overflow = nullptr;
            other.length = 0;
            other.failed = false;
        }

        LogMessage &LogMessage::operator=(LogMessage &&other) noexcept
        {
            if (this != &other)
            {
                reset();
                level = other.level;
                timestamp = other.timestamp;
                length = other.length;
                overflow = other.overflow;
                failed = other.failed;
                if (length > 0 && !overflow)
                {
                    std::memcpy(buffer.data(), other.buffer.data(), length);
                }
                other.overflow = nullptr;
                other.length = 0;
                other.failed = false;
            }
            return *this;
        }

        std::string_view LogMessage::message() const noexcept
        {
            if (overflow)
            {
                return *overflow;
            }
            return std::string_view(buffer.data(), length);
        }

        bool LogMessage::is_valid() const noexcept
        {
            if (failed)
            {
                return false;
            }
            if (overflow)
            {
                return length == overflow->size();
            }
            return length <= MAX_INLINE_SIZE;
        }

        void LogMessage::reset() noexcept
        {
            if (overflow)
            {
                StringPool::instance().deallocate(overflow);
                overflow = nullptr;
            }
            length = 0;
            failed = false;
        }

        size_t DynamicMPMCQueue::validated_capacity(size_t capacity)
        {
            if ((capacity & (capacity - 1)) != 0 || capacity < 2)
            {
                throw std::invalid_argument("DynamicMPMCQueue capacity must be a power of 2 and at least 2");
            }
            return capacity;
        }

        DynamicMPMCQueue::DynamicMPMCQueue(size_t capacity)
            : m_capacity(validated_capacity(capacity)), m_mask(m_capacity - 1),
              m_buffer(std::make_unique<Slot[]>(m_capacity))
        {
            for (size_t i = 0; i < m_capacity; ++i)
            {
                m_buffer[i].sequence.store(i, std::memory_order_relaxed);
            }
        }

        bool DynamicMPMCQueue::try_push(LogMessage &item) noexcept
        {
            size_t pos = m_enqueue_pos.load(std::memory_order_relaxed);

            for (;;)
            {
                Slot &slot = m_buffer[pos & m_mask];
                size_t seq = slot.sequence.load(std::memory_order_acquire);
                intptr_t diff = static_cast<intptr_t>(seq) - static_cast<intptr_t>(pos);

                if (diff == 0)
                {
                    if (m_enqueue_pos.compare_exchange_weak(pos, pos + 1, std::memory_order_relaxed))
                    {
                        slot.data = std::move(item);
                        slot.sequence.store(pos + 1, std::memory_order_release);
                        return true;
                    }
                }
                else if (diff < 0)
                {
                    return false;
                }
                else
                {
                    pos = m_enqueue_pos.load(std::memory_order_relaxed);
                }
            }
        }

        bool DynamicMPMCQueue::try_pop(LogMessage &item) noexcept
        {
            size_t pos = m_dequeue_pos.load(std::memory_order_relaxed);

            for (;;)
            {
                Slot &slot = m_buffer[pos & m_mask];
                size_t seq = slot.sequence.load(std::memory_order_acquire);
                intptr_t diff = static_cast<intptr_t>(seq) - static_cast<intptr_t>(pos + 1);

                if (diff == 0)
                {
                    if (m_dequeue_pos.compare_exchange_weak(pos, pos + 1, std::memory_order_relaxed))
                    {
                        item = std::move(slot.data);
                        slot.sequence.store(pos + m_capacity, std::memory_order_release);
                        return true;
                    }
                }
                else if (diff < 0)
                {
                    return false;
                }
                else
                {
                    pos = m_dequeue_pos.load(std::memory_order_relaxed);
                }
            }
        }

        size_t DynamicMPMCQueue::try_pop_batch(std::vector<LogMessage> &items, size_t max_count) noexcept
        {
            if (max_count == 0)
            {
                return 0;
            }

            // Reserve headroom so the push_back loop below never reallocates. This runs on the writer's noexcept
            // frames, so a throwing allocator here must not escape: on bad_alloc the reserve is skipped and the pop
            // is capped to whatever spare capacity the vector already holds. Failing closed to a smaller batch is
            // correct behaviour for an out-of-memory host; terminating it is not.
            try
            {
                items.reserve(items.size() + max_count);
            }
            catch (...)
            {
            }

            // Never pop more than fits in the reserved capacity. Within capacity, push_back performs no allocation and
            // the LogMessage move constructor is noexcept, so the loop cannot throw even if the reserve above failed.
            const size_t headroom = items.capacity() - items.size();
            const size_t budget = std::min(max_count, headroom);

            size_t count = 0;
            LogMessage msg;

            while (count < budget && try_pop(msg))
            {
                items.push_back(std::move(msg));
                ++count;
            }

            return count;
        }

        size_t DynamicMPMCQueue::size() const noexcept
        {
            size_t enq = m_enqueue_pos.load(std::memory_order_relaxed);
            size_t deq = m_dequeue_pos.load(std::memory_order_relaxed);
            return (enq >= deq) ? (enq - deq) : 0;
        }

        bool DynamicMPMCQueue::empty() const noexcept
        {
            return size() == 0;
        }
    } // namespace detail

    // The AsyncLogger pimpl: every member and method that touches the queue, string pool, writer thread, or flush
    // synchronization lives here, so the header (internal/async_logger.hpp) names none of it. AsyncLogger forwards
    // each public call to the matching Impl method.
    struct AsyncLogger::Impl
    {
        Impl(
            const AsyncLoggerConfig &config,
            std::shared_ptr<detail::WinFileStream> file_stream,
            std::shared_ptr<std::mutex> log_mutex
        );
        ~Impl() noexcept;

        Impl(const Impl &) = delete;
        Impl &operator=(const Impl &) = delete;
        Impl(Impl &&) = delete;
        Impl &operator=(Impl &&) = delete;

        [[nodiscard]] bool
        enqueue(LogLevel level, std::string_view message, std::atomic<std::size_t> *retired_drop_counter) noexcept;
        [[nodiscard]] bool flush_with_timeout(std::chrono::milliseconds timeout) noexcept;
        void flush() noexcept;
        void shutdown() noexcept;
        [[nodiscard]] bool is_running() const noexcept;
#if defined(DMK_ENABLE_TEST_SEAMS)
        [[nodiscard]] bool is_writer_waiting() const noexcept;
#endif
        [[nodiscard]] size_t queue_size() const noexcept;
        [[nodiscard]] size_t dropped_count() const noexcept;
        void reset_dropped_count() noexcept;
        void set_timestamp_format(std::string timestamp_format) noexcept;
        void set_file_stream(std::shared_ptr<detail::WinFileStream> file_stream) noexcept;
        // True once shutdown() detached the writer under the loader lock instead of joining it. The public
        // destructor reads this to decide whether the Impl (and the queue / wake event / flush channel / file stream
        // the detached writer still touches) may be destroyed or must be leaked in place.
        [[nodiscard]] bool writer_was_detached() const noexcept;

        void writer_thread_func() noexcept;
        /// Yields to an in-flight push, flushes the sink on the interval, and parks while work can still arrive.
        void run_idle_cycle(std::chrono::steady_clock::time_point &last_flush) noexcept;
        /// Flushes the sink, zeroes the pending count, and publishes Stopped at the writer exit.
        void finish_writer_drain() noexcept;
        void finish_producer() noexcept;
        [[nodiscard]] size_t write_batch(std::span<const detail::LogMessage> messages) noexcept;
        bool handle_overflow(detail::LogMessage &&message) noexcept;
        /// Retries the Block-policy push until the deadline, and on timeout counts a drop and returns false.
        [[nodiscard]] bool retry_push_until_deadline(detail::LogMessage &message) noexcept;
        // Wakes a parked writer after a successful push. SetEvent acquires no DMK control-plane mutex, so a
        // callback-safe Drop-policy producer cannot stall behind a flusher or the writer here. The producer publishes
        // the queue slot before it reads m_writer_waiting; the writer publishes m_writer_waiting before it rechecks for
        // work and parks. Those seq_cst operations close the lost-wakeup window, and the auto-reset event retains one
        // signal when a producer wins the race immediately before the wait.
        void notify_writer() noexcept;

        detail::DynamicMPMCQueue m_queue;
        AsyncLoggerConfig m_config;

        std::shared_ptr<detail::WinFileStream> m_file_stream;
        std::shared_ptr<std::mutex> m_log_mutex;

        std::jthread m_writer_thread;
        // Counted reference on the module the writer thread's code lives in, taken before the thread is created.
        // shutdown() releases it after a clean join, or leaks it on the loader-lock detach path so the writer's code
        // stays mapped. void* keeps the pimpl header-light; it holds an HMODULE in the implementation. See
        // detail::acquire_module_ref.
        void *m_writer_self_ref{nullptr};
        // Single-owner shutdown state. Async: producers enqueue and the writer drains. Stopping: a stop was
        // requested, so the retained writer finishes the drain while new callback-safe producers drop and count.
        // Stopped: the writer has drained, flushed the sink, and acknowledged the drain. The writer owns the
        // Stopping->Stopped transition at its own tail (the loader-lock abandon path returns and leaves everything to
        // it); shutdown() only requests the stop.
        enum class State : std::uint8_t
        {
            Async,
            Stopping,
            Stopped
        };
        std::atomic<State> m_state{State::Stopped};
        // Producers register before observing m_state. This prevents the writer from exiting while an admitted
        // producer has not published its queue slot yet.
        std::atomic<size_t> m_active_producers{0};
        // Latched by shutdown() when it detaches the writer on the loader-lock path. Read by ~AsyncLogger to keep the
        // Impl alive past the detached writer. A latched flag (rather than re-querying is_loader_lock_held() in the
        // destructor) avoids a TOCTOU where the loader-lock state differs between the detach decision and the free.
        std::atomic<bool> m_writer_detached{false};

        // Flush-drain acknowledgement channel, used only by control-plane flushers (flush_with_timeout) and the
        // signalers that release them (the writer after a batch drains the pending count to zero, and finish_producer
        // when the last admitted producer leaves during shutdown). The producer wake path does NOT touch this mutex;
        // it uses m_wake_event, so a callback-safe producer never contends a control-plane lock.
        std::mutex m_flush_mutex;
        std::condition_variable m_flush_cv;

        // Auto-reset event the writer parks on when idle. A producer SetEvents it (mutex-free) to wake the writer;
        // shutdown() SetEvents it so a parked writer observes the stop. Held as a Win32 HANDLE created before the
        // writer thread starts. Closed by ~Impl on the normal join path; on the loader-lock detach path the whole
        // Impl (and this handle) is leaked in place so the still-running detached writer keeps a live event.
        HANDLE m_wake_event{nullptr};

        // Set true by the writer immediately before it parks on m_wake_event and cleared when it wakes. Producers read
        // it (seq_cst) after a successful queue push; the seq_cst order makes a racing push either visible to the
        // writer's pre-park work recheck or visible here as a parked-writer wake through SetEvent.
        std::atomic<bool> m_writer_waiting{false};

        std::atomic<size_t> m_pending_messages{0};
        std::atomic<size_t> m_dropped_messages{0};
    };

    AsyncLogger::Impl::Impl(
        const AsyncLoggerConfig &config,
        std::shared_ptr<detail::WinFileStream> file_stream,
        std::shared_ptr<std::mutex> log_mutex
    )
        : m_queue(config.queue_capacity), m_config(config), m_file_stream(std::move(file_stream)),
          m_log_mutex(std::move(log_mutex))
    {
        if (m_config.timestamp_format.empty())
        {
            m_config.timestamp_format = DEFAULT_ASYNC_TIMESTAMP_FORMAT;
        }
        if (!m_config.validate())
        {
            throw std::invalid_argument("Invalid AsyncLoggerConfig");
        }
        // Bound the drain request to what the queue can ever hold. A larger batch_size buys nothing (the queue cannot
        // produce more records than its capacity) and costs liveness: the writer reserves batch_size headroom before
        // popping, and a request past the vector's max_size throws length_error on every single attempt, which is a
        // permanent zero-progress pop rather than a transient one. Clamping on the owned copy leaves the caller's
        // configuration untouched, and rejecting instead would turn a harmless oversize into a construction failure on
        // a path that reaches Session bootstrap.
        m_config.batch_size = std::min(m_config.batch_size, m_config.queue_capacity);

        if (!m_file_stream)
        {
            throw std::invalid_argument("file_stream cannot be null");
        }

        if (!m_log_mutex)
        {
            throw std::invalid_argument("log_mutex cannot be null");
        }

        // Hold a counted reference on this module before creating the writer thread. Once std::jthread returns, the
        // writer may already be executing this TU's code, so the keepalive has to predate the thread start. shutdown()
        // releases it after a clean join or leaks it on the loader-lock detach path.
        const HMODULE writer_self_ref = acquire_module_ref(diagnostics::ModulePinReason::AsyncLogger);
        if (writer_self_ref == nullptr)
        {
            throw std::system_error(
                static_cast<int>(GetLastError()),
                std::system_category(),
                "AsyncLogger: acquire_module_ref failed"
            );
        }

        // Auto-reset (bManualReset FALSE), initially non-signaled. Created before the writer thread starts so the
        // thread can park on it immediately; a producer or shutdown() signals it to wake the parked writer.
        m_wake_event = ::CreateEventW(nullptr, FALSE, FALSE, nullptr);
        if (m_wake_event == nullptr)
        {
            release_module_ref(writer_self_ref, diagnostics::ModulePinReason::AsyncLogger);
            throw std::system_error(
                static_cast<int>(GetLastError()),
                std::system_category(),
                "AsyncLogger: CreateEventW failed"
            );
        }

        m_state.store(State::Async, std::memory_order_release);
        try
        {
            m_writer_thread = std::jthread(&AsyncLogger::Impl::writer_thread_func, this);
        }
        catch (...)
        {
            m_state.store(State::Stopped, std::memory_order_release);
            ::CloseHandle(m_wake_event);
            m_wake_event = nullptr;
            release_module_ref(writer_self_ref, diagnostics::ModulePinReason::AsyncLogger);
            throw;
        }
        m_writer_self_ref = writer_self_ref;
    }

    AsyncLogger::Impl::~Impl() noexcept
    {
        shutdown();
        // Reached only off the loader-lock detach path: shutdown() joined the writer, so the wake event is no longer
        // waited on and is closed here. On the detach path the public ~AsyncLogger leaks this Impl in place (its
        // release()), so this destructor never runs and the handle stays live for the still-running detached writer.
        if (m_wake_event != nullptr)
        {
            ::CloseHandle(m_wake_event);
            m_wake_event = nullptr;
        }
    }

    bool AsyncLogger::Impl::enqueue(
        LogLevel level,
        std::string_view message,
        std::atomic<std::size_t> *retired_drop_counter
    ) noexcept
    {
        // The seq_cst registration and state check form an admission handshake with shutdown's state transition. A
        // producer that observes Async remains visible until it publishes or drops; one that arrives after Stopping
        // cannot publish.
        m_active_producers.fetch_add(1, std::memory_order_seq_cst);
        if (m_state.load(std::memory_order_seq_cst) != State::Async)
        {
            std::atomic<std::size_t> &drop_counter =
                retired_drop_counter != nullptr ? *retired_drop_counter : m_dropped_messages;
            drop_counter.fetch_add(1, std::memory_order_relaxed);
            finish_producer();
            return false;
        }

#if defined(DMK_ENABLE_TEST_SEAMS)
        if (auto *gate = detail::g_async_logger_producer_gate.load(std::memory_order_acquire))
        {
            detail::g_async_logger_producer_waiting.store(true, std::memory_order_release);
            while (gate->load(std::memory_order_acquire))
            {
                std::this_thread::yield();
            }
            detail::g_async_logger_producer_waiting.store(false, std::memory_order_release);
        }
#endif

        LogMessage msg(level, message);
        if (!msg.is_valid())
        {
            // An over-long message whose overflow allocation failed is an invalid, zero-length husk. Drop and count
            // it rather than enqueue an empty timestamped line that misrepresents the lost content.
            m_dropped_messages.fetch_add(1, std::memory_order_relaxed);
            finish_producer();
            return false;
        }

        // Increment before push so flush cannot observe zero while a message is already in the queue but not yet
        // counted.
        m_pending_messages.fetch_add(1, std::memory_order_seq_cst);
#if defined(DMK_ENABLE_TEST_SEAMS)
        // Test-only pause in the in-flight window: pending is counted but the slot is not published yet.
        if (auto *gate = detail::g_async_logger_prepush_gate.load(std::memory_order_acquire))
        {
            detail::g_async_logger_prepush_waiting.store(true, std::memory_order_release);
            while (gate->load(std::memory_order_acquire))
            {
                std::this_thread::yield();
            }
            detail::g_async_logger_prepush_waiting.store(false, std::memory_order_release);
        }
#endif
        if (m_queue.try_push(msg))
        {
            notify_writer();
            finish_producer();
            return true;
        }
        // Push failed: undo the pre-increment before entering overflow handling
        m_pending_messages.fetch_sub(1, std::memory_order_seq_cst);
        const bool handled = handle_overflow(std::move(msg));
        finish_producer();
        return handled;
    }

    bool AsyncLogger::Impl::flush_with_timeout(std::chrono::milliseconds timeout) noexcept
    {
        // Succeeds only on a genuine drain acknowledgement (the pending count reaching zero), never merely because
        // the writer stopped. A stopped writer with an undrained queue must report a failed flush, not a false
        // success. The predicate is checked before the wait, so an already-drained logger returns at once.
        std::unique_lock<std::mutex> lock(m_flush_mutex);
#if defined(DMK_ENABLE_TEST_SEAMS)
        detail::g_async_logger_flush_waiting.store(true, std::memory_order_release);
        // Hold m_flush_mutex (the control-plane mutex) while a fixture proves a Drop-policy producer's enqueue
        // completes without acquiring it. wait_for below only runs once the gate clears and the lock is released.
        if (auto *gate = detail::g_async_logger_flush_mutex_gate.load(std::memory_order_acquire))
        {
            while (gate->load(std::memory_order_acquire))
            {
                std::this_thread::yield();
            }
        }
#endif
        const bool flushed = m_flush_cv.wait_for(
            lock,
            timeout,
            [this]() noexcept
            {
                return m_pending_messages.load(std::memory_order_acquire) == 0 &&
                       m_active_producers.load(std::memory_order_seq_cst) == 0;
            }
        );
#if defined(DMK_ENABLE_TEST_SEAMS)
        detail::g_async_logger_flush_waiting.store(false, std::memory_order_release);
#endif
        return flushed;
    }

    void AsyncLogger::Impl::flush() noexcept
    {
        (void)flush_with_timeout(DEFAULT_FLUSH_TIMEOUT);
    }

    void AsyncLogger::Impl::shutdown() noexcept
    {
        State expected = State::Async;
        if (!m_state.compare_exchange_strong(expected, State::Stopping, std::memory_order_seq_cst))
        {
            // Already Stopping or Stopped: shutdown ran once and owns the teardown.
            return;
        }

        // Wake a parked writer so it observes Stopping and drains to exit. SetEvent takes no lock, which is required
        // on the loader-lock abandon path, where waiting for a writer-owned mutex could deadlock process teardown. A
        // flusher blocked on m_flush_cv is released separately, by the writer's post-drain notify at its tail.
        ::SetEvent(m_wake_event);

        if (m_writer_thread.joinable())
        {
            if (detail::async_logger_must_not_block())
            {
                // Loader-lock abandon: publish the stop and return immediately. The retained writer alone finishes
                // the drain, owns final sink access, resets the pending counter, and performs the Stopping->Stopped
                // transition at its tail. Draining or zeroing the counter here would make this thread a second
                // consumer of the same queue and sink and could underflow the counter against the writer's own
                // decrement. Detach the writer and leak its module reference (taken before thread creation) so its
                // code stays mapped, and latch the detach so ~AsyncLogger leaks this Impl in place instead of freeing
                // the queue / wake event / flush channel / file stream the writer still reads.
                try
                {
                    m_writer_thread.detach();
                }
                catch (...)
                {
                    // The Impl is abandoned below, so a still-joinable jthread remains live storage rather than
                    // reaching its joining destructor under the loader lock.
                }
                m_writer_detached.store(true, std::memory_order_release);
                DetourModKit::diagnostics::record_intentional_leak(
                    DetourModKit::diagnostics::LeakSubsystem::AsyncLogger
                );
                return;
            }

            try
            {
                m_writer_thread.join();
            }
            catch (...)
            {
                try
                {
                    if (m_writer_thread.joinable())
                    {
                        m_writer_thread.detach();
                    }
                }
                catch (...)
                {
                    // The leaked Impl keeps a still-joinable thread object alive.
                }
                m_writer_detached.store(true, std::memory_order_release);
                DetourModKit::diagnostics::record_intentional_leak(
                    DetourModKit::diagnostics::LeakSubsystem::AsyncLogger
                );
                return;
            }
            // Joined off the loader lock: the writer's code is done, so drop the reference taken before thread
            // creation. Another reference on the module still exists (the caller running this teardown), so this is
            // never terminal.
            release_module_ref(static_cast<HMODULE>(m_writer_self_ref), diagnostics::ModulePinReason::AsyncLogger);
            m_writer_self_ref = nullptr;
        }

        // The writer waits for every admitted producer and owns the complete drain before join returns.
    }

    bool AsyncLogger::Impl::is_running() const noexcept
    {
        return m_state.load(std::memory_order_acquire) == State::Async;
    }

#if defined(DMK_ENABLE_TEST_SEAMS)
    bool AsyncLogger::Impl::is_writer_waiting() const noexcept
    {
        return m_writer_waiting.load(std::memory_order_acquire);
    }
#endif

    size_t AsyncLogger::Impl::queue_size() const noexcept
    {
        return m_queue.size();
    }

    size_t AsyncLogger::Impl::dropped_count() const noexcept
    {
        return m_dropped_messages.load(std::memory_order_relaxed);
    }

    void AsyncLogger::Impl::reset_dropped_count() noexcept
    {
        m_dropped_messages.store(0, std::memory_order_release);
    }

    void AsyncLogger::Impl::set_timestamp_format(std::string timestamp_format) noexcept
    {
        // No lock taken here: the caller holds the shared log mutex (m_log_mutex), which is the same mutex the writer
        // thread takes before it reads m_config.timestamp_format in write_batch / enqueue / handle_overflow. Because
        // the caller holds it, the writer cannot be mid-read, so the assignment is race-free; taking the mutex here
        // would self-deadlock the reconfigure path that already owns it. std::string move-assignment is noexcept, so
        // the by-value parameter (copied in the caller's throwing context) makes this frame genuinely no-throw.
        m_config.timestamp_format = std::move(timestamp_format);
    }

    void AsyncLogger::Impl::set_file_stream(std::shared_ptr<detail::WinFileStream> file_stream) noexcept
    {
        // Same locking rule as set_timestamp_format: the caller holds m_log_mutex, which every reader of m_file_stream
        // takes, so the writer thread cannot be mid-write. Logger::reconfigure_locked opens the replacement sink before
        // it retires the old one, so the writer never observes a closed stream between the two.
        m_file_stream = std::move(file_stream);
    }

    bool AsyncLogger::Impl::writer_was_detached() const noexcept
    {
        return m_writer_detached.load(std::memory_order_acquire);
    }

    void AsyncLogger::Impl::finish_producer() noexcept
    {
        const size_t previous = m_active_producers.fetch_sub(1, std::memory_order_seq_cst);
        // Signal flush waiters only while stopping, where the last admitted producer draining out is the transition
        // that lets a shutdown-time flush observe m_active_producers == 0 and complete. During Async this path stays
        // off the flush condition variable so a producer never contends the control-plane mutex on a hot enqueue; an
        // Async flush waiter is instead released by the writer's post-drain notify or, failing that, by its own wait
        // timeout, so its return value stays a genuine drain acknowledgement in every case.
        if (previous == 1 && m_state.load(std::memory_order_seq_cst) != State::Async)
        {
            m_flush_cv.notify_all();
            // The stopping writer's loop stays alive on m_active_producers != 0, so the transition to zero is also
            // its exit condition. A producer that leaves WITHOUT publishing a slot (a dropped over-inline message)
            // never reaches notify_writer, and a writer already parked on the wake event otherwise inherits the
            // full flush interval before it rechecks. The same seq_cst Dekker pairing as the push path applies: the
            // writer publishes m_writer_waiting before it loads m_active_producers, so either it sees this exit and
            // skips the wait, or this load sees the parked flag and signals.
            if (m_writer_waiting.load(std::memory_order_seq_cst))
            {
#if defined(DMK_ENABLE_TEST_SEAMS)
                if (auto *counter = detail::g_async_logger_finish_wake_counter.load(std::memory_order_acquire))
                {
                    counter->fetch_add(1, std::memory_order_relaxed);
                }
#endif
                ::SetEvent(m_wake_event);
            }
        }
    }

    void AsyncLogger::Impl::notify_writer() noexcept
    {
        // The caller has already published the queue slot. In the seq_cst order either the writer's pre-park work
        // recheck observes that push, or this load observes the writer's parked flag and signals the wake event.
        // SetEvent takes no control-plane mutex, so a callback-safe Drop-policy producer cannot stall behind a
        // flusher or the writer. When the writer is actively draining the flag is false and this is a single atomic
        // load with no syscall, so the streaming hot path stays syscall-free.
        if (m_writer_waiting.load(std::memory_order_seq_cst))
        {
            ::SetEvent(m_wake_event);
        }
    }

    void AsyncLogger::Impl::writer_thread_func() noexcept
    {
        // No pre-reserve here: this frame is noexcept, so a throwing reserve would std::terminate on host OOM.
        // try_pop_batch owns the (fail-closed) reservation and only pops within the capacity it can secure. After the
        // first pop the batch retains its capacity across the clear()s below, so the steady-state reserve is a no-op.
        std::vector<LogMessage> batch;

        auto last_flush = std::chrono::steady_clock::now();

        while (m_state.load(std::memory_order_seq_cst) == State::Async ||
               m_active_producers.load(std::memory_order_seq_cst) != 0 || !m_queue.empty())
        {
#if defined(DMK_ENABLE_TEST_SEAMS)
            // Test-only pause point: hold the writer off the queue while a fixture inspects the pre-drain state.
            for (auto *gate = detail::g_async_logger_writer_gate.load(std::memory_order_acquire);
                 gate && gate->load(std::memory_order_acquire);
                 gate = detail::g_async_logger_writer_gate.load(std::memory_order_acquire))
            {
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            }
#endif
            batch.clear();
            (void)m_queue.try_pop_batch(batch, m_config.batch_size);

            size_t drained = batch.size();
            size_t failed = 0;
            if (drained != 0)
            {
                failed = write_batch(batch);
            }
            else if (!m_queue.empty())
            {
                // The batch reserve could not secure headroom, so the pop returned nothing while records are queued.
                // Without a floor the loop condition stays true, the idle gates below never run, and the writer spins
                // at 100% CPU forever, taking shutdown's join() with it. Drain one record through stack storage
                // instead: try_pop moves into an existing object and allocates nothing, so forward progress no longer
                // depends on the allocator recovering. The accounting below is shared with the batch arm, so a
                // one-record cycle updates exactly what a batch cycle does.
                LogMessage one;
                if (m_queue.try_pop(one))
                {
                    failed = write_batch(std::span<const LogMessage>(&one, 1));
                    drained = 1;
#if defined(DMK_ENABLE_TEST_SEAMS)
                    if (auto *counter = detail::g_async_logger_batch_floor_counter.load(std::memory_order_acquire))
                    {
                        counter->fetch_add(1, std::memory_order_relaxed);
                    }
#endif
                }
            }

            if (drained != 0)
            {
                // Publish sink loss before acknowledging the drain. A flush waiter that observes pending == 0 must
                // also observe the complete drop count for every record the writer just consumed.
                if (failed != 0)
                {
                    m_dropped_messages.fetch_add(failed, std::memory_order_relaxed);
                }
                {
                    std::lock_guard<std::mutex> flock(m_flush_mutex);
                    m_pending_messages.fetch_sub(drained, std::memory_order_acq_rel);
                }
                m_flush_cv.notify_all();
                last_flush = std::chrono::steady_clock::now();
            }
            else
            {
                run_idle_cycle(last_flush);
            }
        }

        finish_writer_drain();
    }

    void AsyncLogger::Impl::run_idle_cycle(std::chrono::steady_clock::time_point &last_flush) noexcept
    {
        // This limit caps the cooperative yields per idle cycle. The limit covers the common few-instruction
        // publish window. A producer preempted beyond it sends the writer to the event wait below, not into an
        // unbounded yield loop.
        constexpr size_t INFLIGHT_SPIN_LIMIT = 8;

        // A producer bumps m_pending_messages before it publishes its queue slot, so a non-zero pending count here
        // means that a push is in flight. A claimed but unpublished slot counts toward the queue size, so
        // m_queue.empty() returns false while the slot offers nothing to drain. The caller therefore gates this cycle
        // on a pop that drained nothing, not on queue emptiness.
        for (size_t spin = 0; spin < INFLIGHT_SPIN_LIMIT && m_state.load(std::memory_order_acquire) == State::Async &&
                              m_pending_messages.load(std::memory_order_seq_cst) != 0;
             ++spin)
        {
            std::this_thread::yield();
        }

        auto now = std::chrono::steady_clock::now();
        if (now - last_flush >= m_config.flush_interval)
        {
            std::lock_guard<std::mutex> lock(*m_log_mutex);
            if (m_file_stream->is_open())
            {
                m_file_stream->flush();
            }
            last_flush = now;
        }

        // The writer publishes m_writer_waiting (seq_cst) before the recheck below, so a producer that publishes a slot
        // after that store signals the event. The writer parks on the event, not on a pending-count predicate that
        // returns at once, to bound the idle work.
        m_writer_waiting.store(true, std::memory_order_seq_cst);
        const bool has_pending = m_pending_messages.load(std::memory_order_seq_cst) != 0;
        const bool keep_running = m_state.load(std::memory_order_seq_cst) == State::Async ||
                                  m_active_producers.load(std::memory_order_seq_cst) != 0;
        if (keep_running || has_pending)
        {
#if defined(DMK_ENABLE_TEST_SEAMS)
            if (auto *counter = detail::g_async_logger_idle_park_counter.load(std::memory_order_acquire))
            {
                counter->fetch_add(1, std::memory_order_relaxed);
            }
#endif
            // With a push in flight (has_pending, nothing drained), the writer parks for a 1 ms wait instead of the
            // full interval. A producer that publishes its slot and reads m_writer_waiting == false before the store
            // above sends no signal. The short wait recovers that rare lost wakeup within a millisecond and does not
            // burn a core. An idle writer parks for up to the full interval, and the next producer's SetEvent wakes it.
            const auto interval = m_config.flush_interval.count();
            const DWORD wait_ms = has_pending ? 1u
                                              : static_cast<DWORD>(
                                                    interval < 1            ? 1
                                                    : interval > 0x7FFFFFFF ? 0x7FFFFFFF
                                                                            : interval
                                                );
            ::WaitForSingleObject(m_wake_event, wait_ms);
        }
        m_writer_waiting.store(false, std::memory_order_seq_cst);
    }

    void AsyncLogger::Impl::finish_writer_drain() noexcept
    {
        {
            std::lock_guard<std::mutex> lock(*m_log_mutex);
            if (m_file_stream->is_open())
            {
                m_file_stream->flush();
            }
        }

        {
            std::lock_guard<std::mutex> lock(m_flush_mutex);
            m_pending_messages.store(0, std::memory_order_release);
            m_flush_cv.notify_all();
        }

        // The writer is the single owner of the Stopping->Stopped transition: it publishes Stopped only after the
        // queue is fully drained, the sink flushed, and the pending counter zeroed above. On the loader-lock abandon
        // path shutdown() returned early and left this final acknowledgement to the retained writer.
        m_state.store(State::Stopped, std::memory_order_release);
    }

    namespace
    {
        /**
         * @brief Writes one record line in the synchronous sink layout (`[B-32]`).
         * @details Each level field leaves std::left on the shared sink, so the millisecond field sets its own
         *          adjustment. A stream exception reaches the caller.
         */
        void write_record_line(
            std::ostream &out,
            const std::tm &calendar_time,
            const LogMessage &message,
            const std::string &timestamp_format
        )
        {
            const auto milliseconds =
                std::chrono::duration_cast<std::chrono::milliseconds>(message.timestamp.time_since_epoch()) % 1000;
            out << "[" << std::put_time(&calendar_time, timestamp_format.c_str()) << "." << std::right
                << std::setfill('0') << std::setw(3) << milliseconds.count() << std::setfill(' ') << "] ["
                << std::setw(7) << std::left << to_string(message.level) << "] :: " << message.message() << '\n';
        }
    } // namespace

    size_t AsyncLogger::Impl::write_batch(std::span<const LogMessage> messages) noexcept
    {
        std::lock_guard<std::mutex> lock(*m_log_mutex);

        if (!m_file_stream->is_open() || !m_file_stream->good())
        {
            return messages.size();
        }

        try
        {
            // Cache the localtime result across consecutive messages that share the same second to avoid repeated CRT
            // lock acquisition inside localtime_s.
            std::time_t cached_second{-1};
            std::tm cached_tm{};

            for (const auto &msg : messages)
            {
                const auto time_t = std::chrono::system_clock::to_time_t(msg.timestamp);

                if (time_t != cached_second)
                {
                    cached_second = time_t;
#if defined(_WIN32) || defined(_MSC_VER)
                    localtime_s(&cached_tm, &time_t);
#else
                    localtime_r(&time_t, &cached_tm);
#endif
                }

                write_record_line(*m_file_stream, cached_tm, msg, m_config.timestamp_format);
            }

#if defined(DMK_ENABLE_TEST_SEAMS)
            if (auto *probe = detail::g_async_logger_before_flush_probe)
            {
                probe(*m_file_stream);
            }
#endif
            m_file_stream->flush();
        }
        catch (...)
        {
            return messages.size();
        }

        // An insertion or final flush failure leaves the stream unhealthy. Record the whole dequeued batch as
        // unconfirmed because the buffer does not expose which complete record boundaries reached the file.
        return m_file_stream->good() ? 0 : messages.size();
    }

    bool AsyncLogger::Impl::handle_overflow(LogMessage &&message) noexcept
    {
        switch (m_config.overflow_policy)
        {
        case OverflowPolicy::DropNewest:
            m_dropped_messages.fetch_add(1, std::memory_order_relaxed);
            return false;

        case OverflowPolicy::DropOldest:
        {
            LogMessage oldest;
            if (m_queue.try_pop(oldest))
            {
                // Count the evicted oldest message as dropped
                m_dropped_messages.fetch_add(1, std::memory_order_relaxed);
                if (m_queue.try_push(message))
                {
                    // Net effect on m_pending_messages: pop(-1) + push(+1) = 0
                    notify_writer();
                    return true;
                }
                // Pop succeeded but push failed: net -1
                m_pending_messages.fetch_sub(1, std::memory_order_seq_cst);
            }
            // Count the new message as dropped (separate from the evicted oldest above). m_dropped_messages counts
            // individual lost messages, not overflow events.
            m_dropped_messages.fetch_add(1, std::memory_order_relaxed);
            return false;
        }

        case OverflowPolicy::Block:
            return retry_push_until_deadline(message);

        case OverflowPolicy::SyncFallback:
        {
            std::lock_guard<std::mutex> lock(*m_log_mutex);
            if (!m_file_stream->is_open() || !m_file_stream->good())
            {
                // The synchronous fallback could not reach a healthy sink, so the message is lost. Count it as a
                // drop rather than reporting a silent failure.
                m_dropped_messages.fetch_add(1, std::memory_order_relaxed);
                return false;
            }

            const auto time_t = std::chrono::system_clock::to_time_t(message.timestamp);
            std::tm tm_buf{};

#if defined(_WIN32) || defined(_MSC_VER)
            localtime_s(&tm_buf, &time_t);
#else
            localtime_r(&time_t, &tm_buf);
#endif

            write_record_line(*m_file_stream, tm_buf, message, m_config.timestamp_format);
            m_file_stream->flush();

            if (m_file_stream->fail())
            {
                // The synchronous write left the stream failed, so the message did not durably reach the sink.
                m_dropped_messages.fetch_add(1, std::memory_order_relaxed);
                return false;
            }
            return true;
        }

        default:
            m_dropped_messages.fetch_add(1, std::memory_order_relaxed);
            return false;
        }
    }

    bool AsyncLogger::Impl::retry_push_until_deadline(LogMessage &message) noexcept
    {
#if defined(DMK_ENABLE_TEST_SEAMS)
        if (auto *counter = detail::g_async_logger_block_entry_counter.load(std::memory_order_acquire))
        {
            counter->fetch_add(1, std::memory_order_relaxed);
        }
        if (auto *gate = detail::g_async_logger_block_entry_gate.load(std::memory_order_acquire))
        {
            while (gate->load(std::memory_order_acquire))
            {
                std::this_thread::yield();
            }
        }
#endif
        const auto deadline = std::chrono::steady_clock::now() + m_config.block_timeout_ms;
#if defined(DMK_ENABLE_TEST_SEAMS)
        if (auto *start_ns = detail::g_async_logger_block_start_ns.load(std::memory_order_acquire))
        {
            const auto now_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::steady_clock::now().time_since_epoch()
            );
            start_ns->store(now_ns.count(), std::memory_order_release);
        }
#endif
        size_t spin_count = 0;

        // Count the message as pending for the whole retry loop, so a flush waiter sees it in flight.
        m_pending_messages.fetch_add(1, std::memory_order_seq_cst);

        while (std::chrono::steady_clock::now() < deadline)
        {
            if (m_queue.try_push(message))
            {
                notify_writer();
                return true;
            }

            if (spin_count < m_config.spin_backoff_iterations)
            {
                ++spin_count;
            }
            else if (spin_count < m_config.block_max_spin_iterations)
            {
                std::this_thread::yield();
                ++spin_count;
            }
            else
            {
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            }
        }
        m_pending_messages.fetch_sub(1, std::memory_order_seq_cst);
        m_dropped_messages.fetch_add(1, std::memory_order_relaxed);
        return false;
    }

    // AsyncLogger is a thin facade: construction builds the Impl (which validates the config and starts the writer
    // thread), and every public method forwards to it. The out-of-line destructor sees the complete Impl so the
    // unique_ptr can delete it (Impl::~Impl drains and joins the writer).
    AsyncLogger::AsyncLogger(
        const AsyncLoggerConfig &config,
        std::shared_ptr<detail::WinFileStream> file_stream,
        std::shared_ptr<std::mutex> log_mutex
    )
        : m_impl(std::make_unique<Impl>(config, std::move(file_stream), std::move(log_mutex)))
    {
#if defined(DMK_ENABLE_TEST_SEAMS)
        detail::g_async_logger_live_count_for_test.fetch_add(1, std::memory_order_relaxed);
#endif
    }

    AsyncLogger::~AsyncLogger() noexcept
    {
#if defined(DMK_ENABLE_TEST_SEAMS)
        detail::g_async_logger_live_count_for_test.fetch_sub(1, std::memory_order_relaxed);
#endif
        if (!m_impl)
        {
            return;
        }

        // Drive the writer to a stop. Under the loader lock shutdown() cannot join, so it detaches the writer (which
        // keeps reading m_queue / m_flush_cv / m_file_stream until it observes the stop) and latches m_writer_detached.
        m_impl->shutdown();

        if (m_impl->writer_was_detached())
        {
            // The writer is still running against this Impl's members, so ~Impl must NOT run: destroying the condition
            // variable while the detached writer is parked on it (or the queue it is draining) is undefined behaviour.
            // Abandon the already-heap-allocated Impl in place: release() relinquishes the unique_ptr without
            // freeing, so the members outlive the writer with zero further allocation.
            // The detached writer's own counted module reference keeps the code pages it executes mapped. The
            // intentional-leak event was already recorded inside shutdown()'s detach branch, so it is not recorded a
            // second time here.
            (void)m_impl.release();
            return;
        }

        // Off the loader lock the writer was joined by shutdown(), so the unique_ptr destroys the Impl normally. ~Impl
        // calls shutdown() again, but the Async->Stopping state CAS makes that an idempotent no-op before the members
        // are freed.
    }

    void AsyncLogger::arm_retention_root(const std::shared_ptr<AsyncLogger> &self) noexcept
    {
        m_retention_root = self;
    }

    void AsyncLogger::release_retention_root() noexcept
    {
        m_retention_root.reset();
    }

    void AsyncLogger::set_timestamp_format(std::string timestamp_format) noexcept
    {
        m_impl->set_timestamp_format(std::move(timestamp_format));
    }

    void AsyncLogger::set_file_stream(std::shared_ptr<detail::WinFileStream> file_stream) noexcept
    {
        m_impl->set_file_stream(std::move(file_stream));
    }

    bool AsyncLogger::enqueue(LogLevel level, std::string_view message) noexcept
    {
        return m_impl->enqueue(level, message, nullptr);
    }

    bool AsyncLogger::enqueue_from_facade(
        LogLevel level,
        std::string_view message,
        std::atomic<std::size_t> &facade_drops
    ) noexcept
    {
        return m_impl->enqueue(level, message, &facade_drops);
    }

    bool AsyncLogger::flush_with_timeout(std::chrono::milliseconds timeout) noexcept
    {
        return m_impl->flush_with_timeout(timeout);
    }

    void AsyncLogger::flush() noexcept
    {
        m_impl->flush();
    }

    void AsyncLogger::shutdown() noexcept
    {
        m_impl->shutdown();
    }

    bool AsyncLogger::is_running() const noexcept
    {
        return m_impl->is_running();
    }

#if defined(DMK_ENABLE_TEST_SEAMS)
    bool AsyncLogger::is_writer_waiting() const noexcept
    {
        return m_impl->is_writer_waiting();
    }
#endif

    size_t AsyncLogger::queue_size() const noexcept
    {
        return m_impl->queue_size();
    }

    size_t AsyncLogger::dropped_count() const noexcept
    {
        return m_impl->dropped_count();
    }

    void AsyncLogger::reset_dropped_count() noexcept
    {
        m_impl->reset_dropped_count();
    }

    bool AsyncLogger::writer_was_detached() const noexcept
    {
        return m_impl->writer_was_detached();
    }

} // namespace DetourModKit
