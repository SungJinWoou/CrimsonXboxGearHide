#ifndef DETOURMODKIT_INTERNAL_CONFIG_PASS_HPP
#define DETOURMODKIT_INTERNAL_CONFIG_PASS_HPP

/**
 * @file internal/config_pass.hpp
 * @brief Data-plane pass vocabulary owned by config.cpp.
 * @details The reload control plane (src/internal/config_reload.cpp) and the watcher control plane (config_watch.cpp)
 *          drive the registry pass and the combo grammar through this seam. The registry state, the SimpleIni
 *          pipeline, and the grammar itself stay confined to config.cpp.
 */

#include "internal/config_diagnostics.hpp"

#include "DetourModKit/input.hpp"

#include <filesystem>
#include <string>
#include <string_view>

namespace DetourModKit::config::detail
{
    class BackgroundReloadGuard;

    /**
     * @brief Reloads configuration and reports whether setters ran.
     * @param[out] out_setters_ran True once at least one deferred setter is invoked. False when the hash skip, a
     *                             read/parse failure, an empty setter list, or an unload latch stopped the pass before
     *                             the first setter.
     * @param background_guard Optional admission guard for a background pass. The setter loop aborts when the guard
     *                         leaves its enabled lifecycle mid-pass.
     * @return true if a previous load() path was available. False if reload() preceded any load(), or if
     *         ReloadApplyLock refused a same-thread re-entry.
     */
    [[nodiscard]] bool reload_impl(bool &out_setters_ran, const BackgroundReloadGuard *background_guard = nullptr);

    /// Takes the config mutex and returns a tear-free copy of the INI path last passed to load().
    [[nodiscard]] std::string snapshot_last_loaded_ini_path();

    /**
     * @brief Determines the full INI path and records each diagnostic for later emission.
     * @details @p ini_filename is UTF-8. An ill-formed name or an embedded NUL returns an empty path with an Error
     *          record.
     */
    [[nodiscard]] std::filesystem::path get_ini_file_path(const std::string &ini_filename, DeferredDiagnostics &diags);

    /**
     * @brief Parses a comma-separated string of key combos (OR logic) into a KeyComboList.
     * @details Two opt-out sentinels yield an empty result silently: an empty post-trim input and the literal
     *          "NONE". A non-empty non-sentinel input whose every token fails to parse is a user typo and
     *          records one WARNING that names @p binding_log_name (or "<unnamed>").
     */
    [[nodiscard]] input::KeyComboList
    parse_key_combo_list(const std::string &input, DeferredDiagnostics &diags, std::string_view binding_log_name = {});

    /**
     * @brief Registers the combo config item that rebinds @p binding_name on every load() and reload().
     * @details The item applies the parsed @p default_combo at registration. A rebind of an unknown name is a no-op.
     */
    void bind_combo_rebind_item(
        std::string_view section,
        std::string_view ini_key,
        std::string_view log_name,
        std::string_view binding_name,
        std::string_view default_combo
    );
} // namespace DetourModKit::config::detail

#endif // DETOURMODKIT_INTERNAL_CONFIG_PASS_HPP
