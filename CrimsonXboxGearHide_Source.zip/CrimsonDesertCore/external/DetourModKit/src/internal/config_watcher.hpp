#ifndef DETOURMODKIT_INTERNAL_CONFIG_WATCHER_HPP
#define DETOURMODKIT_INTERNAL_CONFIG_WATCHER_HPP

/**
 * @file config_watcher.hpp
 * @brief Internal filesystem watcher engine that triggers a callback when an INI file changes.
 * @details This is the private engine that backs config::enable_auto_reload / disable_auto_reload. It is reached only
 *          through the config module's pimpl orchestration, carries the Win32 ReadDirectoryChangesW pump, and is never
 *          installed. The config surface owns the watcher's lifetime; consumers do not see this type.
 */

#include "internal/config_diagnostics.hpp"

#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <string_view>
#include <thread>

namespace DetourModKit
{
    namespace detail
    {
        struct ConfigWatcherStartGate;

        /**
         * @class ConfigWatcher
         * @brief Background watcher for a single INI config file.
         * @details Owns a StoppableWorker that opens the INI file's parent directory via ReadDirectoryChangesW and
         *          fires @p on_reload when the target file is modified. Consecutive change events within the debounce
         *          window collapse to a single callback so editor save-flurries (Notepad++ / VSCode atomic save,
         *          rename-swap-save, last-write-time tick) do not cause redundant reloads.
         *
         *          Detected change kinds:
         *            - FILE_NOTIFY_CHANGE_LAST_WRITE  (plain save in place)
         *            - FILE_NOTIFY_CHANGE_SIZE        (truncation or growth)
         *            - FILE_NOTIFY_CHANGE_FILE_NAME   (rename-swap-save pattern,
         *              where the editor writes to a sibling temp and renames it over the target)
         *
         *          Filename matching is case-insensitive (Windows filesystem convention). The watcher does not recurse
         *          into subdirectories.
         *
         *          Non-copyable, non-movable. The watcher owns a worker thread and a directory handle; neither would
         *          survive a duplicated or moved owner.
         *
         * @warning The @p on_reload callback is invoked on the watcher's background thread. Callers must handle their
         *          own synchronization if the callback touches shared state. An exception escaping the callback is
         *          caught at the invocation site, logged as an error, and swallowed, so the watcher keeps pumping. This
         *          containment is mandatory rather than cosmetic: letting a throw unwind the worker body would free the
         *          in-flight ReadDirectoryChangesW OVERLAPPED and notification buffer before the kernel notify IRP is
         *          drained. The StoppableWorker body handler remains only a last-resort backstop for a non-callback
         *          throw.
         */
        class ConfigWatcher
        {
        public:
            using StartGate = std::shared_ptr<ConfigWatcherStartGate>;

            /**
             * @brief Constructs a watcher for @p ini_path.
             * @param ini_path Absolute or relative UTF-16 path to the INI file to monitor. The watcher opens the parent
             *                 directory for change notifications. The file does not need to exist at construction.
             * @param debounce Quiet-window length. A callback fires only after @p debounce has elapsed since the last
             *                 matching change event.
             * @param on_reload Callback invoked on the watcher thread when a debounced change is observed. May be empty
             *                  to construct an inert watcher.
             */
            explicit ConfigWatcher(
                std::wstring_view ini_path,
                std::chrono::milliseconds debounce = std::chrono::milliseconds{250},
                std::function<void()> on_reload = {}
            );

            ~ConfigWatcher() noexcept;

            ConfigWatcher(const ConfigWatcher &) = delete;
            ConfigWatcher &operator=(const ConfigWatcher &) = delete;
            ConfigWatcher(ConfigWatcher &&) = delete;
            ConfigWatcher &operator=(ConfigWatcher &&) = delete;

            /**
             * @brief Starts the background watcher thread.
             * @details Repeated calls leave an active watcher unchanged. The worker opens the parent directory and
             *          queues the first ReadDirectoryChangesW request before it notifies the caller. A true result
             *          means I/O is active. The lock order is watcher mutex, start mutex, then startup-channel mutex.
             * @param diags Collects each caller-side and pre-handshake diagnostic.
             * @param gate Receives the worker release gate. Release it after the caller unlocks its control mutex.
             * @return true if the worker becomes active or is already active. Returns false after an open failure,
             *         handshake timeout, or pre-handshake exception. The watcher stays stopped after each reported
             *         failure.
             */
            [[nodiscard]] bool start(config::detail::DeferredDiagnostics &diags, StartGate &gate);

            /**
             * @brief Releases a worker after its caller exits the control-mutex scope.
             *
             * @param gate The gate returned by the record-list start overload. A null gate is a no-op.
             */
            static void release_start_gate(const StartGate &gate) noexcept;

            /**
             * @brief Starts the watcher and emits its diagnostics before worker release.
             *
             * @details Use this overload only when the caller holds no lock that a sink call can span.
             */
            [[nodiscard]] bool start();

            /**
             * @brief Stops the background watcher thread synchronously.
             * @details Idempotent. Safe to call before start() or multiple times. Blocks until the worker exits, unless
             *          the current thread holds the Windows loader lock, in which case the worker is detached (see
             *          StoppableWorker::shutdown()). This is an honest synchronous rundown: it includes the
             *          notification drain (bounded to ~2 * DRAIN_TIMEOUT_MS), a final debounced @p on_reload callback
             *          if a change is still pending, and the thread join. The drain and join are bounded, but the final
             *          callback runs synchronously, so a callback that blocks makes stop() block for exactly as long.
             *          It is not a time-bounded operation and does not detach a running callback; a caller that needs
             *          a hard bound must make its callback cooperative.
             * @note Because a change that arrived within the debounce window but had not yet fired triggers one final
             *       @p on_reload callback during this stop, stop() does not guarantee that no further callback runs.
             *       Callers that must observe no callback after stopping should latch their own flag.
             */
            void stop() noexcept;

            /// Requests worker stop without locking, joining, or destroying callback storage.
            void request_stop() noexcept;

            /**
             * @brief Returns true after the worker body has exited, or when no worker was started.
             * @details A true result authorizes the control plane to call stop() without waiting on user callback code.
             */
            [[nodiscard]] bool has_exited() const noexcept;

            /**
             * @brief Returns true while the watcher thread is still alive.
             */
            [[nodiscard]] bool is_running() const noexcept;

            /**
             * @brief Returns the INI file path this watcher is monitoring.
             */
            [[nodiscard]] const std::wstring &ini_path() const noexcept;

            /**
             * @brief Returns the configured debounce duration.
             */
            [[nodiscard]] std::chrono::milliseconds debounce() const noexcept;

            /**
             * @brief Returns true if @p id names the background worker thread.
             * @details Lets a stop request detect a setter-induced self-call (a reload callback that, running on the
             *          worker thread, tries to tear the watcher down) and avoid joining the worker from the worker
             *          itself, which would otherwise raise std::system_error(resource_deadlock_would_occur). The worker
             *          publishes its id when its thread
             *          starts (before the first overlapped read is issued) and clears it on exit, so this returns false
             *          before the worker thread has started and after the worker has exited (including after stop() has
             *          joined it); a later OS-recycled thread id therefore cannot alias a dead worker and suppress a
             *          real stop.
             * @param id The thread id to compare against.
             * @return true only while the worker is running and @p id equals its thread id; the default (no-thread) id
             *         never matches.
             */
            [[nodiscard]] bool is_worker_thread(std::thread::id id) const noexcept;

        private:
            struct Impl;

            // Move an Impl into a never-freed heap cell and record the intentional leak, releasing the unique_ptr on
            // allocation failure so the storage still leaks without running ~Impl. Both husk paths (the loader-lock
            // teardown and the start leak-on-timeout) share this exact dance, so it lives in one private helper.
            static void leak_impl_storage(std::unique_ptr<Impl> &impl) noexcept;

            /**
             * @brief Keeps a live worker, or joins and drops an exited worker.
             * @note The caller must hold start_mutex.
             * @return true when the worker body is live. @p gate then holds the release gate of that worker.
             */
            [[nodiscard]] bool keep_live_worker_or_drop_exited(StartGate &gate) noexcept;

            /**
             * @brief Drops the worker of a failed start, or husks the watcher after a handshake timeout.
             * @note The caller must hold start_mutex. A true @p started makes this call a no-op.
             */
            void clean_up_failed_start(bool started, bool handshake_timed_out) noexcept;

            std::unique_ptr<Impl> m_impl;
        };
    } // namespace detail
} // namespace DetourModKit

#endif // DETOURMODKIT_INTERNAL_CONFIG_WATCHER_HPP
