#ifndef DETOURMODKIT_INTERNAL_INPUT_INTERCEPT_HPP
#define DETOURMODKIT_INTERNAL_INPUT_INTERCEPT_HPP

/**
 * @file input_intercept.hpp
 * @brief Internal active-input layer driven by InputPoller.
 * @details The layer masks digital gamepad buttons and captures wheel events for InputPoller.
 *          It owns both XInput hooks, code-provider references, and shared atomic data.
 *          Retained hooks keep their executable chains and native TLS owners until process exit.
 *
 *          [B-95] serializes owner changes and data writes. Lock order: s_intercept_mutex, then the data-plane lock.
 *          Detours take neither lock. They use atomics, numeric native TLS, and the rule seqlock.
 *          This Windows-only header remains private.
 */

#include <windows.h>
#include <xinput.h>

#include <array>
#include <cstddef>
#include <cstdint>
#include <string_view>

namespace DetourModKit::detail
{
    /// Function-pointer type for XInputGetState and the ordinal-100 XInputGetStateEx.
    using XInputGetStateFn = DWORD(WINAPI *)(DWORD, XINPUT_STATE *);

    /**
     * @struct WheelPulseState
     * @brief Poll-thread-private state that turns queued wheel notches into single-cycle pulses.
     * @details The wheel has no released state, so the poll loop synthesizes one:
     *          a notch reads as "pressed" for exactly one cycle, then is forced low for one cycle so the edge detector
     *          re-arms. Without the forced gap a continuous scroll would read as one long press and fire only once.
     *          Indices are 0=Up, 1=Down, 2=Left, 3=Right.
     */
    struct WheelPulseState
    {
        /// Unconsumed notches per direction.
        std::array<int, 4> pending{};
        /// Whether the previous cycle emitted a pulse.
        std::array<bool, 4> pulsing{};
    };

    /**
     * @brief Maximum unconsumed notches retained per direction.
     * @details The pulse stepper drains at most one notch per direction every two poll cycles (one cycle pulses, the
     *          next forces the re-arm gap), so a scroll faster than that drain accumulates a backlog. Capping it bounds
     *          how long phantom notches can replay after the user stops scrolling; a real burst rarely exceeds this,
     *          and dropping the tail of an extreme burst is preferable to an unbounded replay queue.
     */
    inline constexpr int MAX_WHEEL_PENDING = 16;

    /**
     * @brief Advances the wheel pulse state machine by one poll cycle.
     * @param state Per-direction pulse state, carried across cycles.
     * @return Bitmask of directions pressed this cycle (bit 0 = Up .. bit 3 = Right).
     */
    [[nodiscard]] uint8_t step_wheel_pulse(WheelPulseState &state) noexcept;

    /**
     * @brief Adds freshly drained wheel notches to the pending backlog, capped.
     * @details Each retained notch still maps to one Press edge via step_wheel_pulse;
     *          this only bounds the carried-over backlog per direction to @ref MAX_WHEEL_PENDING so a sustained fast
     *          scroll cannot queue notches faster than they drain. Negative inputs are ignored so a corrupt count
     *          cannot drive pending negative and underflow the drain.
     * @param state Pulse state whose pending counts are updated in place.
     * @param taken Notch counts just drained from the detour, indexed 0=Up..3=Right.
     */
    void add_wheel_notches(WheelPulseState &state, const std::array<int, 4> &taken) noexcept;

    /**
     * @struct GamepadSuppressState
     * @brief Poll-thread-private consume-until-release latch for suppressed gamepad buttons.
     */
    struct GamepadSuppressState
    {
        /// Currently suppressed XInput button bits.
        uint16_t armed{0};
        /// Per-bit release deadline; a held bit uses the sentinel.
        std::array<uint64_t, 16> deadline_ms{};
    };

    /**
     * @brief Advances the gamepad suppression latch by one poll cycle.
     * @details A bit stays suppressed from the moment an active consume chord claims it (@p owned_now) until the
     *          physical button is released (@p true_buttons no longer has it) plus @p grace_ms. This closes the
     *          modifier-released-before-trigger window: releasing the modifier a frame before the trigger cannot leak a
     *          bare trigger to the game, because suppression is latched to the trigger button's own lifetime, not the
     *          chord's.
     * @param state Latch state carried across cycles.
     * @param owned_now Digital button bits the active consume chords claim this cycle (each bit's physical button is
     *                  already known pressed).
     * @param true_buttons The unmasked XINPUT_GAMEPAD.wButtons read this cycle.
     * @param now_ms Monotonic millisecond timestamp for this cycle.
     * @param grace_ms Release grace window in milliseconds.
     * @return Bitmask of button bits to clear from the game's state this cycle.
     */
    [[nodiscard]] uint16_t step_gamepad_suppress(
        GamepadSuppressState &state,
        uint16_t owned_now,
        uint16_t true_buttons,
        uint64_t now_ms,
        uint64_t grace_ms
    ) noexcept;

    /**
     * @struct GamepadConsumeRule
     * @brief A consume chord reduced to the XInput button bits the detour can evaluate without the poll thread.
     * @details The reactive (poll-published) mask trails the physical state by up to one poll cycle. A rule lets the
     *          detour mask the trigger against the exact snapshot that the game is about to read. This closes the
     *          window.
     *          Built only from chords whose modifiers and masked triggers are all digital gamepad buttons, so the
     *          decision is fully reproducible from XINPUT_GAMEPAD.wButtons alone.
     */
    struct GamepadConsumeRule
    {
        /// Digital button bits that must all be held.
        uint16_t modifier_mask{0};
        /// Known-modifier bits outside this chord; any held rejects it (strict match).
        uint16_t forbidden_mask{0};
        /// Digital button bits to clear when the chord matches.
        uint16_t trigger_mask{0};
    };

    /**
     * @brief Maximum number of consume rules the detour evaluates.
     * @details The bound is the detour's storage, not a policy: a longer list publishes its first this-many rules and
     *          drops the remainder. Evaluation ORs each matching rule's trigger
     *          mask, so a dropped rule costs exactly its own chord the leading-edge protection and costs the retained
     *          rules nothing.
     */
    inline constexpr std::size_t MAX_GAMEPAD_CONSUME_RULES = 32;

    /**
     * @struct ConsumePublish
     * @brief Outcome of an attempted consume-rule publication.
     */
    struct ConsumePublish
    {
        /// False when the caller did not hold the layer, in which case nothing was written.
        bool authorized{false};
        /// Rules actually written, which is @c min(count, MAX_GAMEPAD_CONSUME_RULES) when authorized and 0 otherwise.
        std::size_t published{0};
    };

    /**
     * @brief Evaluates consume rules against a raw button snapshot.
     * @details Pure helper shared by the XInput detour and its tests. A rule contributes its @ref
     *          GamepadConsumeRule::trigger_mask when every @ref GamepadConsumeRule::modifier_mask bit is present in @p
     *          true_buttons and no @ref GamepadConsumeRule::forbidden_mask bit is. Masking a trigger bit that is not
     *          currently down is a no-op against the game's state, so a rule may match before its trigger is pressed
     *          without observable effect.
     * @param true_buttons The unmasked XINPUT_GAMEPAD.wButtons the game will read.
     * @param rules Pointer to @p count contiguous rules (may be nullptr if 0).
     * @param count Number of rules.
     * @return Button bits to clear from the game's state.
     */
    [[nodiscard]] uint16_t
    evaluate_consume_rules(uint16_t true_buttons, const GamepadConsumeRule *rules, std::size_t count) noexcept;

    /**
     * @brief Publishes the consume rule list read by the XInput detour, if @p owner still holds the layer.
     * @details Copies up to @ref MAX_GAMEPAD_CONSUME_RULES rules behind a seqlock so a detour on a game thread reads a
     *          consistent snapshot without locking. A @p count above the cap publishes the first @ref
     *          MAX_GAMEPAD_CONSUME_RULES; the caller derives the shortfall from the result and owns the diagnosis.
     *          Rule masking shares the reactive mask's time-to-live (rules exist only while consume gamepad bindings
     *          do, which is exactly when publish_gamepad_suppress refreshes the deadline), so a stalled poll thread
     *          stops rule masking too.
     * @param rules Pointer to @p count contiguous rules (may be nullptr if 0).
     * @param count Number of rules offered.
     * @param owner Nonzero owner id that must equal the live layer owner; any other value writes nothing.
     */
    [[nodiscard]] ConsumePublish
    publish_gamepad_consume_rules(const GamepadConsumeRule *rules, std::size_t count, std::uint64_t owner) noexcept;

    /**
     * @brief Reads the published consume rule list and evaluates it against a raw button snapshot.
     * @details The XInput detour's rule-read side, exported for testing. Reads the seqlock-guarded rule list in a
     *          single attempt (a torn or mid-update snapshot yields 0) and returns evaluate_consume_rules over it. This
     *          is independent of the focus gate (see set_gamepad_rule_suppress_enabled), which the detour applies
     *          separately.
     * @param true_buttons The unmasked XINPUT_GAMEPAD.wButtons the game will read.
     * @return Button bits the currently published rules would clear.
     */
    [[nodiscard]] uint16_t evaluate_published_consume_rules(uint16_t true_buttons) noexcept;

    /**
     * @brief Enables or disables detour-side consume-rule masking, if @p owner still holds the layer.
     * @details Gates whether the XInput detour evaluates the published rule list. The poll thread drives this every
     *          cycle so rule masking stops the instant the host window loses focus or the controller disconnects,
     *          matching the reactive mask (which the poll loop clears to 0 on focus loss) and the mouse-wheel consume
     *          flag. Without it the detour would keep masking the foreground game's gamepad input while the mod is in
     *          the background, because the published rule list and its time-to-live both stay alive across focus
     *          changes.
     * @param enabled True to evaluate rules, false to skip them.
     * @param owner Nonzero owner id that must equal the live layer owner; any other value changes nothing.
     * @return true when the gate was written.
     */
    [[nodiscard]] bool set_gamepad_rule_suppress_enabled(bool enabled, std::uint64_t owner) noexcept;

    /**
     * @brief Owner id for a standalone caller (tests, direct install/uninstall) that drives the layer without a poller.
     * @details Zero is reserved for the unowned state. Pollers use ids from next_intercept_owner().
     */
    inline constexpr std::uint64_t STANDALONE_INTERCEPT_OWNER = 1;

    /**
     * @brief Draws an interception-owner id distinct from the two reserved values.
     * @details Each poller retains one id across installation and teardown so a superseded poller cannot remove a newer
     *          poller's hooks.
     */
    [[nodiscard]] std::uint64_t next_intercept_owner() noexcept;

    /// Reports whether the interception layer is currently held by the nonzero @p owner.
    [[nodiscard]] bool intercept_owned_by(std::uint64_t owner) noexcept;

    // XInput interception (gamepad passthrough suppression)

    /**
     * @brief Installs the XInputGetState hook pair for the given controller index under @p owner.
     * @details Both required exports form one transaction. An absent or aliased ordinal 100 needs no second hook.
     *          Both hooks start disabled. Target modules and retained storage receive references before publication.
     *          Creation failure leaves ownership unchanged. Ambiguous target bytes retain any reachable chain.
     *
     *          Exact patch witnesses authorize owned entries. Foreign entries require scoped calls through both
     *          exports, matching detour receipts, successful controller samples, and an unchanged final snapshot.
     *          A receipt proves only its invocation. A conditional foreign handler can bypass other callers.
     *          Every maintenance call checks both members. A failed check disarms both detours.
     *
     *          Recovery uses each member's existing hook. Failed re-arms receive a bounded retry delay.
     *          Owner, target, or member changes reset that delay. Foreign calls run outside every DMK lock.
     * @param user_index Controller whose state can receive a mask.
     * @param owner Nonzero interception-layer owner id.
     * @return True when both required routes have exact or observed evidence for this owner. Otherwise false.
     * @note Best-effort. An upstream handler has no execution deadline. Revoked probe leases retain executable
     *       chains when the teardown deadline expires. Exact witnesses still govern every byte mutation.
     */
    [[nodiscard]] bool install_xinput(int user_index, std::uint64_t owner = STANDALONE_INTERCEPT_OWNER) noexcept;

    /**
     * @brief Returns whether paired route evidence currently authorizes XInput suppression.
     * @details False after a failed paired check or logical teardown. Maintenance can restore authorization.
     */
    [[nodiscard]] bool xinput_installed() noexcept;

    /**
     * @brief Returns the published original XInputGetState chain, or nullptr after logical teardown.
     * @details A degraded live pair retains its chain. The caller must hold the provider's lifetime.
     *          Pollers use sample_xinput_raw_state instead, so every compatible copy receives raw controller state.
     */
    [[nodiscard]] XInputGetStateFn xinput_trampoline() noexcept;

    /**
     * @brief Samples the current export without suppression by compatible DMK copies.
     * @details A refused scope skips the provider call and leaves state unchanged.
     *          Trampolines can traverse another compatible copy's suppression.
     * @param user_index Controller to sample.
     * @param state Receives the raw controller state.
     * @param owner The poller's interception owner.
     * @return False after a failed scope, disconnected controller, or TLS restore failure.
     * @note The poller must retain a raw-scope owner across its complete worker lifetime.
     */
    [[nodiscard]] bool sample_xinput_raw_state(
        DWORD user_index,
        XINPUT_STATE &state,
        std::uint64_t owner = STANDALONE_INTERCEPT_OWNER
    ) noexcept;

    /**
     * @brief Publishes the set of button bits the XInput detour should suppress, if @p owner still holds the layer.
     * @details Refreshes a short time-to-live alongside the mask so that if the poll thread stops refreshing it
     *          (crash/hang) the detour stops masking and the game regains its input rather than latching forever.
     * @param suppress_bits Button bits to clear; 0 disables masking.
     * @param owner Nonzero owner id that must equal the live layer owner; any other value writes nothing.
     * @return true when the mask was written.
     */
    [[nodiscard]] bool publish_gamepad_suppress(uint16_t suppress_bits, std::uint64_t owner) noexcept;

    // Mouse-wheel capture (thread-scoped WH_GETMESSAGE hook)

    /**
     * @brief Wheel direction bit positions in the per-direction consume mask.
     * @details A single wheel message carries exactly one direction. The bit order matches WheelPulseState / the
     *          s_wheel_count slots (0=Up, 1=Down, 2=Left, 3=Right) so the poll loop, the pulse machine, and the hook
     *          callback agree on indexing.
     */
    enum class WheelDirection : uint8_t
    {
        Up = 1u << 0,
        Down = 1u << 1,
        Left = 1u << 2,
        Right = 1u << 3,
    };

    /// Returns the mask bit for a wheel direction.
    [[nodiscard]] constexpr uint8_t wheel_direction_bit(WheelDirection direction) noexcept
    {
        return static_cast<uint8_t>(direction);
    }

    /**
     * @brief Hard ceiling on the raw per-direction wheel-notch counter the local wheel hook accumulates.
     * @details `[B-25]` The poll loop drains the counter only while a wheel binding exists. The hook stays mounted
     *          until shutdown, so an undrained counter accretes idle notches toward signed overflow.
     *          Write-site saturation bounds it regardless of poll-thread liveness. The ceiling is far above
     *          any real burst, so only the pathological idle-accretion case saturates.
     */
    inline constexpr int MAX_WHEEL_NOTCHES = 1024;

    /**
     * @enum WheelRouteState
     * @brief Typed health of the local wheel route. Values mirror the DMK_WHEELHOST_ROUTE_* C ABI states.
     */
    enum class WheelRouteState : std::uint8_t
    {
        /// No target thread is mounted. A mount attempt with a valid target can succeed.
        TargetWait = 0,
        /// The hook is mounted and the target thread is alive.
        Ready = 1,
        /// The route was lost or disabled (target exit, failed mount, or a failed drain). A remount can succeed.
        Retryable = 2,
        /// Old-hook removal failed on a live thread. New mounts are blocked until that thread exits.
        CleanupBlocked = 3,
    };

    /**
     * @brief Mounts or migrates the local WH_GETMESSAGE wheel source onto @p target_thread_id under @p owner.
     * @details One transaction serves the fresh mount, the idempotent same-thread call, and the migration to a new
     *          thread. A migration disables capture, advances the epoch, drains admitted callback phases (bounded),
     *          and removes the old hook before the new hook mounts, so hooks never overlap. A removal failure on a
     *          live thread publishes @ref WheelRouteState::CleanupBlocked and blocks the new mount. Takes a permanent
     *          MessageHookKeepalive on the first successful publication, because Windows permits a selected hook
     *          callback to run after UnhookWindowsHookEx returns.
     * @param owner Nonzero interception-layer owner id shared with the XInput hook.
     * @param target_thread_id The UI thread to mount on. It must belong to this process and be alive.
     * @return true when the hook is mounted on @p target_thread_id for this owner; false when the target is invalid,
     *         the transaction is blocked, or another owner holds the layer. message_hook_route_state() carries the
     *         failure detail.
     */
    [[nodiscard]] bool install_message_hook(std::uint64_t owner, std::uint32_t target_thread_id) noexcept;

    /**
     * @brief Returns whether the local wheel hook is mounted on a live target thread.
     * @details Derived from the live thread handle, never from a sticky installed flag: a dead target retires the
     *          route and reads false.
     */
    [[nodiscard]] bool message_hook_installed() noexcept;

    /**
     * @brief Returns the settled local route state after a target-liveness recheck.
     * @details A cleanup-blocked route whose old thread exited becomes Retryable here.
     */
    [[nodiscard]] WheelRouteState message_hook_route_state() noexcept;

    /// Returns the mounted target thread id, or 0 while no live route exists.
    [[nodiscard]] std::uint32_t message_hook_thread_id() noexcept;

    /// Returns the local mount generation. A successful mount or migration increments it once.
    [[nodiscard]] std::uint64_t message_hook_mount_generation() noexcept;

    /**
     * @brief Atomically takes and clears the accumulated wheel notch counts, if @p owner still holds the layer.
     * @details Consuming notches is a destructive read of state the owner's poll loop is entitled to, so a non-owner
     *          reads all zeros and leaves the counters intact rather than swallowing the owner's backlog.
     * @param owner Nonzero owner id that must equal the live layer owner.
     * @return Notch counts since the last call, indexed 0=Up, 1=Down, 2=Left, 3=Right; all zero for a non-owner.
     */
    [[nodiscard]] std::array<int, 4> take_wheel_counts(std::uint64_t owner) noexcept;

#if defined(DMK_ENABLE_TEST_SEAMS)
    /// Claims the idle layer for STANDALONE_INTERCEPT_OWNER without installing a hook.
    [[nodiscard]] bool acquire_standalone_lease_for_test() noexcept;

    /// Releases the test-only standalone lease and clears the data it authorized.
    void release_standalone_lease_for_test() noexcept;

    /**
     * @brief Test-only: stages a wheel-notch backlog as if the wheel hook had latched @p notches.
     * @details The hook callback increments the counters only from a real WM_MOUSEWHEEL / WM_MOUSEHWHEEL retrieval,
     *          which the unit suite cannot deliver without a pumped queue. This seam lets a white-box test stand up
     *          the exact stale-backlog state that the poll loop's drain and recompute's no-wheel -> wheel discard
     *          exist to handle, so those paths are exercised deterministically. Each slot saturates at
     *          MAX_WHEEL_NOTCHES, matching the hook's write site. Compiled out of shipping archives.
     */
    void seed_wheel_notches_for_test(const std::array<int, 4> &notches) noexcept;
#endif

    /**
     * @brief Publishes the set of wheel directions the wheel hook should swallow this cycle.
     * @details Uses a per-direction mask so a chord such as "Ctrl+WheelUp" eats neither a bare WheelDown nor an
     *          unmodified WheelUp. The poll loop evaluates each consume wheel binding's modifiers every cycle and
     *          unions the owned direction bits (see WheelDirection). Like the gamepad reactive suppression mask, the
     *          hook only swallows a message whose own direction bit is set. A short time-to-live is refreshed
     *          alongside a non-zero mask so a stalled poll thread stops swallowing and the game regains its wheel.
     * @param direction_mask OR of WheelDirection bits to swallow; 0 forwards every wheel message.
     * @param require_focus When true, count admission and consume finalization also require process foreground.
     * @param owner Nonzero owner id that must equal the live layer owner; any other value writes nothing.
     * @return true when the mask was written. A closed wheel capture refuses the mask.
     */
    [[nodiscard]] bool publish_wheel_consume(uint8_t direction_mask, bool require_focus, std::uint64_t owner) noexcept;

    /**
     * @brief Tears down both interceptors and stops all masking, if @p owner still holds the layer.
     * @details Retires the owner before touching backend state. XInput removal drains game detours and requires
     *          Original byte witnesses for both hooks; timeout, foreign ownership, an unreadable window, or an
     *          unconfirmed toggle retains the pair and keepalives without allocation. The two raw members are one
     *          transaction: a primary restore that refuses after the ordinal-100 restore committed re-arms that member
     *          before retaining, so retention never drops an entry point the pair covered on entry. Wheel-hook
     *          removal drains admitted callback phases (bounded) after the epoch advance, then removes the OS hook.
     *          Idempotent.
     * @param owner Nonzero interception-layer owner id. Any non-owner returns without changing the installation.
     * @warning Never call under the loader lock, and never before the poll thread has been joined: that thread reads
     *          the current XInput export, and raw hook teardown registers VEH state and rewrites executable
     *          pages.
     */
    void uninstall(std::uint64_t owner = STANDALONE_INTERCEPT_OWNER) noexcept;

#if defined(DMK_ENABLE_TEST_SEAMS)
    /// Seam signature; see set_xinput_detour_body_seam.
    using XInputDetourBodySeam = void (*)() noexcept;

    /// Seam signature; see set_xinput_arm_seam.
    using XInputArmSeam = void (*)() noexcept;

    /// Seam signature; see set_xinput_clean_release_seam.
    using XInputCleanReleaseSeam = void (*)() noexcept;

    /// Seam signature for the allocation-free XInput retention attribution probe.
    using XInputRetentionAttributionSeam = void (*)(std::string_view) noexcept;

    /// Seam signature; see set_xinput_create_seam.
    using XInputCreateSeam = void (*)() noexcept;

    /**
     * @brief Installs a probe that runs inside an XInput detour body while its in-flight guard is held.
     * @details The only way to park a caller inside a detour deterministically, which is what makes uninstall()'s
     *          bounded drain time out on demand. Null clears it. Compiled out of shipping archives.
     */
    void set_xinput_detour_body_seam(XInputDetourBodySeam seam) noexcept;

    /// Holds or releases a raw-XInput caller after stable route admission but before the C++ detour body.
    void set_xinput_route_entry_hold_for_test(bool hold) noexcept;

    /// Reports whether a raw-XInput caller reached the stable pre-body route park.
    [[nodiscard]] bool xinput_route_entry_reached_for_test() noexcept;

    /**
     * @brief Runs a probe after both raw targets are witnessed restored and immediately before hook-object release.
     * @details Lets a lifecycle proof poison allocation only across the clean noexcept release boundary. Null clears
     *          the probe.
     */
    void set_xinput_clean_release_seam(XInputCleanReleaseSeam seam) noexcept;

    /**
     * @brief Installs a probe that receives the fixed-buffer XInput retention attribution.
     * @details The probe runs after the interception lock is released.
     *          A null value clears it.
     */
    void set_xinput_retention_attribution_seam(XInputRetentionAttributionSeam seam) noexcept;

    /**
     * @brief Runs a probe after a raw hook's isolated allocator exists and before backend construction begins.
     * @details Lets the lifecycle proof poison only allocations made inside InlineHook::create. Null clears it.
     */
    void set_xinput_create_seam(XInputCreateSeam seam) noexcept;

    /**
     * @brief Arms one raw-XInput backend toggle exception at @p target.
     * @param target Exact backend target, or nullptr to disarm the seam.
     * @param after_mutation true to throw after the byte mutation; false to throw before it.
     */
    void set_xinput_backend_toggle_exception_for_test(void *target, bool after_mutation) noexcept;

    /// Returns how many raw-XInput backend exceptions the current test arm reached and contained.
    [[nodiscard]] std::size_t xinput_backend_toggle_exception_catches_for_test() noexcept;

    /**
     * @brief Installs a probe between a raw-XInput backend toggle and the witness read that judges it.
     * @details The only deterministic way to place a competing prologue writer in that exact window. Null clears it.
     */
    void set_xinput_arm_seam(XInputArmSeam seam) noexcept;

    /// Reports whether a claimed layer lacks paired route authorization.
    [[nodiscard]] bool xinput_pair_degraded_for_test() noexcept;

    /**
     * @struct XInputPairCoverage
     * @brief Separates evidence for each required pair member.
     * @details The exact witness query treats an absent or aliased ordinal 100 as covered.
     *          The observation query reports receipts only for required members.
     */
    struct XInputPairCoverage
    {
        bool primary{false};
        bool ex{false};
    };

    /// Re-witnesses both pair members' target bytes without changing published state.
    [[nodiscard]] XInputPairCoverage xinput_pair_coverage_for_test() noexcept;

    /** @brief Returns scoped route observations separately from exact-patch coverage. Test-only. */
    [[nodiscard]] XInputPairCoverage xinput_pair_observation_for_test() noexcept;

    /**
     * @brief Counts backend re-arm transactions the recovery gate has let through.
     * @details The observable difference between "the poll loop retried the backend" and "the poll loop was refused by
     *          the deadline", which is what makes the capped-delay contract measurable without timing the test.
     */
    [[nodiscard]] std::size_t xinput_recovery_attempts_for_test() noexcept;

    /**
     * @brief Expires the current recovery delay without resetting the accumulated backoff.
     * @details Lets a proof drive many recovery attempts deterministically instead of sleeping out a growing delay.
     * @return The accumulated delay that was expired, in milliseconds.
     */
    [[nodiscard]] std::uint64_t expire_xinput_recovery_delay_for_test() noexcept;

    /**
     * @brief Returns whether permanent storage currently owns a primary raw hook.
     * @details The result reports the permanent-retention latch on the canonical hook and keepalives.
     *          A false result does not describe backend storage. reset() can reclaim or retain that storage.
     */
    [[nodiscard]] bool xinput_permanent_primary_retained() noexcept;

    /**
     * @brief Counts XInput keepalives: 0 with no detour, 2 for one target module, or 3 for a forwarded Ex target.
     * @details A timeout or unproved restore leaves the same set in permanent storage. A clean teardown releases it.
     *          This seam excludes independent host pins on the XInput DLL.
     */
    [[nodiscard]] int xinput_module_refs_held() noexcept;

    /// Arms the B-100 process-exit oracle with a patched XInput target byte.
    void arm_xinput_process_exit_oracle_for_test(const std::uint8_t *target) noexcept;

    /**
     * @brief Overrides the module install_xinput() resolves XInputGetState from, bypassing the DLL-name search.
     * @details Lets a test select a synthetic proxy whose ordinal 100 is local or forwarded. Null clears the override.
     *          Compiled out of shipping archives.
     */
    void set_xinput_module_override_for_test(HMODULE module) noexcept;

    /**
     * @brief Returns the saved original XInputGetStateEx (ordinal-100) trampoline, or nullptr when no chain exists.
     * @details A committed arm keeps this non-null for callers admitted before its target became unreachable, even
     *          while the pair is degraded. Absent and aliased exports have no distinct chain.
     */
    [[nodiscard]] XInputGetStateFn xinput_ex_trampoline() noexcept;

    /// Applies the raw-XInput suppression gate to a synthetic state.
    void apply_xinput_suppress_for_test(XINPUT_STATE *state, DWORD user_index) noexcept;

    /// Returns the controller index most recently published by a successful install.
    [[nodiscard]] int xinput_bound_user_index() noexcept;

    /// Seam signature; see set_data_plane_entry_seam.
    using DataPlaneEntrySeam = void (*)() noexcept;

    /// Seam signature; see set_wheel_capture_entry_seam.
    using WheelCaptureEntrySeam = void (*)() noexcept;

    /**
     * @brief Installs a probe that runs on entry to a data-plane operation, before it takes the data-plane lock.
     * @details The only way to park a caller in the window between deciding to publish and being authorized to,
     *          which is what makes a revocation land against an already-entered publication on demand. Null clears it.
     *          Compiled out of shipping archives.
     */
    void set_data_plane_entry_seam(DataPlaneEntrySeam seam) noexcept;

    /**
     * @brief Installs a probe that runs inside wheel count admission, after the capture sample and before the
     *        epoch-tagged fold.
     * @details Lets a test park a callback frame inside the counted admission phase, or prove that owner revocation
     *          invalidates an already-entered capture without waiting for it and without polluting the successor's
     *          backlog. Null clears it. Compiled out of shipping archives.
     */
    void set_wheel_capture_entry_seam(WheelCaptureEntrySeam seam) noexcept;

    /// Seam signature; see set_wheel_finalize_entry_seam.
    using WheelFinalizeEntrySeam = void (*)() noexcept;

    /**
     * @brief Installs a probe that runs inside wheel consume finalization, before its revalidation.
     * @details Lets a test change focus, masks, or the epoch between count admission and the final WM_NULL write.
     *          Null clears it. Compiled out of shipping archives.
     */
    void set_wheel_finalize_entry_seam(WheelFinalizeEntrySeam seam) noexcept;

    /// Overrides the bounded wheel admitted-phase drain wait. Zero restores the default. Test-only.
    void set_wheel_drain_timeout_for_test(std::uint64_t timeout_ms) noexcept;

    /// Forces local message-hook removal to fail. False restores the OS call. Test-only.
    void set_message_unhook_failure_for_test(bool fail) noexcept;

    /// Overrides the wheel focus gate's foreground answer: 0 unfocused, 1 focused, negative restores the real query.
    void set_wheel_process_focus_for_test(std::int32_t focused) noexcept;

    /// Returns the count of resident callback frames currently inside a wheel admission phase. Test-only.
    [[nodiscard]] std::uint32_t wheel_admitted_phases_for_test() noexcept;

    /**
     * @brief Runs the complete wheel-message path for one signed delta (T-WHEEL).
     * @details Exactly the hook callback's handling: count admission (remainder accumulation under the live capture
     *          state and whole-notch publication into the drain counters), then the consume-finalization verdict
     *          against the published consume mask.
     * @return true when the real hook callback would swallow the message.
     */
    [[nodiscard]] bool process_wheel_message_for_test(bool horizontal, int delta) noexcept;

    /**
     * @brief Returns the consume-rule seqlock sequence.
     * @details Odd means a write bracket is open. A refused publication must leave it even and unchanged, which is the
     *          observable difference between refusing before the bracket and rolling one back.
     */
    [[nodiscard]] std::uint32_t consume_rules_sequence() noexcept;

    /// Returns the reactive gamepad mask currently published to the detour.
    [[nodiscard]] std::uint16_t gamepad_suppress_mask_for_test() noexcept;

    /// Returns whether detour-side consume-rule evaluation is enabled.
    [[nodiscard]] bool gamepad_rule_suppress_enabled_for_test() noexcept;

    /// Returns the wheel-direction consume mask currently published to the wheel hook.
    [[nodiscard]] std::uint8_t wheel_consume_mask_for_test() noexcept;

    /**
     * @brief Claims the idle layer for an arbitrary @p owner without installing a hook.
     * @details Owner-scoped paths are otherwise only reachable by installing, which needs a live XInput module or a
     *          top-level window that a unit-test process may not have. This grants the lease alone so a white-box case
     *          can drive an owning poller's drain and publication paths on any host. Fails while another owner holds
     *          the layer. Release through uninstall(owner). Compiled out of shipping archives.
     */
    [[nodiscard]] bool adopt_owner_for_test(std::uint64_t owner) noexcept;
#endif

} // namespace DetourModKit::detail

#endif // DETOURMODKIT_INTERNAL_INPUT_INTERCEPT_HPP
