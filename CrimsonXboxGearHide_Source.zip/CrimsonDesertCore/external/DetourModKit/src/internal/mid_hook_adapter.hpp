#ifndef DETOURMODKIT_INTERNAL_MID_HOOK_ADAPTER_HPP
#define DETOURMODKIT_INTERNAL_MID_HOOK_ADAPTER_HPP

/**
 * @file internal/mid_hook_adapter.hpp
 * @brief The backend-typed mid-hook dispatch pool: per-hook adapters, exception containment, and rundown.
 * @details A mid hook's callback is reached from a hand-emitted assembly stub that the backend calls directly. This
 *          pool places a DMK frame between the stub and the user callback, where exceptions can be contained and
 *          callback entries counted.
 *
 *          The backend's destination type is `void(*)(safetyhook::Context&)` and carries no user-data parameter, so the
 *          only way to reach a per-hook callback from an exactly typed function is to give each hook its own function.
 *          `mid_adapter<I>` is that function, and slot @p I supplies the identity the signature has no room to pass.
 *
 *          The adapter's exact backend type requires no function-pointer conversion or related warning suppression.
 *
 *          The opaque hook::MidContext is recovered by a REFERENCE cast inside the adapter, which is the same
 *          pass-through the public accessors in src/hook_mid_context.cpp perform and is sound because MidContext is
 *          forever incomplete and is only ever the Context the backend passed.
 *
 *          Only the hook sibling TUs (src/hook.cpp and src/internal/mid_hook_adapter.cpp) include this header, so the
 *          backend stays confined to that island.
 */

#include "DetourModKit/hook.hpp"

#include "platform.hpp"

#include <safetyhook.hpp>

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <utility>

namespace DetourModKit::detail
{
    /**
     * @brief The number of DMK-managed mid hooks that may exist at one time.
     * @details Each slot costs one generated adapter function, so the pool is a compile-time set. Exhaustion is
     *          reported as ErrorCode::MidHookCapacityExhausted rather than degraded into an untyped failure.
     */
    inline constexpr std::size_t MID_ADAPTER_CAPACITY = 64;

    /**
     * @brief Process-lifetime dispatch state for one mid hook.
     * @details Never destroyed. A thread that has already loaded a slot pointer may still be inside its adapter when
     *          teardown releases the slot, so the storage must outlive every hook that ever used it; only the slot's
     *          CONTENTS are recycled, and `claimed` is released only once `adapter_entries` reaches zero.
     */
    struct MidAdapterSlot
    {
        /// Owns the slot for one hook's lifetime. Released only after a witnessed drain.
        std::atomic<bool> claimed{false};
        /// The rundown tombstone: false means no further user callback may begin through this slot.
        std::atomic<bool> live{false};
        /// Threads currently inside this slot's adapter body, including ones that back out at the tombstone.
        std::atomic<std::uint32_t> adapter_entries{0};
        /// User callbacks that passed the tombstone recheck and have not returned.
        std::atomic<std::uint32_t> callbacks_in_flight{0};
        /// Callbacks whose thread could not be recorded in the entry chain, so self-entry cannot be disproven.
        std::atomic<std::uint32_t> untracked_entries{0};
        /// The user callback. Only ever read by a thread that has entered and observed `live`.
        std::atomic<hook::MidHookFn> detour{nullptr};
        /// Counts user exceptions contained at this boundary, for diagnostics.
        std::atomic<std::uint64_t> contained_exceptions{0};
        /// The hooked address, carried here so a containment report can name the site without touching Impl storage.
        std::atomic<std::uintptr_t> target{0};
    };

    /// The pool. Namespace-scope storage with no destructor, by the same never-destroyed discipline the ledger uses.
    [[nodiscard]] MidAdapterSlot *mid_adapter_slots() noexcept;

    /**
     * @brief One frame of the current thread's mid-adapter entry chain.
     * @details Lives on the adapter's own stack, so maintaining the chain allocates nothing. It exists so teardown can
     *          answer "is THIS thread inside THIS slot" exactly, which is what keeps a hook destroyed from inside its
     *          own callback from waiting on itself forever.
     */
    struct MidEntryFrame
    {
        const MidAdapterSlot *slot{nullptr};
        MidEntryFrame *prev{nullptr};
    };

    /**
     * @brief The Win32 TLS index that holds this thread's MidEntryFrame chain head, or TLS_OUT_OF_INDEXES.
     * @details The adapter uses it on arbitrary host threads, so it is a Win32 TLS index instead of `thread_local`
     *          (`[B-86]`). Each claimed slot owns the index, so a live slot always has a valid index, and the last
     *          released slot returns it. A retained route keeps its slot claimed, so its index stays reserved (proofs:
     *          `Lifecycle.MidEntryTlsIndexReturnsWithTheLastSlot`, `Lifecycle.MidEntryTlsIndexStaysWithARetainedSlot`).
     *          A frame store under it can still fail for an index past the TEB's inline slots. The adapter therefore
     *          counts an entry that it cannot record, and never assumes that entry absent.
     */
    [[nodiscard]] DWORD mid_entry_tls_index() noexcept;

    /// True when the calling thread is currently inside @p slot's adapter body.
    [[nodiscard]] bool thread_is_inside_mid_adapter(const MidAdapterSlot &slot) noexcept;

    /// Reports a contained user exception. Defined in src/internal/mid_hook_adapter.cpp, where the logger is visible.
    void note_contained_mid_exception(MidAdapterSlot &slot) noexcept;

#if defined(DMK_ENABLE_TEST_SEAMS)
    /**
     * @brief Stable executable interval exposed by the backend route park.
     * @note Test hosts that cannot include this header redeclare this enum, because including it would pull the
     *       backend into targets that deliberately carry no safetyhook include path. These values are therefore part
     *       of that cross-target contract: reordering an enumerator fails here rather than silently changing which
     *       interval a redeclaring host selects.
     */
    enum class MidRouteParkStage : std::uint8_t
    {
        None,
        BeforeAdapter,
        AfterAdapter
    };
    static_assert(static_cast<std::uint8_t>(MidRouteParkStage::None) == 0);
    static_assert(static_cast<std::uint8_t>(MidRouteParkStage::BeforeAdapter) == 1);
    static_assert(static_cast<std::uint8_t>(MidRouteParkStage::AfterAdapter) == 2);

    /// Arms one backend-route park, or releases an existing park with None.
    void set_mid_route_park_for_test(MidRouteParkStage stage) noexcept;

    /// Reports whether the armed backend-route park was reached.
    [[nodiscard]] bool mid_route_park_reached_for_test() noexcept;

    /**
     * @brief Fired inside the adapter after the fast-path live check and before the callback commit.
     * @details The window between those two points is the only one the tombstone recheck below exists to close, and it
     *          is a pure thread race: an entrant that has already passed the fast-path check must still not run a
     *          callback if a rundown completes before it commits. No stress schedule reaches that instant reliably, so
     *          a test parks a thread here and runs the teardown to completion underneath it.
     */
    extern void (*g_mid_adapter_precommit_probe)() noexcept;

    /**
     * @brief Native id of the thread whose entry-chain store must report failure, or 0 for none.
     * @details A store into a reserved index past the TEB's inline slots is backed by a lazily heap-allocated
     *          expansion array, so it can fail on a thread that has never used a high index while the reservation
     *          itself stays valid. The untracked accounting that failure selects is what keeps a teardown from waiting
     *          on the very thread running it, and no host can provoke the heap state on demand. Keyed by thread id
     *          rather than held in thread_local storage because MinGW lowers thread_local to emutls, which would
     *          allocate on this exact callback path.
     */
    extern std::atomic<std::uint32_t> g_mid_entry_store_failure_thread;

    /// Counts stores the exact failure seam refused, so a proof cannot pass through the ordinary tracked path.
    extern std::atomic<std::uint64_t> g_mid_entry_store_failure_hits;

    /// Returns the pool index from the most recent successful claim, or MID_ADAPTER_CAPACITY before any claim.
    [[nodiscard]] std::size_t last_claimed_mid_slot_for_test() noexcept;

    /// Reports whether pool slot @p index is currently claimed. Out-of-range indices report false.
    [[nodiscard]] bool mid_slot_claimed_for_test(std::size_t index) noexcept;

    /**
     * @brief Adjusts slot @p index's adapter-body entry count by @p delta.
     * @details Stands in for an indefinitely parked adapter entrant. The drains read only this counter, so an
     *          injected entry is indistinguishable from a preempted thread inside the body. The caller must balance
     *          the adjustment.
     */
    void adjust_mid_adapter_entries_for_test(std::size_t index, std::int32_t delta) noexcept;
#endif

    /// The one store whose failure decides tracked versus untracked accounting for this entry.
    [[nodiscard]] inline bool store_mid_entry(DWORD tls, MidEntryFrame *frame) noexcept
    {
#if defined(DMK_ENABLE_TEST_SEAMS)
        if (g_mid_entry_store_failure_thread.load(std::memory_order_relaxed) == ::GetCurrentThreadId())
        {
            g_mid_entry_store_failure_hits.fetch_add(1, std::memory_order_relaxed);
            return false;
        }
#endif
        return ::TlsSetValue(tls, frame) != FALSE;
    }

    /// The outcome kind of @ref claim_mid_adapter_slot.
    enum class MidSlotClaimStatus : std::uint8_t
    {
        Claimed,
        CapacityExhausted,
        EntryIndexUnavailable
    };

    /// The outcome of @ref claim_mid_adapter_slot.
    struct MidSlotClaim
    {
        /// The claimed pool index, or @ref MID_ADAPTER_CAPACITY when the claim failed.
        std::size_t index{MID_ADAPTER_CAPACITY};
        MidSlotClaimStatus status{MidSlotClaimStatus::CapacityExhausted};
        /// GetLastError() from the failed entry-index reservation.
        DWORD system_error{ERROR_SUCCESS};
    };

    /// Takes ownership of a free slot and of the entry TLS index that its adapter records frames under.
    [[nodiscard]] MidSlotClaim claim_mid_adapter_slot() noexcept;

    /// Returns a drained slot and its entry-index ownership to the pool. Never call on a slot that is not run down.
    void release_mid_adapter_slot(std::size_t index) noexcept;

    /// The outcome of @ref run_down_mid_slot.
    enum class MidRundown : std::uint8_t
    {
        /// No user callback is executing; teardown may proceed.
        Drained,
        /**
         * @brief Waiting cannot be proven to terminate, so the caller must pin instead.
         * @details Either the calling thread is itself inside the adapter (much the likelier cause), or an entrant
         *          lacks a record and cannot be ruled out as the caller. The two cases are not distinguished
         *          because the required action is the same.
         */
        Unwaitable,
        /// The bounded wait ended with a callback still in flight. The caller must pin.
        Expired
    };

    /**
     * @brief Waits for every user callback committed before @p slot was tombstoned.
     * @details New adapter entries can still arrive through a pinned backend. The live recheck prevents a callback
     *          commit. The function returns Unwaitable to avoid a self-wait. It returns Expired when the bounded wait
     *          ends with a callback still counted.
     */
    [[nodiscard]] MidRundown run_down_mid_slot(MidAdapterSlot &slot) noexcept;

    /**
     * @brief Waits for every adapter body to leave after entry through the backend has stopped.
     * @param slot The tombstoned slot to drain.
     * @return The result is true when no entrant remains. It is false when the bounded wait expires with an occupied
     *         body. A false result never permits reclamation of the slot or stub.
     * @note Backend route rundown separately spans the generated stub from its stable gateway through its stable exit
     *       thunk. This counter remains the slot-reuse authority for the DMK adapter body itself.
     */
    [[nodiscard]] bool drain_mid_adapter_entries(MidAdapterSlot &slot) noexcept;

    /**
     * @brief The body every generated adapter shares.
     * @details Enter, recheck, invoke, leave. The callback-counter/recheck pair and the tombstone/drain pair are a
     *          Dekker seam: both sides are seq_cst so at least one of them observes the other, which is what makes "no
     *          callback begins after rundown returns" hold without a lock on the callback path.
     *
     *          The reference count is held across the WHOLE body, including the back-out, so a drained slot has no
     *          thread anywhere in this function and its contents may be recycled.
     */
    inline void dispatch_mid_adapter(MidAdapterSlot &slot, safetyhook::Context &ctx) noexcept
    {
        slot.adapter_entries.fetch_add(1, std::memory_order_seq_cst);
        if (slot.live.load(std::memory_order_seq_cst))
        {
#if defined(DMK_ENABLE_TEST_SEAMS)
            if (auto *probe = g_mid_adapter_precommit_probe)
            {
                probe();
            }
#endif
            slot.callbacks_in_flight.fetch_add(1, std::memory_order_seq_cst);
            if (slot.live.load(std::memory_order_seq_cst))
            {
                if (const hook::MidHookFn detour = slot.detour.load(std::memory_order_acquire))
                {
                    const DWORD tls = mid_entry_tls_index();
                    MidEntryFrame frame{&slot, nullptr};
                    bool tracked = false;
                    if (tls != TLS_OUT_OF_INDEXES)
                    {
                        frame.prev = static_cast<MidEntryFrame *>(::TlsGetValue(tls));
                        tracked = store_mid_entry(tls, &frame);
                    }
                    if (!tracked)
                    {
                        // The chain walk cannot see this thread, so a teardown must not conclude it is absent: a wrong
                        // "no" makes the rundown wait on the very thread running it, while a wrong "yes" only pins.
                        // Counted rather than made sticky so the pool recovers once the entry leaves.
                        slot.untracked_entries.fetch_add(1, std::memory_order_seq_cst);
                    }
                    try
                    {
                        // The one boundary that must never let a throw reach the backend's generated mid stub. The
                        // routed gateway, wrapper, and exit thunk are all described by registered unwind data, but the
                        // stub between them adjusts RSP dynamically and is not, so an escaping exception unwinds
                        // through a frame the platform cannot describe: a host crash rather than an error.
                        detour(reinterpret_cast<hook::MidContext &>(ctx));
                    }
                    catch (...)
                    {
                        note_contained_mid_exception(slot);
                    }
                    if (tracked)
                    {
                        (void)::TlsSetValue(tls, frame.prev);
                    }
                    else
                    {
                        slot.untracked_entries.fetch_sub(1, std::memory_order_seq_cst);
                    }
                }
            }
            slot.callbacks_in_flight.fetch_sub(1, std::memory_order_seq_cst);
        }
        slot.adapter_entries.fetch_sub(1, std::memory_order_seq_cst);
    }

    /**
     * @brief The generated per-hook adapter.
     * @details This IS the backend's destination: a genuine `void(safetyhook::Context&)`, so the backend's call through
     *          it is an ordinary call of a function of its own type.
     */
    template <std::size_t Index> void mid_adapter(safetyhook::Context &ctx) noexcept
    {
        dispatch_mid_adapter(mid_adapter_slots()[Index], ctx);
    }

    template <std::size_t... Indices>
    [[nodiscard]] constexpr std::array<safetyhook::MidHookFn, sizeof...(Indices)>
    make_mid_adapter_table(std::index_sequence<Indices...>) noexcept
    {
        // Dropping noexcept from each adapter pointer's type is a standard implicit conversion.
        return {&mid_adapter<Indices>...};
    }

    /// Adapter addresses in the exact type the backend consumes.
    extern constinit const std::array<safetyhook::MidHookFn, MID_ADAPTER_CAPACITY> MID_ADAPTER_TABLE;
} // namespace DetourModKit::detail

#endif // DETOURMODKIT_INTERNAL_MID_HOOK_ADAPTER_HPP
