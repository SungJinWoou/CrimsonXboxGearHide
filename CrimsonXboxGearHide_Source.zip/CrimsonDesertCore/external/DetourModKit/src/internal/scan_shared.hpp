#ifndef DETOURMODKIT_INTERNAL_SCAN_SHARED_HPP
#define DETOURMODKIT_INTERNAL_SCAN_SHARED_HPP

/**
 * @file internal/scan_shared.hpp
 * @brief Small shared helpers for scan-module TUs: anchor selection, resolution arithmetic, and strict UTF-8 decoding.
 * @details Never installed. The scan_matching, scan_resolution, and scan_prologue_recovery TUs all turn a value Pattern
 *          into an EnginePattern with a haystack-chosen anchor and screen byte-tier resolutions through the same
 *          plausible-userspace floor, so those helpers live here in one place rather than being duplicated. The anchor
 *          override is correctness-neutral: it only changes which single byte the memchr prefilter sweeps for; the full
 *          masked compare still decides every accepted position.
 */

#include "internal/memory_guarded.hpp"
#include "internal/scan_engine.hpp"
#include "internal/scan_exclusions.hpp"

#include "DetourModKit/region.hpp"
#include "DetourModKit/scan.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string_view>

namespace DetourModKit
{
    namespace detail
    {
        // Bounded haystack sampling budget. A byte-frequency ranking needs only a representative sample, not the whole
        // image: 64 page reads (256 KiB) strided across the scope are ample to rank 256 byte values, and the fixed cap
        // keeps anchor selection a constant cost regardless of scope size so it never approaches the cost of the scan
        // it accelerates. Scopes larger than the budget ceiling (a whole-process window, terabytes of mostly-unmapped
        // address space) are not sampled at all: the sample would be unrepresentative and would pay for dozens of
        // guaranteed page faults, so those fall back to the compile-time anchor.
        inline constexpr std::size_t SAMPLE_PAGE = 0x1000;
        inline constexpr std::size_t SAMPLE_MAX_PAGES = 64;
        inline constexpr std::size_t SAMPLE_MIN_BYTES = SAMPLE_PAGE;
        inline constexpr std::size_t SAMPLE_MAX_SCOPE = std::size_t{512} * 1024 * 1024;

        struct HaystackHistogram
        {
            std::array<std::uint32_t, 256> counts{};
            std::size_t sampled = 0;
        };

        // Sample a bounded, strided set of pages from the scope and tally a 256-bin byte-frequency histogram. Reads go
        // through guarded_read_bytes one page at a time, so an unmapped / guard page inside the scope is skipped rather
        // than faulting the host; the stride spreads the sample across .text and .rdata / .data so the frequencies
        // reflect the whole image, not just its first pages. Entirely stack-based (the histogram and the page buffer
        // are locals), so it never allocates and is safe to call from the noexcept scan paths.
        [[nodiscard]] inline HaystackHistogram sample_haystack(Region scope) noexcept
        {
            HaystackHistogram histogram;
            const std::uintptr_t base = scope.base.raw();
            if (base == 0 || scope.size == 0 || scope.size > SAMPLE_MAX_SCOPE)
            {
                return histogram;
            }
            const std::size_t total_pages = (scope.size + SAMPLE_PAGE - 1) / SAMPLE_PAGE;
            const std::size_t stride = (total_pages > SAMPLE_MAX_PAGES) ? (total_pages / SAMPLE_MAX_PAGES) : 1;
            std::array<std::uint8_t, SAMPLE_PAGE> buffer{};
            std::size_t pages_read = 0;
            for (std::size_t page = 0; page < total_pages && pages_read < SAMPLE_MAX_PAGES; page += stride)
            {
                const std::uintptr_t page_address = base + static_cast<std::uintptr_t>(page) * SAMPLE_PAGE;
                const std::size_t remaining = scope.size - page * SAMPLE_PAGE;
                const std::size_t want = (remaining < SAMPLE_PAGE) ? remaining : SAMPLE_PAGE;
                if (!guarded_read_bytes(page_address, buffer.data(), want))
                {
                    // A page that faults mid-read is skipped; the sample stays a valid (smaller) lower bound.
                    continue;
                }
                for (std::size_t i = 0; i < want; ++i)
                {
                    ++histogram.counts[buffer[i]];
                }
                histogram.sampled += want;
                ++pages_read;
            }
            return histogram;
        }

        // When a sufficient haystack sample exists, pick the pattern's fully-known byte whose value is rarest in this
        // image (the most selective prefilter for this haystack), overriding the compile-time rarest-byte anchor the
        // Pattern carries; otherwise fall back to that compile-time anchor. Returns the engine "no fully-known byte"
        // sentinel (size()) when segment 0 has no full byte. Correctness-neutral: the anchor only selects which single
        // byte the memchr prefilter sweeps for; the full masked compare still decides every accepted position.
        //
        // The override is confined to segment 0 (the fixed run before the first bounded jump), exactly like the
        // compile-time anchor: the segmented matcher locates that first run and then walks the variable gaps, so a byte
        // in a later segment sits at a gap-dependent address the memchr prefilter cannot sweep for. Choosing an anchor
        // outside segment 0 would compute a wrong candidate start and silently miss real matches.
        [[nodiscard]] inline std::size_t
        choose_scan_anchor(const scan::Pattern &pattern, const HaystackHistogram &histogram) noexcept
        {
            const std::size_t size = pattern.size();
            if (histogram.sampled < SAMPLE_MIN_BYTES)
            {
                return pattern.has_anchor() ? pattern.anchor_index() : size;
            }
            const std::span<const std::byte> bytes = pattern.bytes();
            const std::span<const std::byte> mask = pattern.mask();
            const detail::PatternBuffer &data = detail::pattern_buffer(pattern);
            const std::size_t segment0_end = (data.jump_count == 0) ? size : data.jumps[0].position;
            std::size_t best_index = size;
            std::uint32_t best_count = 0;
            for (std::size_t i = 0; i < segment0_end; ++i)
            {
                if (mask[i] != std::byte{0xFF})
                {
                    // Only a fully-known byte gives the prefilter one exact value to memchr for; nibble / wildcard
                    // positions cannot anchor.
                    continue;
                }
                const std::uint32_t count = histogram.counts[std::to_integer<std::uint8_t>(bytes[i])];
                if (best_index == size || count < best_count)
                {
                    best_index = i;
                    best_count = count;
                }
            }
            return best_index;
        }

        // Builds the engine pattern for a value Pattern with the haystack-chosen anchor. Allocates two small vectors,
        // so every caller on a noexcept path guards this against std::bad_alloc.
        [[nodiscard]] inline EnginePattern
        to_engine_pattern(const scan::Pattern &pattern, const HaystackHistogram &histogram)
        {
            const std::size_t anchor = choose_scan_anchor(pattern, histogram);
            return engine_pattern_from(pattern, anchor);
        }

        /**
         * @brief Decodes one UTF-8 code point and advances @p pos.
         * @details Runtime and persistence share this strict decoder. A replacement character changes the requested
         *          literal. The caller must pass pos less than text.size().
         * @param text Input bytes.
         * @param pos Input and output byte position.
         * @param out Decoded scalar value on success.
         * @return True on success. False for an invalid leader, tail, scalar value, overlong form, or truncated
         * sequence.
         */
        [[nodiscard]] inline bool decode_utf8(std::string_view text, std::size_t &pos, char32_t &out) noexcept
        {
            const auto byte_at = [&text](std::size_t index) noexcept { return static_cast<std::uint8_t>(text[index]); };

            const std::uint8_t lead = byte_at(pos);
            std::size_t extra = 0;
            char32_t value = 0;
            if (lead < 0x80)
            {
                out = lead;
                ++pos;
                return true;
            }
            if (lead >= 0xC2 && lead <= 0xDF)
            {
                extra = 1;
                value = lead & 0x1FU;
            }
            else if (lead >= 0xE0 && lead <= 0xEF)
            {
                extra = 2;
                value = lead & 0x0FU;
            }
            else if (lead >= 0xF0 && lead <= 0xF4)
            {
                extra = 3;
                value = lead & 0x07U;
            }
            else
            {
                return false;
            }

            // The caller guarantees pos < size. The subtraction keeps this bounds check free from pointer overflow.
            if (extra >= text.size() - pos)
            {
                return false;
            }
            for (std::size_t i = 1; i <= extra; ++i)
            {
                const std::uint8_t continuation = byte_at(pos + i);
                if ((continuation & 0xC0U) != 0x80U)
                {
                    return false;
                }
                value = (value << 6) | (continuation & 0x3FU);
            }

            // The leader ranges above exclude two-byte overlongs. These checks reject the remaining invalid values.
            if ((extra == 2 && value < 0x800) || (extra == 3 && value < 0x10000) ||
                (value >= 0xD800 && value <= 0xDFFF) || value > 0x10FFFF)
            {
                return false;
            }
            pos += extra + 1;
            out = value;
            return true;
        }

        /// Reports whether every byte of @p text belongs to a well-formed UTF-8 sequence (decode_utf8's rule).
        [[nodiscard]] inline bool utf8_is_well_formed(std::string_view text) noexcept
        {
            std::size_t pos = 0;
            while (pos < text.size())
            {
                char32_t code_point = 0;
                if (!decode_utf8(text, pos, code_point))
                {
                    return false;
                }
            }
            return true;
        }

        // Exact-membership validity checks for the string-xref facet enums, shared by the direct find_string_xref
        // boundary and resolve()'s whole-ladder prepass so both fail closed on the same vocabulary.
        [[nodiscard]] inline constexpr bool valid_string_encoding(scan::StringEncoding encoding) noexcept
        {
            return encoding == scan::StringEncoding::Utf8 || encoding == scan::StringEncoding::Utf16le;
        }

        [[nodiscard]] inline constexpr bool valid_xref_return(scan::XrefReturn mode) noexcept
        {
            switch (mode)
            {
            case scan::XrefReturn::ReferencingInstruction:
            case scan::XrefReturn::EnclosingFunction:
            case scan::XrefReturn::StringPointerSlot:
                return true;
            }
            return false;
        }

        // Zero keeps the decoder's natural width; a positive width may narrow at most the 64-bit result type.
        [[nodiscard]] inline constexpr bool valid_code_constant_byte_width(std::uint8_t byte_width) noexcept
        {
            return byte_width <= sizeof(std::int64_t);
        }

        /**
         * @struct ResolvedScanHit
         * @brief A public scan hit plus the physical matched span that supplied its byte evidence.
         * @details @ref winning_index and @ref match_span identify the selected rung for fresh epoch validation.
         *          @ref match_span is the raw matched extent. @ref physical_source can also cover a RIP instruction
         *          suffix that extends past that match (T-CODE-EPOCH).
         */
        struct ResolvedScanHit
        {
            scan::Hit hit;
            Region physical_source;
            /// Ladder index of the selected candidate. SIZE_MAX denotes a prologue-recovery hit.
            std::size_t winning_index = static_cast<std::size_t>(-1);
            /// The selected byte rung's raw matched span. Text tiers and recovery leave it empty.
            Region match_span;
        };

        /// Resolves a request and retains private physical-source provenance for anchor quorum checks.
        [[nodiscard]] Result<ResolvedScanHit> resolve_scan_with_provenance(const scan::ScanRequest &request);

        /// Returns the compiled byte Pattern of a Direct or RipRelative candidate, or nullptr for a text tier.
        [[nodiscard]] inline const scan::Pattern *byte_pattern_of(const scan::Candidate &candidate) noexcept
        {
            if (const scan::DirectPattern *direct = candidate.as_direct())
            {
                return &direct->pattern;
            }
            if (const scan::RipRelativePattern *rip = candidate.as_rip_relative())
            {
                return &rip->pattern;
            }
            return nullptr;
        }

        /**
         * @struct ResolvedCodeConstant
         * @brief A decoded constant plus the instruction and matched byte span that supplied it.
         * @details @ref instruction_span covers the whole decoded instruction, not just its first byte: every byte of
         *          it is evidence this constant depends on, so a co-voting selector that witnesses any of those bytes
         *          shares the failure domain and must not corroborate.
         */
        struct ResolvedCodeConstant
        {
            std::int64_t value = 0;
            Region instruction_span;
            Region physical_source;
        };

        /// Reads a code constant while retaining private physical-source provenance for anchor quorum checks.
        [[nodiscard]] Result<ResolvedCodeConstant>
        read_code_constant_with_provenance(const scan::CodeConstant &code_constant, Region scope);

        /**
         * @brief Resolves a string xref while retaining the referencing instruction's span for quorum checks.
         * @param physical_source Receives the half-open span of the bytes the result rides on; empty on failure.
         * @details The span covers the referencing instruction whole, and for @ref scan::XrefReturn::StringPointerSlot
         *          it reaches through the store the slot address was decoded from, since that store's own disp32 is
         *          what the mode returns. A co-voting selector that witnesses any of those bytes shares the failure
         *          domain and must not corroborate.
         */
        [[nodiscard]] Result<Address>
        find_string_xref_with_provenance(const scan::StringRefQuery &query, Region scope, Region &physical_source);

        /**
         * @brief Resolves a string xref while honouring an exclusion set the caller already assembled.
         * @param query String literal and reference-selection facets.
         * @param scope Address range to search.
         * @param exclusions Combined DMK-owned and caller-declared query storage; null builds the set from @p query
         *        alone.
         * @param declared_exclusions Caller-declared spans, used only to establish readable-scan authority.
         * @param physical_source When non-null, receives the half-open span of the bytes the result rides on; empty on
         *        failure. See @ref find_string_xref_with_provenance for what that span covers.
         * @return The resolved address, or a typed scan error.
         * @details Exists so the ladder resolver can carry its own query storage into phase 1 instead of re-deriving
         *          it. Internal on purpose, so no consumer depends on DMK's exclusion representation.
         */
        [[nodiscard]] Result<Address> find_string_xref_with_exclusions(
            const scan::StringRefQuery &query,
            Region scope,
            const ScanExclusions *exclusions,
            std::span<const Region> declared_exclusions,
            Region *physical_source = nullptr
        );

        // Direct-tier resolution: the resolved address is the match plus the signed walk-back. Screened through the
        // plausible-userspace floor so a pathological walk-back that underflows to a near-null / kernel-range address
        // is a miss, never a hit.
        [[nodiscard]] inline std::optional<std::uintptr_t>
        resolve_direct(std::uintptr_t match, const scan::DirectPattern &direct) noexcept
        {
            const std::uintptr_t resolved = match + static_cast<std::uintptr_t>(direct.walk_back);
            if (!is_plausible_ptr(resolved))
            {
                return std::nullopt;
            }
            return resolved;
        }

        // Adds a sign-extended disp32 to the next-instruction address with defined modular arithmetic.
        [[nodiscard]] inline constexpr std::uintptr_t add_rip_displacement(
            std::uintptr_t instruction,
            std::size_t instruction_length,
            std::int32_t displacement
        ) noexcept
        {
            const std::uintptr_t displacement_offset =
                static_cast<std::uintptr_t>(static_cast<std::int64_t>(displacement));
            return instruction + static_cast<std::uintptr_t>(instruction_length) + displacement_offset;
        }

        /**
         * @brief Decodes one guarded instruction snapshot and returns its declared RIP-relative disp32.
         * @param instruction Immutable bytes captured at the matched instruction during the page sweep.
         * @param displacement_offset Declared byte offset of the disp32 field.
         * @param instruction_length Declared total instruction length.
         * @return The displacement when the decoded instruction has the declared length and disp32 location on a
         *         RIP-relative memory operand; otherwise std::nullopt.
         * @details Defined in scan_rip_relative.cpp so Zydis stays confined to that TU. The displacement comes from the
         *          same guarded byte snapshot that is decoded, so a second live-memory read cannot diverge from it.
         */
        [[nodiscard]] std::optional<std::int32_t> decode_rip_displacement(
            std::span<const std::byte> instruction,
            std::size_t displacement_offset,
            std::size_t instruction_length
        ) noexcept;

        // RipRelative-tier resolution: decode-verify the immutable sweep snapshot, then compute next-IP plus its
        // sign-extended disp32. A drifted layout, an absent snapshot, or an implausible target is a miss.
        [[nodiscard]] inline std::optional<std::uintptr_t> resolve_rip_relative_candidate(
            std::uintptr_t match,
            const scan::RipRelativePattern &rip,
            std::span<const std::byte> instruction
        ) noexcept
        {
            // A wildcarded pattern can byte-match an instruction whose opcode, addressing form, or length drifted from
            // the declared layout; applying the declared displacement_at to that instruction would read a
            // plausible-but-wrong disp32 and resolve a wrong target. Decode-verify gates the resolution so a drift is a
            // miss, not a silently wrong hit.
            const std::optional<std::int32_t> displacement =
                decode_rip_displacement(instruction, rip.displacement_at, rip.instruction_length);
            if (!displacement)
            {
                return std::nullopt;
            }
            const std::uintptr_t resolved = add_rip_displacement(match, rip.instruction_length, *displacement);
            if (!is_plausible_ptr(resolved))
            {
                return std::nullopt;
            }
            return resolved;
        }
    } // namespace detail
} // namespace DetourModKit

#endif // DETOURMODKIT_INTERNAL_SCAN_SHARED_HPP
