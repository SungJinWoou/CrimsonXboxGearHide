#include "DetourModKit/logger.hpp"
#include "DetourModKit/diagnostics.hpp"
#include "DetourModKit/filesystem.hpp"

#include "internal/async_logger.hpp"
#include "internal/utf8_conversion.hpp"
#include "internal/win_file_stream.hpp"
#include "platform.hpp"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <ctime>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <new>
#include <stdexcept>
#include <string_view>
#include <type_traits>

namespace DetourModKit::detail
{
#if defined(DMK_ENABLE_TEST_SEAMS)
    // shutdown_internal() fires this test-only probe inside its dropped-mutex window, after the first writer retirement
    // and before the final re-check. A fixture drives configure() and enable_async_mode() calls into that window. Tests
    // install it on one thread. Builds without DMK_ENABLE_TEST_SEAMS omit it.
    void (*g_logger_shutdown_gap_probe)() noexcept = nullptr;

    // Test-only probe fired inside enable_async_mode()'s arm-then-publish window. When non-null it may throw, which
    // is the only way to reach the rollback that breaks a retention root whose writer was never published. Set /
    // cleared on a single thread inside a test fixture; the definition and fire site compile out of shipping builds.
    void (*g_logger_publication_probe)() = nullptr;

    // Test-only probe at the old success-diagnostic site after enable_async_mode() publishes the writer.
    // It can throw when non-null. Tests install it on one thread. Shipping builds omit it.
    void (*g_logger_post_publication_probe)() = nullptr;

    // Test-only probe fired after Logger::log() snapshots an async writer and before it calls enqueue(). A fixture
    // retires that writer inside the probe to prove a late rejection reaches the facade's cumulative drop counter.
    void (*g_logger_async_snapshot_probe)() noexcept = nullptr;

    // Test-only probe at entry to each record delivery route. A fixture checks whether a config lock spans that route.
    void (*g_logger_record_probe)(LogLevel, std::string_view) noexcept = nullptr;

    // Test-only rendezvous after set_log_level() reads the current level and before it attempts the state transition.
    void (*g_logger_level_transition_probe)() noexcept = nullptr;
#endif
} // namespace DetourModKit::detail

namespace DetourModKit
{
    namespace
    {
        using StaticConfigAtom = std::atomic<std::shared_ptr<const Logger::StaticConfig>>;

        /**
         * @brief Returns the never-destroyed process configuration publication slot.
         * @details The slot matches the process-lifetime Logger storage (`[B-47]`).
         */
        StaticConfigAtom &static_config_atom()
        {
            alignas(StaticConfigAtom) static unsigned char storage[sizeof(StaticConfigAtom)];
            static StaticConfigAtom *const atom =
                ::new (static_cast<void *>(storage)) StaticConfigAtom{std::make_shared<const Logger::StaticConfig>(
                    std::string{DEFAULT_LOG_PREFIX},
                    std::string{DEFAULT_LOG_FILE_NAME},
                    std::string{DEFAULT_TIMESTAMP_FORMAT}
                )};
            return *atom;
        }

        /**
         * @brief Serializes process-default configuration publication and application.
         * @details Late static teardown can call configure(). The mutex uses never-destroyed storage (`[B-47]`).
         */
        [[nodiscard]] std::mutex &static_config_mutex() noexcept
        {
            alignas(std::mutex) static unsigned char storage[sizeof(std::mutex)];
            static std::mutex *const mutex = ::new (static_cast<void *>(storage)) std::mutex();
            return *mutex;
        }

        /**
         * @brief Writes one INFO banner line from a pre-rendered timestamp.
         * @details Stream insertion records an error through failbit. This helper does not throw after a state
         *          commit.
         */
        void
        write_banner_line(detail::WinFileStream &sink, std::string_view timestamp, std::string_view message) noexcept
        {
            sink << "[" << timestamp << "] " << "[" << std::setw(7) << std::left << "INFO" << "] :: " << message
                 << '\n';
        }

        /**
         * @brief Abandons a detached writer's handle to the retention root armed before its publication.
         * @details Retention costs nothing here: the writer already owns itself, so keeping it alive is simply not
         *          breaking that root. Nothing is allocated, nothing can throw, and there is no finite supply of
         *          fallback storage to exhaust, which is what makes this safe on the loader-lock path that reaches it.
         *          No module reference is taken either: the detached writer thread holds its own counted reference on
         *          this module (taken before thread creation, while the module was fully mapped), and that is what
         *          keeps its code mapped.
         */
        void abandon_detached_async_logger(std::shared_ptr<AsyncLogger> &logger) noexcept
        {
            if (!logger)
            {
                return;
            }
            logger.reset();
            DetourModKit::diagnostics::record_intentional_leak(DetourModKit::diagnostics::LeakSubsystem::Logger);
        }

#if defined(DMK_ENABLE_TEST_SEAMS)
        /**
         * @brief Fires the post-publication probe of enable_async_mode() and discards any exception it throws.
         * @details This seam proves that a throw after publication cannot escape or disturb the published writer.
         */
        void fire_post_publication_probe() noexcept
        {
            if (auto *post_publication_probe = detail::g_logger_post_publication_probe)
            {
                try
                {
                    post_publication_probe();
                }
                catch (...)
                {
                }
            }
        }
#endif
    } // anonymous namespace

    std::shared_ptr<const Logger::StaticConfig> Logger::get_static_config()
    {
        return static_config_atom().load(std::memory_order_acquire);
    }

    void Logger::set_static_config(std::shared_ptr<const StaticConfig> config)
    {
        static_config_atom().store(std::move(config), std::memory_order_release);
    }

    LogLevel string_to_log_level(std::string_view level_str)
    {
        std::string upper_level_str(level_str);
        for (char &c : upper_level_str)
        {
            // Fold ASCII a-z by hand, as manifest.cpp does for its keywords: std::toupper is locale sensitive, which
            // [B-37] forbids on a resolution path. LoggerTest.StringToLogLevelUsesAsciiFold pins the rule.
            if (c >= 'a' && c <= 'z')
            {
                c = static_cast<char>(c - 'a' + 'A');
            }
        }

        if (upper_level_str == "TRACE")
            return LogLevel::Trace;
        if (upper_level_str == "DEBUG")
            return LogLevel::Debug;
        if (upper_level_str == "INFO")
            return LogLevel::Info;
        if (upper_level_str == "WARNING")
            return LogLevel::Warning;
        if (upper_level_str == "ERROR")
            return LogLevel::Error;

        std::cerr << "[" << DEFAULT_LOG_PREFIX << " Logger WARNING] Unrecognized log level string '" << level_str
                  << "'. Defaulting to INFO." << '\n';
        return LogLevel::Info;
    }

    void Logger::configure(
        std::string_view prefix,
        std::string_view file_name,
        std::string_view timestamp_fmt,
        LogOpenMode open_mode,
        LogSourceStampMode source_stamp_mode
    )
    {
        std::lock_guard<std::mutex> config_lock(static_config_mutex());

        // The staged snapshot precedes first use because the process-default constructor reads it. The prior snapshot
        // restores the last accepted defaults after a failed apply.
        auto staged_config = std::make_shared<const StaticConfig>(
            std::string(prefix),
            std::string(file_name),
            std::string(timestamp_fmt),
            open_mode,
            source_stamp_mode
        );
        auto previous_config = get_static_config();
        set_static_config(std::move(staged_config));

        // The qualified free accessor avoids the member log() overload set, which hides the process-default accessor.
        try
        {
            Logger &instance = DetourModKit::log();

            // An inert first-use logger owns no sink or mutex and cannot apply the staged defaults. Restore the prior
            // snapshot before it returns to its process-lifetime inert state.
            if (instance.is_inert())
            {
                set_static_config(std::move(previous_config));
                return;
            }

            // The sink locks serialize configuration with shutdown. Neither operation can split the other's sink
            // transition.
            std::scoped_lock lock(instance.m_async_mutex, *instance.m_log_mutex_ptr);
            if (instance.m_async_writer_abandoned.load(std::memory_order_acquire))
            {
                // A detached writer retains final sink ownership. Restore the snapshot to avoid a second sink owner.
                set_static_config(std::move(previous_config));
                return;
            }
            // configure() is the authoritative reset path: it re-enables the process default even after a shutdown,
            // so a test fixture or a re-attach can reuse the sink. The latch is deliberately outside the sink
            // transaction. A live facade over an unopenable sink still routes an Error record to stderr.
            instance.m_shutdown_called.store(false, std::memory_order_release);
            if (!instance.reconfigure_locked(prefix, file_name, timestamp_fmt))
            {
                set_static_config(std::move(previous_config));
            }
            else
            {
                instance.set_source_stamp_mode(source_stamp_mode);
            }
        }
        catch (...)
        {
            // A post-publication allocation can throw. Rollback pairs the immutable defaults with the last accepted
            // configuration and preserves configure()'s exception contract.
            set_static_config(std::move(previous_config));
            throw;
        }
    }

    void Logger::reconfigure(std::string_view prefix, std::string_view file_name, std::string_view timestamp_fmt)
    {
        if (is_inert() || m_async_writer_abandoned.load(std::memory_order_acquire))
        {
            return;
        }

        if (m_shutdown_called.load(std::memory_order_acquire))
        {
            return;
        }

        // Acquire both m_async_mutex and *m_log_mutex_ptr to prevent concurrent log() calls from reading
        // partially-updated string members during reconfiguration.
        std::scoped_lock lock(m_async_mutex, *m_log_mutex_ptr);
        if (m_shutdown_called.load(std::memory_order_acquire) ||
            m_async_writer_abandoned.load(std::memory_order_acquire))
        {
            return;
        }
        // The public form reports nothing: a caller that needs the outcome reads the log file it named.
        (void)reconfigure_locked(prefix, file_name, timestamp_fmt);
    }

    bool Logger::reconfigure_locked(std::string_view prefix, std::string_view file_name, std::string_view timestamp_fmt)
    {
        // Precondition: the caller holds m_async_mutex and *m_log_mutex_ptr.

        // Skip only when all parameters match AND the stream is usable. After shutdown or a prior open failure the
        // stream may be closed, so fall through to reopen even if the strings are identical.
        const bool sink_usable = m_log_file_stream_ptr->is_open() && m_log_file_stream_ptr->good();
        if (sink_usable && m_log_prefix == prefix && m_log_file_name == file_name &&
            m_timestamp_format == timestamp_fmt)
        {
            return true;
        }

        // The prefix and timestamp format apply per line, not baked into the open file, so a change that keeps the
        // same file needs no reopen. A different target file, or an unusable stream, needs a replacement sink. Only
        // the process-start constructor truncates, so the replacement opens in append mode and the target file keeps
        // its existing records.
        const bool needs_new_sink = (m_log_file_name != file_name) || !sink_usable;

        // All transaction allocation precedes file creation. A failed candidate leaves the current configuration and
        // sink intact. A failed retirement can leave an empty candidate file, but it retains the current handle and
        // tail.
        // LoggerTest.Reconfigure_InvalidPath_KeepsOldFile and LoggerTest.Reconfigure_AllocationFailure_KeepsOldSink
        // pin both halves.
        std::string staged_prefix(prefix);
        std::string staged_file_name(file_name);
        std::string staged_timestamp_format(timestamp_fmt);
        std::string staged_async_format = staged_timestamp_format;
        const bool retires_prior_sink = needs_new_sink && m_log_file_stream_ptr->is_open();
        const std::string retire_timestamp = retires_prior_sink ? get_timestamp(m_timestamp_format) : std::string{};
        std::string retire_notice;
        if (retires_prior_sink)
        {
            retire_notice = "Logger reconfiguring. New file: ";
            retire_notice += file_name;
        }
        const std::string adopt_notice = needs_new_sink ? ("Logger reconfigured. Now logging to: " + staged_file_name)
                                                        : std::string("Logger reconfigured (same file retained).");
        const std::string adopt_timestamp = get_timestamp(staged_timestamp_format);

        std::shared_ptr<detail::WinFileStream> staged_sink;
        if (needs_new_sink)
        {
            staged_sink = open_sink(staged_file_name, /*truncate=*/false);
            if (!staged_sink)
            {
                return false;
            }
        }

        // The current sink closes before the state commit. A close failure retains the handle and buffered tail.
        // Cleared stream flags permit a later retry. The candidate stays uncommitted while recoverable state exists.
        if (staged_sink && retires_prior_sink)
        {
            if (sink_usable)
            {
                write_banner_line(*m_log_file_stream_ptr, retire_timestamp, retire_notice);
                m_log_file_stream_ptr->flush();
            }
            m_log_file_stream_ptr->close();
            if (m_log_file_stream_ptr->is_open())
            {
                m_log_file_stream_ptr->clear();
                return false;
            }
        }

        // Member moves, banner writes, and both async setters are no-throw. The configuration cannot become
        // half-applied.
        m_log_prefix = std::move(staged_prefix);
        m_log_file_name = std::move(staged_file_name);
        m_timestamp_format = std::move(staged_timestamp_format);

        if (staged_sink)
        {
            m_log_file_stream_ptr = std::move(staged_sink);
            write_banner_line(*m_log_file_stream_ptr, adopt_timestamp, adopt_notice);
        }
        else
        {
            // The same file stays open with its records intact. The in-line banner records the change without
            // truncation.
            write_banner_line(*m_log_file_stream_ptr, adopt_timestamp, adopt_notice);
            m_log_file_stream_ptr->flush();
        }

        // A live async writer receives the committed sink and timestamp format. enable_async_mode captures both at
        // construction. Without this update, the writer keeps the old format and writes to the retired stream. Each
        // setter assigns under the scoped lock, and the writer reads both only under *m_log_mutex_ptr.
        if (m_async_mode_enabled.load(std::memory_order_acquire))
        {
            if (auto async_logger = m_async_logger.load(std::memory_order_acquire))
            {
                async_logger->set_file_stream(m_log_file_stream_ptr);
                async_logger->set_timestamp_format(std::move(staged_async_format));
            }
        }
        return true;
    }

    Logger::Logger() : m_log_mutex_ptr(std::make_shared<std::mutex>())
    {
        const auto config = get_static_config();
        m_log_prefix = config->log_prefix;
        m_log_file_name = config->log_file_name;
        m_timestamp_format = config->timestamp_format;
        m_source_stamp_mode.store(config->source_stamp_mode, std::memory_order_relaxed);

        // A default construction starts a fresh log unless the published configuration selected Append.
        // Reconfiguration never truncates.
        adopt_first_sink(/*truncate=*/config->open_mode == LogOpenMode::Truncate);
    }

    Logger::Logger(InertTag) noexcept
    {
        // Inert first-use logger. No sink, shared sink mutex, or writer is allocated, so is_inert() (a null
        // m_log_mutex_ptr) is true and every enabled log request fails closed by dropping and counting. Constructing
        // the empty string and atomic members allocates nothing, so this stays no-throw under the OOM that forced the
        // fallback.
    }

    Logger::Logger(
        std::string_view prefix,
        std::string_view file_name,
        std::string_view timestamp_fmt,
        LogOpenMode open_mode,
        LogSourceStampMode source_stamp_mode
    )
        : m_log_prefix(prefix), m_log_file_name(file_name), m_timestamp_format(timestamp_fmt),
          m_log_mutex_ptr(std::make_shared<std::mutex>()), m_source_stamp_mode(source_stamp_mode)
    {
        // Construction starts a fresh log unless the caller selected Append. Reconfiguration never truncates.
        adopt_first_sink(/*truncate=*/open_mode == LogOpenMode::Truncate);
    }

    std::shared_ptr<detail::WinFileStream> Logger::open_sink(const std::string &file_name, bool truncate) const
    {
        // Opens a candidate sink and never touches this Logger, so reconfigure_locked() can prove the replacement
        // file before it retires the live one. Truncate starts a fresh file. Append preserves prior records.
        const std::wstring log_file_full_path = generate_log_file_path(file_name);
        if (log_file_full_path.empty() && !file_name.empty())
        {
            // generate_log_file_path() already reported the name that did not widen. An empty path names no file.
            return nullptr;
        }
        const auto mode = truncate ? (std::ios::out | std::ios::trunc) : (std::ios::out | std::ios::app);
        auto sink = std::make_shared<detail::WinFileStream>();
        sink->open(log_file_full_path, mode);

        if (!sink->is_open())
        {
            std::cerr << "[" << m_log_prefix << " Logger CRITICAL ERROR] "
                      << "Failed to open log file: " << detail::utf8_from_wide(log_file_full_path)
                      << ". Subsequent logs to file will fail." << '\n';
            return nullptr;
        }
        return sink;
    }

    void Logger::adopt_first_sink(bool truncate)
    {
        // Construction only: a failed open still leaves a stream object, because every later log() dereferences
        // m_log_file_stream_ptr and fails closed on the closed stream rather than on a null pointer.
        auto sink = open_sink(m_log_file_name, truncate);
        if (!sink)
        {
            m_log_file_stream_ptr = std::make_shared<detail::WinFileStream>();
            return;
        }
        m_log_file_stream_ptr = std::move(sink);
        write_banner_line(
            *m_log_file_stream_ptr,
            get_timestamp(m_timestamp_format),
            "Logger initialized. Logging to: " + m_log_file_name
        );
    }

    Logger::~Logger() noexcept
    {
        bool expected = false;
        if (!m_shutdown_called.compare_exchange_strong(expected, true, std::memory_order_acq_rel))
        {
            return;
        }
        shutdown_internal();
    }

    void Logger::shutdown() noexcept
    {
        bool expected = false;
        if (!m_shutdown_called.compare_exchange_strong(expected, true, std::memory_order_acq_rel))
        {
            return;
        }
        shutdown_internal();
    }

    void Logger::shutdown_internal() noexcept
    {
        // An inert first-use logger owns no async writer, sink, or shared sink mutex, so there is nothing to drain or
        // close.
        if (is_inert())
        {
            return;
        }

        // Retires the published writer. The caller holds m_async_mutex but not *m_log_mutex_ptr, which the writer
        // takes to drain before its join returns. Returns true when the writer detached and keeps final sink access.
        const auto retire_published_writer = [this](std::shared_ptr<AsyncLogger> &owner) noexcept -> bool
        {
            if (!m_async_mode_enabled.load(std::memory_order_acquire))
            {
                return false;
            }
            owner = m_async_logger.exchange(nullptr, std::memory_order_acq_rel);
            m_async_mode_enabled.store(false, std::memory_order_release);
            if (!owner)
            {
                return false;
            }
            owner->shutdown();
            m_dropped_messages.fetch_add(owner->dropped_count(), std::memory_order_relaxed);
            if (owner->writer_was_detached())
            {
                // The latch precedes the release of m_async_mutex, so configure cannot reopen behind the writer.
                m_async_writer_abandoned.store(true, std::memory_order_release);
                return true;
            }
            // The joined writer reads no state. The owner reference keeps it alive, so the root release cannot destroy
            // the writer inside its own call.
            owner->release_retention_root();
            return false;
        };

        std::shared_ptr<AsyncLogger> local_logger;
        bool writer_detached = false;
        {
            std::lock_guard<std::mutex> lock(m_async_mutex);
            writer_detached = retire_published_writer(local_logger);
        }

#if defined(DMK_ENABLE_TEST_SEAMS)
        if (auto *gap_probe = detail::g_logger_shutdown_gap_probe)
        {
            gap_probe();
        }
#endif

        // A configure call that ran inside the gap above must not leave the facade live after this shutdown continues.
        m_shutdown_called.store(true, std::memory_order_release);

        // A detached writer still owns the AsyncLogger state and final sink access. Drop this frame's handle without
        // breaking the writer's retention root and return without sink I/O. Keying on the recorded detach outcome
        // avoids a loader-lock re-query race.
        if (writer_detached)
        {
            abandon_detached_async_logger(local_logger);
            return;
        }

        // A configure() and enable_async_mode() pair in the gap can publish a writer. m_async_mutex stays held from
        // this re-check through the close, so no pair publishes between them. A writer that any path detached keeps
        // final sink access (`[B-48]`), so the close runs only while the abandoned latch is clear. Every write of that
        // latch runs under m_async_mutex. gap_logger drops after both mutexes release.
        std::shared_ptr<AsyncLogger> gap_logger;
        bool gap_writer_detached = false;
        {
            std::lock_guard<std::mutex> async_lock(m_async_mutex);
            m_shutdown_called.store(true, std::memory_order_release);
            gap_writer_detached = retire_published_writer(gap_logger);
            if (!m_async_writer_abandoned.load(std::memory_order_acquire))
            {
                std::lock_guard<std::mutex> sink_lock(*m_log_mutex_ptr);
                if (m_log_file_stream_ptr && m_log_file_stream_ptr->is_open())
                {
                    m_log_file_stream_ptr->flush();
                    m_log_file_stream_ptr->close();
                }
            }
        }
        if (gap_writer_detached)
        {
            abandon_detached_async_logger(gap_logger);
        }
    }

    void Logger::set_log_level(LogLevel level)
    {
        // LogLevel's fixed unsigned base makes a negative value unrepresentable, so the upper bound is the whole
        // domain check: an out-of-range cast arrives as a value above Error. LoggerTest.SetLogLevel_InvalidLevel pins
        // the rejection at 5, 99, and the top of the base.
        auto level_int = static_cast<std::underlying_type_t<LogLevel>>(level);
        if (level_int > static_cast<std::underlying_type_t<LogLevel>>(LogLevel::Error))
        {
            log(LogLevel::Warning,
                "Attempted to set an invalid log level value ({}). Keeping current level.",
                level_int);
            return;
        }

        auto old_level = m_current_log_level.load(std::memory_order_acquire);
#if defined(DMK_ENABLE_TEST_SEAMS)
        if (const auto transition_probe = detail::g_logger_level_transition_probe)
        {
            transition_probe();
        }
#endif

        for (;;)
        {
            if (old_level == level)
            {
                return;
            }
            if (m_current_log_level
                    .compare_exchange_weak(old_level, level, std::memory_order_acq_rel, std::memory_order_acquire))
            {
                break;
            }
        }

        // The new threshold precedes this record. The ordinary predicate discards the record after an upward change.
        (void)format_located(
            [this](std::string_view rendered) { return this->emit_record(LogLevel::Info, rendered); },
            source_stamp_enabled(LogLevel::Info),
            std::source_location::current(),
            "Log level changed from {} to {}",
            to_string(old_level),
            to_string(level)
        );
    }

    bool Logger::log(LogLevel level, std::string_view message)
    {
        if (level < m_current_log_level.load(std::memory_order_acquire))
        {
            return false;
        }

        return emit_record(level, message);
    }

    bool Logger::emit_record(LogLevel level, std::string_view message)
    {
#if defined(DMK_ENABLE_TEST_SEAMS)
        if (const auto record_probe = detail::g_logger_record_probe)
        {
            record_probe(level, message);
        }
#endif
        if (m_shutdown_called.load(std::memory_order_acquire) ||
            m_async_writer_abandoned.load(std::memory_order_acquire))
        {
            m_dropped_messages.fetch_add(1, std::memory_order_relaxed);
            return false;
        }

        // An inert first-use logger (construction failed under OOM) owns no sink or shared sink mutex. Drop and count
        // the record instead of dereferencing a null pointer; it stays inert for the process lifetime.
        if (is_inert())
        {
            m_dropped_messages.fetch_add(1, std::memory_order_relaxed);
            return false;
        }

        // Fast path: an atomic<bool> gate (a genuine lock-free read) selects async mode. The atomic<shared_ptr>
        // snapshot that follows is correct and callback-safe but takes a bounded internal STL lock, not a lock-free
        // read (see the m_async_logger member comment in logger.hpp), so it is not described as lock-free here.
        if (m_async_mode_enabled.load(std::memory_order_acquire))
        {
            auto local_logger = m_async_logger.load(std::memory_order_acquire);
            if (local_logger)
            {
#if defined(DMK_ENABLE_TEST_SEAMS)
                if (auto *snapshot_probe = detail::g_logger_async_snapshot_probe)
                {
                    snapshot_probe();
                }
#endif
                // The queue result exposes the true delivery status instead of unconditional success.
                return local_logger->enqueue_from_facade(level, message, m_dropped_messages);
            }
        }

        const auto level_str = to_string(level);
        std::lock_guard<std::mutex> lock(*m_log_mutex_ptr);

        // Close the race where shutdown exchanges the async handle after the first check but before this thread reaches
        // the synchronous sink. An admitted synchronous write finishes before shutdown can acquire this same mutex.
        if (m_shutdown_called.load(std::memory_order_acquire) ||
            m_async_writer_abandoned.load(std::memory_order_acquire))
        {
            m_dropped_messages.fetch_add(1, std::memory_order_relaxed);
            return false;
        }

        if (m_log_file_stream_ptr->is_open() && m_log_file_stream_ptr->good())
        {
            *m_log_file_stream_ptr << "[" << get_timestamp(m_timestamp_format) << "] "
                                   << "[" << std::setw(7) << std::left << level_str << "] :: " << message << '\n';

            // Flush on warnings/errors to ensure critical messages survive crashes
            if (level >= LogLevel::Warning)
            {
                m_log_file_stream_ptr->flush();
            }

            // Report whether the write (and any flush) left the stream healthy, so log_noexcept()/try_log() reflect
            // actual delivery rather than just a no-throw call.
            const bool delivered = m_log_file_stream_ptr->good();
            if (!delivered)
            {
                m_dropped_messages.fetch_add(1, std::memory_order_relaxed);
            }
            return delivered;
        }

        if (level >= LogLevel::Error)
        {
            // std::cerr is shared with the host, so the level field pads by hand and leaves its format flags unchanged.
            constexpr std::string_view level_padding{"       "};
            std::cerr << "[" << m_log_prefix << " LOG_FILE_WRITE_ERROR] [" << get_timestamp(m_timestamp_format) << "] ["
                      << level_str << level_padding.substr(std::min(level_str.size(), level_padding.size()))
                      << "] :: " << message << '\n';
        }

        // The file sink was closed or unhealthy; the message was not delivered to it (an error-level message reached
        // stderr only as a last resort). Count it so dropped_count() reflects the loss.
        m_dropped_messages.fetch_add(1, std::memory_order_relaxed);
        return false;
    }

    bool Logger::log_noexcept(LogLevel level, std::string_view message) noexcept
    {
        // The synchronous sink allocates as it formats a timestamp, and a custom stream can raise.
        // This wrapper keeps the no-throw contract for noexcept-boundary callers. The bool is log()'s delivery status.
        try
        {
            return log(level, message);
        }
        catch (...)
        {
            // log() counts every record it refuses and never throws after counting one, so this catch owns the
            // records that were lost mid-write, which otherwise leave dropped_count() below the real loss.
            m_dropped_messages.fetch_add(1, std::memory_order_relaxed);
            return false;
        }
    }

    std::string Logger::get_timestamp(const std::string &format) const
    {
        try
        {
            const auto now = std::chrono::system_clock::now();
            const auto in_time_t = std::chrono::system_clock::to_time_t(now);
            std::tm timeinfo_struct = {};

#if defined(_MSC_VER) || defined(__MINGW32__) || defined(__MINGW64__)
            // MinGW's localtime_s takes the same (struct tm *, const time_t *) argument order as MSVC, not the ISO C11
            // Annex K order, so the call is identical.
            if (localtime_s(&timeinfo_struct, &in_time_t) != 0)
            {
                throw std::runtime_error("localtime_s failed to convert time.");
            }
#else
            if (localtime_r(&in_time_t, &timeinfo_struct) == nullptr)
            {
                throw std::runtime_error("localtime_r failed to convert time.");
            }
#endif
            // Single stack buffer for timestamp + milliseconds, no heap allocation
            char buf[134];
            const size_t len = std::strftime(buf, sizeof(buf) - 5, format.c_str(), &timeinfo_struct);
            if (len == 0)
            {
                return "TIMESTAMP_FORMAT_ERROR";
            }

            const auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) % 1000;
            const int ms_len = std::snprintf(buf + len, 5, ".%03d", static_cast<int>(ms.count()));
            return std::string(buf, len + static_cast<size_t>(ms_len));
        }
        catch (const std::exception &e)
        {
            std::cerr << "[" << m_log_prefix << " Logger TIMESTAMP_ERROR] Failed to generate timestamp: " << e.what()
                      << '\n';
            return "TIMESTAMP_GENERATION_ERROR";
        }
        catch (...)
        {
            std::cerr << "[" << m_log_prefix
                      << " Logger TIMESTAMP_ERROR] Unknown exception during timestamp generation." << '\n';
            return "TIMESTAMP_GENERATION_ERROR";
        }
    }

    std::wstring Logger::generate_log_file_path(const std::string &file_name) const
    {
        const std::wstring wide_name = detail::widen_utf8(file_name);
        if (!file_name.empty() && wide_name.empty())
        {
            std::cerr << "[" << m_log_prefix << " Logger PATH_WARNING] Log file name is not well-formed UTF-8, holds a "
                      << "NUL, or exceeds INT_MAX bytes." << '\n';
            return {};
        }

        const std::filesystem::path log_file_path_obj(wide_name);
        if (log_file_path_obj.is_absolute())
        {
            return log_file_path_obj.wstring();
        }

        try
        {
            std::wstring module_dir = filesystem::get_runtime_directory();
            if (module_dir.empty() || module_dir == L".")
            {
                std::cerr << "[" << m_log_prefix << " Logger PATH_WARNING] "
                          << "Could not determine module directory. Using relative path: " << file_name << '\n';
                return log_file_path_obj.wstring();
            }

            const std::filesystem::path final_log_path = std::filesystem::path(module_dir) / log_file_path_obj;
            return final_log_path.lexically_normal().wstring();
        }
        catch (const std::exception &e)
        {
            std::cerr << "[" << m_log_prefix
                      << " Logger PATH_WARNING] Failed to determine module directory for log file: " << e.what()
                      << ". Using relative path for log file: " << file_name << '\n';
            return log_file_path_obj.wstring();
        }
        catch (...)
        {
            std::cerr << "[" << m_log_prefix
                      << " Logger PATH_WARNING] Unknown exception while determining module directory for log file."
                      << " Using relative path: " << file_name << '\n';
            return log_file_path_obj.wstring();
        }
    }

    void Logger::enable_async_mode(const AsyncLoggerConfig &config) noexcept
    {
        // An inert first-use logger has no sink to feed a writer thread; async mode stays unavailable for its
        // process-lifetime inert state.
        if (is_inert())
        {
            return;
        }

        bool sink_closed = false;
        bool activation_failed = false;
        bool activated = false;
        std::size_t queue_cap = 0;
        std::size_t batch_sz = 0;

        {
            std::lock_guard<std::mutex> lock(m_async_mutex);

            // Refuse to resurrect async logging after shutdown. The check runs under m_async_mutex because
            // shutdown_internal() drops that mutex before it closes the sink. A configure() inside that window clears
            // the latch, and shutdown_internal() then retires any writer published there (`[B-48]`).
            if (m_shutdown_called.load(std::memory_order_acquire))
            {
                return;
            }

            if (m_async_writer_abandoned.load(std::memory_order_acquire))
            {
                return;
            }

            if (m_async_mode_enabled.load(std::memory_order_acquire))
            {
                return;
            }

            if (!m_log_file_stream_ptr->is_open())
            {
                sink_closed = true;
            }
            else
            {
                try
                {
                    // Override the config's timestamp format with the Logger's own so the async sink emits the same
                    // timestamps as the synchronous path; callers configure the format through the Logger, not the
                    // async config.
                    AsyncLoggerConfig effective_config = config;
                    effective_config.timestamp_format = m_timestamp_format;
                    auto writer =
                        std::make_shared<AsyncLogger>(effective_config, m_log_file_stream_ptr, m_log_mutex_ptr);

                    // Arm the writer's retention root here: after make_shared has established shared ownership (so the
                    // stored copy is a reference into an existing control block, not a new allocation) and before
                    // publication (so the storage a loader-lock detach would need already exists the instant a detach
                    // becomes possible). Break it again on any path that does not publish. An unpublished writer has
                    // no owner left to break it later, so an unbroken root outlives the process for nothing.
                    writer->arm_retention_root(writer);
                    try
                    {
#if defined(DMK_ENABLE_TEST_SEAMS)
                        if (auto *publication_probe = detail::g_logger_publication_probe)
                        {
                            publication_probe();
                        }
#endif
                        m_async_logger.store(writer, std::memory_order_release);
                        m_async_mode_enabled.store(true, std::memory_order_release);
                    }
                    catch (...)
                    {
                        writer->release_retention_root();
                        throw;
                    }
                    activated = true;
                    queue_cap = config.queue_capacity;
                    batch_sz = config.batch_size;
                }
                catch (...)
                {
                    // Every throw here occurs before publication. The writer never existed or released its retention
                    // root, so async mode stays off and synchronous delivery remains available.
                    activation_failed = true;
                }
            }
        }

#if defined(DMK_ENABLE_TEST_SEAMS)
        if (activated)
        {
            fire_post_publication_probe();
        }
#endif

        // Diagnostics stay outside the mutex. Fixed text through try_log keeps the published path no-throw.
        if (sink_closed)
        {
            (void)try_log(LogLevel::Error, "Cannot enable async mode: log file is not open.");
        }
        else if (activation_failed)
        {
            (void)try_log(LogLevel::Error, "Failed to enable async mode.");
        }
        else if (activated)
        {
            (void)try_log(
                LogLevel::Info,
                "Async logging mode enabled. Queue capacity: {}, Batch size: {}",
                queue_cap,
                batch_sz
            );
        }
    }

    void Logger::enable_async_mode() noexcept
    {
        enable_async_mode(AsyncLoggerConfig{});
    }

    void Logger::disable_async_mode() noexcept
    {
        std::shared_ptr<AsyncLogger> local_async;
        bool writer_detached = false;
        bool should_log = false;

        {
            std::lock_guard<std::mutex> lock(m_async_mutex);

            if (!m_async_mode_enabled.load(std::memory_order_acquire))
            {
                return;
            }

            local_async = m_async_logger.exchange(nullptr, std::memory_order_acq_rel);
            if (local_async)
            {
                local_async->shutdown();
                m_dropped_messages.fetch_add(local_async->dropped_count(), std::memory_order_relaxed);
                writer_detached = local_async->writer_was_detached();
                if (writer_detached)
                {
                    // A detached writer retains final sink ownership. Make every facade operation fail closed rather
                    // than switching to a second synchronous writer on the same sink.
                    m_async_writer_abandoned.store(true, std::memory_order_release);
                    m_shutdown_called.store(true, std::memory_order_release);
                }
                else
                {
                    // Joined: local_async is the external strong owner that makes breaking the root safe.
                    local_async->release_retention_root();
                }
            }

            m_async_mode_enabled.store(false, std::memory_order_release);
            should_log = true;
        }

        // Mirror shutdown_internal's ownership rule: a detached writer keeps exclusive access to live AsyncLogger
        // state, so leave every detached writer standing on the retention root it was published with. The outcome is
        // recorded under the lifecycle mutex beside the decision it drove, so this teardown and the latches above
        // cannot disagree about which writer they are describing.
        if (writer_detached)
        {
            abandon_detached_async_logger(local_async);
        }

        if (should_log && !writer_detached)
        {
            // disable_async_mode() is noexcept; the synchronous sink can allocate and throw while formatting this
            // line. Fail closed: drop the diagnostic rather than letting an exception escape the mode switch.
            try
            {
                log(LogLevel::Info, "Async logging mode disabled. Switched to synchronous mode.");
            }
            catch (...)
            {
            }
        }
    }

    bool Logger::is_async_mode_enabled() const noexcept
    {
        return m_async_mode_enabled.load(std::memory_order_acquire);
    }

    std::size_t Logger::dropped_count() const noexcept
    {
        std::size_t total = m_dropped_messages.load(std::memory_order_relaxed);
        if (m_async_mode_enabled.load(std::memory_order_acquire))
        {
            if (auto async_logger = m_async_logger.load(std::memory_order_acquire))
            {
                total += async_logger->dropped_count();
            }
        }
        return total;
    }

    void Logger::flush() noexcept
    {
        if (is_inert() || m_async_writer_abandoned.load(std::memory_order_acquire))
        {
            return;
        }

        if (m_async_mode_enabled.load(std::memory_order_acquire))
        {
            auto local_logger = m_async_logger.load(std::memory_order_acquire);
            if (local_logger)
            {
                local_logger->flush();
                return;
            }
        }

        std::lock_guard<std::mutex> lock(*m_log_mutex_ptr);
        if (m_log_file_stream_ptr->is_open())
        {
            m_log_file_stream_ptr->flush();
        }
    }

    Logger &log() noexcept
    {
        // The process-default logger, created once and INTENTIONALLY never destroyed. A plain function-local static
        // Logger would be reclaimed during CRT atexit teardown, so a later static destructor or a detached thread that
        // logs after that point would touch freed storage. Holding the object behind a leaked pointer keeps it alive
        // for the whole process; the pointer itself is a reachable static, so a leak sanitizer sees the allocation as
        // still-reachable rather than leaked. shutdown() (invoked by the Session teardown) flushes and closes the sink
        // explicitly, so the deliberate leak costs only the object's storage, never a lost flush. First-use
        // construction can allocate: create_process_default() catches an out-of-memory failure and publishes an inert
        // drop/count logger instead of letting the throw terminate this noexcept accessor.
        static Logger *const instance = Logger::create_process_default();
        return *instance;
    }

    Logger *Logger::create_process_default() noexcept
    {
        // Prefer the full logger. If its construction throws (first-use OOM allocating the logger object, its sink,
        // or its mutex), publish a process-lifetime inert logger rather than letting the throw escape the noexcept
        // free log() and terminate the host. The inert logger allocates nothing, so this fallback is safe even while
        // allocation is still failing, and it latches for the process generation because this static runs once.
        try
        {
            return new Logger();
        }
        catch (...)
        {
            alignas(Logger) static unsigned char inert_storage[sizeof(Logger)];
            return ::new (static_cast<void *>(inert_storage)) Logger(InertTag{});
        }
    }

} // namespace DetourModKit
