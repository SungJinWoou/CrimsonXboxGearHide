/**
 * @file scan_string_xref.cpp
 * @brief String-reference (xref) anchor resolver: locate an immutable string literal in a module image, then resolve
 *        the unique instruction that references it.
 * @details Two fail-closed phases. Phase 1 locates the single occurrence of the query string in the image's readable
 *          pages (the page-gated readable scan). Phase 2 finds the single RIP-relative reference to that string: a
 *          fast, desync-immune shape scan for the dominant lea/mov forms by default, plus Zydis-verified candidate
 *          discovery for opt-in broad matches and derived-return uniqueness confirmation. Both phases resolve through
 *          the private engine page primitives. Zydis is confined to this TU: no public header exposes a Zydis type.
 */

#include "DetourModKit/scan.hpp"

#include "internal/memory_fault.hpp"
#include "internal/memory_guarded.hpp"
#include "internal/scan_engine.hpp"
#include "internal/scan_exclusions.hpp"
#include "internal/scan_fault_seam.hpp"
#include "internal/scan_pages.hpp"
#include "internal/scan_shared.hpp"

#include "DetourModKit/logger.hpp"
#include "DetourModKit/memory.hpp"

#include <windows.h>

#include <Zydis/Zydis.h>

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <new>
#include <optional>
#include <span>
#include <string>
#include <vector>

namespace DetourModKit
{
    namespace scan
    {
        namespace
        {
            struct ReferenceScanResult
            {
                std::uintptr_t site = 0;
                // Address of the reference's disp32 field. This, not the instruction start, is what identifies a
                // reference across the two phases: the field address is a property of the reference itself and is
                // identical in both, while the instruction start is a framing verdict the leaf/JIT probe may place
                // earlier than the narrow shape scan does when a byte the decoder absorbs precedes the instruction.
                std::uintptr_t key = 0;
                // One past the last byte of the reference instruction @ref site frames. The whole instruction is the
                // evidence a resolved value rides on, so a quorum member that witnesses any byte of it shares this
                // reference's failure domain; publishing only the first byte would let a selector matching the rest of
                // the same instruction abut the span instead of overlapping it.
                std::uintptr_t site_end = 0;
                std::size_t count = 0;
                // This flag is true when the TOCTOU guard skipped an execute-readable window that faulted mid-sweep.
                // The reference count is then only a lower bound, because a second reference to the string can hide
                // in that window. A uniqueness verdict must then fail closed rather than report the lone observed
                // reference as the unique site. merge_reference_scan accumulates the flag across the narrow and broad
                // sweeps.
                bool incomplete = false;
            };

            // The matched narrow reference's lea destination register and instruction length, recovered alongside the
            // unique-site search so the store-xref forward scan needs no second decode of the reference. Valid only
            // when the unique reference is a REX.W `lea reg, [rip+string]` (is_lea == true); a `mov reg, [rip+string]`
            // load already delivered the value to a register, so there is no store to model from the lea. reg is the
            // 4-bit x86-64 register number (REX.R << 3 | ModRM.reg).
            struct LeaReferenceInfo
            {
                std::uint8_t reg = 0;
                std::size_t instr_len = 0;
                std::uintptr_t window_end = 0;
                bool is_lea = false;
            };

            void merge_reference_scan(
                ReferenceScanResult &result,
                std::uintptr_t site,
                std::uintptr_t site_end,
                std::uintptr_t key,
                std::size_t count,
                bool incomplete
            ) noexcept
            {
                // Incompleteness is monotonic: once either sweep skipped a faulted window, the merged count is a lower
                // bound regardless of what the other sweep found.
                result.incomplete = result.incomplete || incomplete;
                if (count == 0)
                {
                    return;
                }
                if (count >= 2)
                {
                    result.count = 2;
                    result.site = 0;
                    result.site_end = 0;
                    result.key = 0;
                    return;
                }
                if (result.count == 0)
                {
                    result.site = site;
                    result.site_end = site_end;
                    result.key = key;
                    result.count = 1;
                    return;
                }
                if (result.key != key)
                {
                    result.site = 0;
                    result.site_end = 0;
                    result.key = 0;
                    result.count = 2;
                }
            }

            // Builds a literal-byte EnginePattern from a string query plus an optional trailing NUL, emitted as a hex
            // AOB and run through parse_aob so the string scan reuses the exact same compiled-pattern path as every
            // other AOB.
            //
            // StringEncoding::Utf8 searches for query.text byte for byte, so a caller may anchor on any byte sequence.
            // StringEncoding::Utf16le searches for the UTF-16LE encoding of that text, which requires it to be
            // well-formed UTF-8: each code point is transcoded, and a supplementary one becomes a surrogate pair.
            // Byte-wise widening is correct only for ASCII and would search for a different literal otherwise.
            //
            // An embedded NUL is rejected on both routes: it contradicts require_terminator, cannot appear in the C
            // string literals these anchors name, and would otherwise make the compiled pattern's terminator ambiguous.
            // Every allocation failure throws std::bad_alloc, the allocation contract of both public entry points.
            [[nodiscard]] Result<detail::EnginePattern> compile_string_pattern(const StringRefQuery &query)
            {
                const auto malformed = []() -> Result<detail::EnginePattern>
                { return std::unexpected(Error{ErrorCode::MalformedQueryText, "scan::find_string_xref"}); };
                if (query.text.find('\0') != std::string_view::npos)
                {
                    return malformed();
                }

                const bool wide = (query.encoding == StringEncoding::Utf16le);
                std::string aob;
                aob.reserve(query.text.size() * (wide ? 6 : 3) + 6);
                const auto emit = [&aob](std::uint8_t byte)
                {
                    static constexpr char hex_digits[] = "0123456789ABCDEF";
                    aob.push_back(hex_digits[byte >> 4]);
                    aob.push_back(hex_digits[byte & 0x0F]);
                    aob.push_back(' ');
                };
                const auto emit_utf16_unit = [&emit](char16_t unit)
                {
                    emit(static_cast<std::uint8_t>(unit & 0xFFU));
                    emit(static_cast<std::uint8_t>((unit >> 8) & 0xFFU));
                };

                if (!wide)
                {
                    for (const char ch : query.text)
                    {
                        emit(static_cast<std::uint8_t>(ch));
                    }
                }
                else
                {
                    std::size_t pos = 0;
                    while (pos < query.text.size())
                    {
                        char32_t code_point = 0;
                        if (!detail::decode_utf8(query.text, pos, code_point))
                        {
                            return malformed();
                        }
                        if (code_point < 0x10000)
                        {
                            emit_utf16_unit(static_cast<char16_t>(code_point));
                        }
                        else
                        {
                            const char32_t offset = code_point - 0x10000;
                            emit_utf16_unit(static_cast<char16_t>(0xD800 + (offset >> 10)));
                            emit_utf16_unit(static_cast<char16_t>(0xDC00 + (offset & 0x3FF)));
                        }
                    }
                }

                if (query.require_terminator)
                {
                    emit(0x00);
                    if (wide)
                    {
                        emit(0x00);
                    }
                }
                Result<detail::EnginePattern> pattern = detail::parse_aob(aob);
                if (pattern)
                {
                    return pattern;
                }
                if (pattern.error().code == ErrorCode::OutOfMemory)
                {
                    throw std::bad_alloc{};
                }
                return malformed();
            }

            // Best-effort diagnosis for executable windows skipped because they faulted mid-scan. A module image is
            // rarely decommitted under a live resolve, but collect_executable_windows only proves readability at gate
            // time, so the window scans below guard their reads and a faulted window is skipped, not fatal. try_log is
            // level-gated and no-throw.
            void log_faulted_windows(std::size_t faulted_windows) noexcept
            {
                if (faulted_windows == 0)
                {
                    return;
                }
                (void)log().try_log(
                    LogLevel::Debug,
                    "scan::find_string_xref: skipped {} executable window(s) that faulted mid-scan (concurrent "
                    "decommit/reprotect).",
                    faulted_windows
                );
            }

            // Inner narrow scan of one already-gated executable window (no fault guard). Mutates found_count /
            // first_site, returning once a second referencing site is seen (found_count == 2) so the caller fails
            // closed on ambiguity. The recognized instruction shape is documented on scan_string_ref_narrow.
            void scan_window_narrow_body(
                const detail::ExecutableWindow &window,
                std::uintptr_t string_addr,
                std::size_t instr_len,
                std::size_t &found_count,
                std::uintptr_t &first_site,
                LeaReferenceInfo *info
            ) noexcept
            {
#if defined(DMK_ENABLE_TEST_SEAMS)
                // Inside the guard's frame, so an armed address the gated window does not cover proves the guard
                // screens the faulting address rather than only the exception class.
                detail::fire_scan_fault_seam_for_test(
                    detail::g_scan_window_fault_for_test,
                    &detail::g_scan_window_fault_preparation_for_test
                );
#endif
                const auto *bytes = reinterpret_cast<const std::uint8_t *>(window.base);
                for (std::size_t i = 0; i + instr_len <= window.span; ++i)
                {
                    const std::uint8_t rex = bytes[i];
                    const std::uint8_t opcode = bytes[i + 1];
                    const std::uint8_t modrm = bytes[i + 2];
                    if (rex < 0x48 || rex > 0x4F || (opcode != 0x8D && opcode != 0x8B) || (modrm & 0xC7) != 0x05)
                    {
                        continue;
                    }
                    std::int32_t disp = 0;
                    std::memcpy(&disp, &bytes[i + 3], sizeof(disp));
                    const std::uintptr_t instr_addr = window.base + i;
                    const std::uintptr_t target =
                        instr_addr + instr_len + static_cast<std::uintptr_t>(static_cast<std::int64_t>(disp));
                    if (target != string_addr)
                    {
                        continue;
                    }
                    ++found_count;
                    if (found_count == 1)
                    {
                        first_site = instr_addr;
                        if (info != nullptr)
                        {
                            // REX.R (bit 2 of the REX byte) is the high bit of the ModRM.reg field; the narrow shape
                            // accepts REX in 0x48..0x4F, so REX.R may be set for an r8..r15 destination. opcode 0x8D is
                            // lea (a load whose pointer a following store can cache); 0x8B is a mov load with no such
                            // store to model.
                            const std::uint8_t reg =
                                static_cast<std::uint8_t>(((rex & 0x04) << 1) | ((modrm >> 3) & 0x07));
                            *info = LeaReferenceInfo{reg, instr_len, window.base + window.span, opcode == 0x8D};
                        }
                    }
                    else
                    {
                        // Ambiguous; caller maps found_count >= 2 to AmbiguousReference.
                        return;
                    }
                }
            }

            // Window-granular TOCTOU fault guard around scan_window_narrow_body. collect_executable_windows gated each
            // window with one VirtualQuery; a concurrent decommit / reprotect before these unguarded byte reads
            // complete would otherwise fault the host. Both arms claim a fault only inside the gated window bytes,
            // [window.base, window.base + window.span): on MSVC through detail::guarded_range_fault_filter, on MinGW
            // x64 through the process-wide vectored read guard the guarded_read paths use (detail::run_guarded_region),
            // armed over the same span. A fault outside it did not come from this window's reads, so it reaches the
            // host's handlers rather than being recorded as a faulted window, exactly as the broad sibling below
            // already does. A 32-bit build is rejected by the defines.hpp architecture gate, so only the two x64 arms
            // exist. Returns true when a fault was swallowed.
            bool scan_window_narrow_guarded(
                const detail::ExecutableWindow &window,
                std::uintptr_t string_addr,
                std::size_t instr_len,
                std::size_t &found_count,
                std::uintptr_t &first_site,
                LeaReferenceInfo *info
            ) noexcept
            {
#ifdef _MSC_VER
                const std::size_t original_found_count = found_count;
                const std::uintptr_t original_first_site = first_site;
                const LeaReferenceInfo original_info = (info != nullptr) ? *info : LeaReferenceInfo{};
                __try
                {
                    scan_window_narrow_body(window, string_addr, instr_len, found_count, first_site, info);
                    return false;
                }
                __except (
                    detail::guarded_range_fault_filter(
                        GetExceptionInformation(),
                        window.base,
                        window.base + window.span
                    )
                )
                {
                    // The caller skips faulted windows, so discard any reference count (and recovered lea info)
                    // collected before the fault, or a partially-scanned window could leak a stale site/register.
                    found_count = original_found_count;
                    first_site = original_first_site;
                    if (info != nullptr)
                    {
                        *info = original_info;
                    }
                    return true;
                }
#elif defined(_WIN64)
                // MinGW x64: arm the process-wide vectored read guard over exactly the bytes the window gate proved
                // readable, so a concurrent decommit / reprotect that faults the scan is swallowed and the window
                // reported faulted. That is the same skip-the-window contract that the MSVC __except arm follows.
                const std::size_t original_found_count = found_count;
                const std::uintptr_t original_first_site = first_site;
                const LeaReferenceInfo original_info = (info != nullptr) ? *info : LeaReferenceInfo{};
                struct NarrowScanContext
                {
                    const detail::ExecutableWindow *window;
                    std::uintptr_t string_addr;
                    std::size_t instr_len;
                    std::size_t *found_count;
                    std::uintptr_t *first_site;
                    LeaReferenceInfo *info;
                } scan_ctx{&window, string_addr, instr_len, &found_count, &first_site, info};

                const auto run_scan = [](void *opaque) noexcept -> void
                {
                    auto *context = static_cast<NarrowScanContext *>(opaque);
                    scan_window_narrow_body(
                        *context->window,
                        context->string_addr,
                        context->instr_len,
                        *context->found_count,
                        *context->first_site,
                        context->info
                    );
                };

                if (detail::run_guarded_region(window.base, window.base + window.span, run_scan, &scan_ctx))
                {
                    return false;
                }
                // Faulted: discard any partial count / site / lea info so a partially-scanned window cannot leak a
                // stale site or register, exactly as the MSVC arm does.
                found_count = original_found_count;
                first_site = original_first_site;
                if (info != nullptr)
                {
                    *info = original_info;
                }
                return true;
#endif
            }

            // The narrow phase sweeps execute-readable windows for dominant REX.W RIP-relative loads that resolve to
            // string_addr.
            //
            // The accepted seven-byte shape uses REX.W LEA/MOV with a RIP-relative ModRM byte and disp32. The disp32
            // starts at offset 3. Exact target equality accepts a reference. The second hit marks ambiguity. `[B-63]`
            // owns shapes outside this tier.
            std::uintptr_t scan_string_ref_narrow(
                std::uintptr_t string_addr,
                std::span<const detail::ExecutableWindow> windows,
                std::size_t &found_count,
                LeaReferenceInfo &info,
                bool &incomplete
            )
            {
                found_count = 0;
                incomplete = false;
                std::uintptr_t first_site = 0;
                info = LeaReferenceInfo{};
                // REX.W + opcode + ModRM + disp32.
                constexpr std::size_t instr_len = 7;
                // scan_window_narrow_body reads bytes[i], bytes[i+1], bytes[i+2] and a disp32 at bytes[i+3..i+6], so
                // the highest index it touches is i+6. The per-window loop only bounds i + instr_len <= span, so
                // instr_len must cover that widest read or the disp32 fetch could run up to four bytes past the window.
                // Pin the coupling here, beside the shape's byte count, so a future instr_len change cannot silently
                // reopen it.
                constexpr std::size_t narrow_max_read_index = 6;
                static_assert(
                    narrow_max_read_index < instr_len,
                    "instr_len must span scan_window_narrow_body's disp32 tail read at bytes[i+3..i+6]"
                );
                std::size_t faulted_windows = 0;

                // Adjacent execute windows require back-carry from the prior window. Without it, a split instruction
                // fits neither window and can create false uniqueness. When windows abut, the next scan includes at
                // most instr_len - 1 prior bytes. The earlier window collection applied the readability gate to those
                // bytes. A carried start never fits the prior sweep, so no duplicate count arises. The
                // StringXrefTest.NarrowReferenceStraddlingProtectionSplitIsFound and
                // NarrowTwoReferencesOneStraddlingSplitAreAmbiguous cases pin both outcomes.
                std::uintptr_t prev_end = 0;
                std::size_t prev_span = 0;
                bool have_prev = false;
                for (const detail::ExecutableWindow &window : windows)
                {
                    detail::ExecutableWindow effective = window;
                    if (have_prev && window.base == prev_end)
                    {
                        const std::size_t carry = (instr_len - 1 < prev_span) ? instr_len - 1 : prev_span;
                        effective.base = window.base - carry;
                        effective.span = window.span + carry;
                    }
                    prev_end = window.base + window.span;
                    prev_span = window.span;
                    have_prev = true;

                    if (effective.span < instr_len)
                    {
                        continue;
                    }
                    if (scan_window_narrow_guarded(effective, string_addr, instr_len, found_count, first_site, &info))
                    {
                        ++faulted_windows;
                        continue;
                    }
                    if (found_count >= 2)
                    {
                        // resolve_string_xref maps a merged count of 2 or more to AmbiguousReference.
                        incomplete = faulted_windows > 0;
                        log_faulted_windows(faulted_windows);
                        return 0;
                    }
                }
                // A skipped faulted window makes the count a lower bound. Surface it so that resolve_string_xref never
                // commits a lone surviving reference as unique. It fails closed on the truncation itself.
                incomplete = faulted_windows > 0;
                log_faulted_windows(faulted_windows);
                return (found_count == 1) ? first_site : 0;
            }

            // `[B-76]` defines the terminal predicate for forward value-attribution scans. RET, unconditional branches,
            // and the SYSRET category stop by category. INT3, UD2, and UIRET stop by mnemonic because Zydis places them
            // elsewhere. None has a fall-through path. A conditional branch keeps its fall-through path. The
            // StringXrefTest.StringPointerSlotStopsAt* and StringPointerSlotContinuesPastConditionalBranch cases pin
            // these choices.
            [[nodiscard]] bool is_non_fall_through_terminal(const ZydisDecodedInstruction &insn) noexcept
            {
                return insn.meta.category == ZYDIS_CATEGORY_RET || insn.meta.category == ZYDIS_CATEGORY_UNCOND_BR ||
                       insn.meta.category == ZYDIS_CATEGORY_SYSRET || insn.mnemonic == ZYDIS_MNEMONIC_INT3 ||
                       insn.mnemonic == ZYDIS_MNEMONIC_UD2 || insn.mnemonic == ZYDIS_MNEMONIC_UIRET;
            }

            // The store-slot scan decodes forward after `lea reg, [rip+string]`.
            // It accepts the first `REX.W MOV [rip+disp32], reg64` store within the caller's tight window.
            //
            // store_end marks one past the accepted store. The complete decoded span forms the evidence for selector
            // failure-domain overlap.
            std::uintptr_t scan_store_slot_after_lea(
                std::uintptr_t lea_site,
                std::size_t lea_len,
                std::uintptr_t window_end,
                std::uint8_t lea_reg,
                detail::ModuleSpan range,
                std::uintptr_t &store_end
            ) noexcept
            {
                store_end = 0;
                // A cached pointer is stored very close to its load; bound the forward scan so a pathological region
                // cannot scan unboundedly and the store cannot be attributed to a distant, unrelated reuse of the same
                // register.
                constexpr std::size_t forward_window = 0x80; // 128 bytes.
                const std::uintptr_t scan_lo = lea_site + lea_len;
                if (scan_lo < lea_site)
                {
                    return 0;
                }
                const std::uintptr_t scan_end = (window_end < range.end) ? window_end : range.end;
                if (scan_lo >= scan_end)
                {
                    return 0;
                }
                const std::uintptr_t scan_hi =
                    (scan_end - scan_lo < forward_window) ? scan_end : scan_lo + forward_window;

                ZydisDecoder decoder;
                if (!ZYAN_SUCCESS(ZydisDecoderInit(&decoder, ZYDIS_MACHINE_MODE_LONG_64, ZYDIS_STACK_WIDTH_64)))
                {
                    return 0;
                }
                // The lea wrote a 64-bit pointer, so the store source and any clobber are tested against the full
                // 64-bit register. ZydisRegisterEncode maps the x86 register number (REX.R << 3 | ModRM.reg) to the
                // GPR64 register.
                const ZydisRegister target_reg = ZydisRegisterEncode(ZYDIS_REGCLASS_GPR64, lea_reg);
                if (target_reg == ZYDIS_REGISTER_NONE)
                {
                    return 0;
                }

                std::uintptr_t p = scan_lo;
                while (p < scan_hi)
                {
                    std::array<std::uint8_t, ZYDIS_MAX_INSTRUCTION_LENGTH> code{};
                    const std::size_t avail =
                        (scan_hi - p < code.size()) ? static_cast<std::size_t>(scan_hi - p) : code.size();
                    if (!detail::guarded_read_bytes(p, code.data(), avail))
                    {
                        // Unreadable byte: the store sits in the same execute-readable window as the lea, so a fault
                        // here means it is not present in mapped code.
                        return 0;
                    }

                    ZydisDecodedInstruction insn;
                    ZydisDecodedOperand operands[ZYDIS_MAX_OPERAND_COUNT];
                    if (!ZYAN_SUCCESS(ZydisDecoderDecodeFull(&decoder, code.data(), avail, &insn, operands)))
                    {
                        // The store must be instruction-aligned with the lea; a decode failure means alignment was lost
                        // or the bytes are not code. Fail closed rather than accept a misaligned match.
                        return 0;
                    }

                    // The store: MOV with a RIP-relative memory destination (operand 0) and the matching 64-bit source
                    // register (operand 1). ZydisCalcAbsoluteAddress turns the destination into the slot's effective
                    // address (next-instruction address + sign-extended disp32).
                    if (insn.mnemonic == ZYDIS_MNEMONIC_MOV && insn.operand_count_visible >= 2 &&
                        operands[0].type == ZYDIS_OPERAND_TYPE_MEMORY && operands[0].mem.base == ZYDIS_REGISTER_RIP &&
                        operands[1].type == ZYDIS_OPERAND_TYPE_REGISTER && operands[1].reg.value == target_reg)
                    {
                        ZyanU64 absolute = 0;
                        if (ZYAN_SUCCESS(
                                ZydisCalcAbsoluteAddress(&insn, &operands[0], static_cast<ZyanU64>(p), &absolute)
                            ))
                        {
                            store_end = p + insn.length;
                            return static_cast<std::uintptr_t>(absolute);
                        }
                        return 0;
                    }

                    // A CALL clobbers the caller-saved registers; a store after it cannot be trusted to cache this
                    // lea's pointer, so stop conservatively rather than attribute a post-call store to the wrong value.
                    if (insn.meta.category == ZYDIS_CATEGORY_CALL)
                    {
                        return 0;
                    }
                    // A store past a non-fall-through terminal belongs to a different function or an unreachable
                    // path, so fail closed rather than attribute it to this lea.
                    if (is_non_fall_through_terminal(insn))
                    {
                        return 0;
                    }
                    // Any write to the loaded register (at any width: a 32-bit write zeroes the upper half) means a
                    // later store would cache a different value. Check every operand, including implicit ones.
                    for (std::size_t op = 0; op < insn.operand_count; ++op)
                    {
                        const ZydisDecodedOperand &operand = operands[op];
                        if (operand.type == ZYDIS_OPERAND_TYPE_REGISTER &&
                            (operand.actions & ZYDIS_OPERAND_ACTION_MASK_WRITE) != 0 &&
                            ZydisRegisterGetLargestEnclosing(ZYDIS_MACHINE_MODE_LONG_64, operand.reg.value) ==
                                target_reg)
                        {
                            return 0;
                        }
                    }

                    p += insn.length;
                }
                return 0;
            }

            // Most bytes an x86-64 instruction can place before its disp32 field: up to four legacy prefixes, a REX
            // byte, a three-byte opcode escape, and the ModRM byte the displacement directly follows. Bounding the
            // leaf/JIT backward probe by this is what keeps candidate verification constant-cost.
            constexpr std::size_t MAX_BYTES_BEFORE_DISP32 = 9;

            // Instructions decoded while walking a trusted function stream forward to reach one candidate. A real
            // function cannot exceed this before the walk is worth abandoning, and the bound stops a corrupt or hostile
            // .pdata record from turning one candidate into an unbounded decode.
            constexpr std::size_t MAX_TRUSTED_STREAM_STEPS = 8192;

            // True when @p insn has a visible memory operand based on RIP whose absolute target is @p string_addr, and
            // that operand's displacement field sits exactly at @p disp_field. Visible operands are ordered first in
            // the array, so iterating the visible count covers every explicit operand a disassembler would show. The
            // displacement-position check is what makes this a verification of a specific candidate rather than a
            // second, independent search: a decode that happens to reference the string through some other field does
            // not confirm the framing under test.
            bool instruction_references_at(
                const ZydisDecodedInstruction &insn,
                const ZydisDecodedOperand *operands,
                std::uintptr_t instr_addr,
                std::uintptr_t disp_field,
                std::uintptr_t string_addr
            ) noexcept
            {
                if (insn.raw.disp.size != 32 || instr_addr + insn.raw.disp.offset != disp_field)
                {
                    return false;
                }
                for (std::size_t op = 0; op < insn.operand_count_visible; ++op)
                {
                    const ZydisDecodedOperand &operand = operands[op];
                    if (operand.type != ZYDIS_OPERAND_TYPE_MEMORY || operand.mem.base != ZYDIS_REGISTER_RIP)
                    {
                        continue;
                    }
                    ZyanU64 absolute = 0;
                    if (ZYAN_SUCCESS(
                            ZydisCalcAbsoluteAddress(&insn, &operand, static_cast<ZyanU64>(instr_addr), &absolute)
                        ) &&
                        static_cast<std::uintptr_t>(absolute) == string_addr)
                    {
                        return true;
                    }
                }
                return false;
            }

            // Resolves the candidate at @p disp_field against a decode stream that starts at a trusted boundary. The
            // innermost .pdata RUNTIME_FUNCTION's BeginAddress is a real instruction boundary by construction, so
            // decoding forward from it reaches @p disp_field synchronized with the compiler's own framing.
            //
            // Three outcomes, and the difference between the last two is load-bearing. A nonzero value is the
            // referencing instruction's address. Zero means the stream REACHED the candidate and rejected it, so
            // probing a shorter inner framing would contradict a boundary the compiler itself declared. No value means
            // the stream produced no verdict at all: no record covers the candidate, the record is unreadable, the
            // function begins outside the bytes this window proved readable, or the decode broke or ran out of budget
            // before arriving. Treating no verdict as a rejection is what would let one undecodable byte (an embedded
            // jump table is the common case) suppress every reference after it in the same function, which is the
            // failure mode this whole discovery path exists to prevent, so those cases fall through to the probe.
            std::optional<std::uintptr_t> resolve_candidate_from_trusted_origin(
                const ZydisDecoder &decoder,
                const detail::ExecutableWindow &window,
                std::uintptr_t disp_field,
                std::uintptr_t string_addr
            ) noexcept
            {
                DWORD64 image_base = 0;
                const PRUNTIME_FUNCTION entry = RtlLookupFunctionEntry(disp_field, &image_base, nullptr);
                if (entry == nullptr || image_base == 0)
                {
                    return std::nullopt;
                }
                RUNTIME_FUNCTION record{};
                if (!detail::guarded_read_bytes(reinterpret_cast<std::uintptr_t>(entry), &record, sizeof(record)))
                {
                    // The record exists but could not be read, so it adjudicates nothing.
                    return std::nullopt;
                }
                const std::uintptr_t origin = static_cast<std::uintptr_t>(image_base) + record.BeginAddress;
                if (origin < window.base || origin > disp_field)
                {
                    // Decoding must start inside bytes this window already proved readable, and a record that does not
                    // actually precede the candidate cannot describe its stream. A function whose entry lies in an
                    // earlier window is ordinary, not suspicious, so this yields no verdict rather than a rejection.
                    return std::nullopt;
                }

                const auto *bytes = reinterpret_cast<const std::uint8_t *>(window.base);
                std::uintptr_t cursor = origin;
                for (std::size_t step = 0; step < MAX_TRUSTED_STREAM_STEPS; ++step)
                {
                    if (cursor >= window.base + window.span)
                    {
                        // The stream left the readable window before arriving, so it never saw the candidate.
                        return std::nullopt;
                    }
                    ZydisDecodedInstruction insn;
                    ZydisDecodedOperand operands[ZYDIS_MAX_OPERAND_COUNT];
                    const std::size_t offset = static_cast<std::size_t>(cursor - window.base);
                    if (!ZYAN_SUCCESS(
                            ZydisDecoderDecodeFull(&decoder, bytes + offset, window.span - offset, &insn, operands)
                        ))
                    {
                        // Real functions carry undecodable bytes: an embedded jump table, compiler padding, or data a
                        // switch lowered into .text. The stream stops there and adjudicates nothing beyond it.
                        return std::nullopt;
                    }
                    if (cursor + insn.length > disp_field)
                    {
                        // Arrived. This instruction is the compiler's own framing of the candidate's bytes, so its
                        // verdict is final in both directions.
                        return instruction_references_at(insn, operands, cursor, disp_field, string_addr) ? cursor : 0;
                    }
                    cursor += insn.length;
                }
                return std::nullopt;
            }

            // Resolves the candidate at @p disp_field without a trusted origin: leaf functions carry no unwind data,
            // and JIT or raw code buffers have no exception table at all. Every instruction start that could place a
            // disp32 at the candidate is probed, so no single framing can suppress the reference.
            //
            // Probing runs from the earliest possible start toward the candidate, so the LONGEST accepted framing wins.
            // That is the disambiguation rule, not a preference: an instruction's encoding includes its legacy prefixes
            // and REX byte, so a start that skips one decodes a different instruction that merely happens to share the
            // displacement. Reporting the shorter framing would put the site one byte past the instruction and disagree
            // with the exact narrow shape scan for the very shapes both can see.
            //
            // The converse is possible too and is not a defect here: an unrelated byte before the true start that the
            // decoder absorbs as a legacy prefix or a superseded REX yields an earlier accepted framing than the narrow
            // shape scan reports. The two phases therefore identify a reference by its displacement FIELD, not by the
            // instruction start, so a framing disagreement over one genuine reference cannot manufacture ambiguity.
            std::uintptr_t resolve_candidate_by_probe(
                const ZydisDecoder &decoder,
                const detail::ExecutableWindow &window,
                std::uintptr_t disp_field,
                std::uintptr_t string_addr
            ) noexcept
            {
                const auto *bytes = reinterpret_cast<const std::uint8_t *>(window.base);
                const std::uintptr_t floor = (disp_field - window.base >= MAX_BYTES_BEFORE_DISP32)
                                                 ? disp_field - MAX_BYTES_BEFORE_DISP32
                                                 : window.base;
                for (std::uintptr_t start = floor; start < disp_field; ++start)
                {
                    ZydisDecodedInstruction insn;
                    ZydisDecodedOperand operands[ZYDIS_MAX_OPERAND_COUNT];
                    const std::size_t offset = static_cast<std::size_t>(start - window.base);
                    if (!ZYAN_SUCCESS(
                            ZydisDecoderDecodeFull(&decoder, bytes + offset, window.span - offset, &insn, operands)
                        ))
                    {
                        continue;
                    }
                    if (instruction_references_at(insn, operands, start, disp_field, string_addr))
                    {
                        return start;
                    }
                }
                return 0;
            }

            // Inner broad scan of one already-gated executable window (no fault guard). Mutates found_count /
            // first_site and returns once a second referencing site is seen. The discovery/verification contract is
            // documented on scan_string_ref_broad.
            void scan_window_broad_body(
                const ZydisDecoder &decoder,
                const detail::ExecutableWindow &window,
                std::uintptr_t string_addr,
                std::uintptr_t count_floor,
                std::size_t &found_count,
                std::uintptr_t &first_site,
                std::uintptr_t &first_end,
                std::uintptr_t &first_key
            ) noexcept
            {
                if (window.span < sizeof(std::int32_t))
                {
                    return;
                }
                const auto *bytes = reinterpret_cast<const std::uint8_t *>(window.base);
                const std::size_t limit = window.span - sizeof(std::int32_t);
                for (std::size_t i = 0; i <= limit; ++i)
                {
                    // Candidate discovery, at every byte offset and independent of any decode. A RIP-relative operand
                    // computes target = end_of_instruction + disp32, and the instruction ends at the displacement field
                    // plus four plus whatever immediate follows, so a field can only reference the string when
                    // string_addr - (field + 4) - disp is one of the immediate widths an x86-64 instruction may place
                    // after a disp32. This is the property that makes the sweep desync-immune: a false boundary can
                    // mis-frame the bytes around a reference, but it cannot make this arithmetic stop holding.
                    std::int32_t disp = 0;
                    std::memcpy(&disp, bytes + i, sizeof(disp));
                    const std::uintptr_t disp_field = window.base + i;
                    const std::int64_t immediate_width = static_cast<std::int64_t>(string_addr) -
                                                         static_cast<std::int64_t>(disp_field + sizeof(disp)) - disp;
                    if (immediate_width != 0 && immediate_width != 1 && immediate_width != 2 && immediate_width != 4)
                    {
                        continue;
                    }

                    // Verification. The trusted .pdata stream decides wherever an exception record covers the
                    // candidate; otherwise the bounded probe covers leaf functions and code with no registered table.
                    const std::optional<std::uintptr_t> trusted_site =
                        resolve_candidate_from_trusted_origin(decoder, window, disp_field, string_addr);
                    const std::uintptr_t site =
                        trusted_site.has_value() ? *trusted_site
                                                 : resolve_candidate_by_probe(decoder, window, disp_field, string_addr);
                    if (site == 0)
                    {
                        continue;
                    }

                    // Cross-window back-carry de-duplication: this window may have been extended backward into the
                    // previous window's tail so a boundary-straddling instruction is discovered whole (see the loop in
                    // scan_string_ref_broad). An instruction that ENDS at or before count_floor lies wholly in the
                    // previous window and was already counted there. count_floor equals this window's real base, so an
                    // un-extended window counts every reference it finds.
                    const std::uintptr_t site_end =
                        disp_field + sizeof(disp) + static_cast<std::uintptr_t>(immediate_width);
                    if (site_end <= count_floor)
                    {
                        continue;
                    }

                    ++found_count;
                    if (found_count == 1)
                    {
                        first_site = site;
                        first_end = site_end;
                        first_key = disp_field;
                    }
                    else
                    {
                        // Ambiguous; caller maps found_count >= 2 to AmbiguousReference.
                        return;
                    }
                }
            }

            // Window-granular TOCTOU fault guard around scan_window_broad_body; the narrow sibling
            // scan_window_narrow_guarded documents the shared rationale. This body also leaves the window:
            // resolve_candidate_from_trusted_origin calls RtlLookupFunctionEntry, whose dynamic-function-table walk is
            // not the scanned range. A fault raised there is a defect or hostile registration, not the concurrent
            // unmap this guard exists to absorb, so it must reach the host's handlers instead of being recorded as a
            // faulted window. The nested guarded_read_bytes of the .pdata record carries its own inner range filter, so
            // its faults never arrive here. Returns true when a fault was swallowed.
            bool scan_window_broad_guarded(
                const ZydisDecoder &decoder,
                const detail::ExecutableWindow &window,
                std::uintptr_t string_addr,
                std::uintptr_t count_floor,
                std::size_t &found_count,
                std::uintptr_t &first_site,
                std::uintptr_t &first_end,
                std::uintptr_t &first_key
            ) noexcept
            {
#ifdef _MSC_VER
                const std::size_t original_found_count = found_count;
                const std::uintptr_t original_first_site = first_site;
                const std::uintptr_t original_first_end = first_end;
                const std::uintptr_t original_first_key = first_key;
                __try
                {
                    scan_window_broad_body(
                        decoder,
                        window,
                        string_addr,
                        count_floor,
                        found_count,
                        first_site,
                        first_end,
                        first_key
                    );
                    return false;
                }
                __except (
                    detail::guarded_range_fault_filter(
                        GetExceptionInformation(),
                        window.base,
                        window.base + window.span
                    )
                )
                {
                    // The caller skips faulted windows, so discard any reference count collected before the fault.
                    found_count = original_found_count;
                    first_site = original_first_site;
                    first_end = original_first_end;
                    first_key = original_first_key;
                    return true;
                }
#elif defined(_WIN64)
                // MinGW x64: same vectored read guard as the narrow sibling, armed over the gated window bytes; a fault
                // is swallowed and the window reported faulted. A 32-bit build is rejected by the defines.hpp
                // architecture gate, so only the two x64 arms exist.
                const std::size_t original_found_count = found_count;
                const std::uintptr_t original_first_site = first_site;
                const std::uintptr_t original_first_end = first_end;
                const std::uintptr_t original_first_key = first_key;
                struct BroadScanContext
                {
                    const ZydisDecoder *decoder;
                    const detail::ExecutableWindow *window;
                    std::uintptr_t string_addr;
                    std::uintptr_t count_floor;
                    std::size_t *found_count;
                    std::uintptr_t *first_site;
                    std::uintptr_t *first_end;
                    std::uintptr_t *first_key;
                } scan_ctx{
                    &decoder,
                    &window,
                    string_addr,
                    count_floor,
                    &found_count,
                    &first_site,
                    &first_end,
                    &first_key
                };

                const auto run_scan = [](void *opaque) noexcept -> void
                {
                    auto *context = static_cast<BroadScanContext *>(opaque);
                    scan_window_broad_body(
                        *context->decoder,
                        *context->window,
                        context->string_addr,
                        context->count_floor,
                        *context->found_count,
                        *context->first_site,
                        *context->first_end,
                        *context->first_key
                    );
                };

                if (detail::run_guarded_region(window.base, window.base + window.span, run_scan, &scan_ctx))
                {
                    return false;
                }
                // Faulted: discard any partial count / site so a partially-scanned window cannot leak a stale site.
                found_count = original_found_count;
                first_site = original_first_site;
                first_end = original_first_end;
                first_key = original_first_key;
                return true;
#endif
            }

            // The broad phase uses Zydis to verify every RIP-relative memory reference that resolves to string_addr.
            // `[B-63]` owns when a derived return must use this phase.
            //
            // An arbitrary byte does not identify an x86-64 instruction boundary. Discovery therefore tests target
            // arithmetic at every byte offset. Only survivors pay for decode and boundary validation. The .pdata entry
            // supplies a registered boundary, while a bounded probe covers fallback code. The second hit marks
            // ambiguity. StringXrefBoundaryProof.FalseBoundaryCannotSuppressBroadOnlyReference pins this order.
            std::uintptr_t scan_string_ref_broad(
                std::uintptr_t string_addr,
                std::span<const detail::ExecutableWindow> windows,
                std::size_t &found_count,
                std::uintptr_t &out_end,
                std::uintptr_t &out_key,
                bool &incomplete
            )
            {
                found_count = 0;
                out_end = 0;
                out_key = 0;
                incomplete = false;
                std::uintptr_t first_site = 0;
                std::uintptr_t first_end = 0;
                std::uintptr_t first_key = 0;

                ZydisDecoder decoder;
                if (!ZYAN_SUCCESS(ZydisDecoderInit(&decoder, ZYDIS_MACHINE_MODE_LONG_64, ZYDIS_STACK_WIDTH_64)))
                {
                    // A decoder that will not initialize cannot verify any reference; fail closed as "no reference"
                    // rather than guess a site.
                    return 0;
                }

                std::size_t faulted_windows = 0;
                // Cross-window back-carry, mirroring the narrow scan (and phase 1). A variable-length reference can
                // straddle the split between two abutting execute-readable windows, decodable by neither window's own
                // sweep (the previous window's decoder truncates at its end, and this window decodes from its base,
                // mid-instruction). When this window abuts the previous, decode from ZYDIS_MAX_INSTRUCTION_LENGTH - 1
                // bytes earlier so the straddler is decoded whole. A count floor at this window's real base then
                // de-duplicates: an instruction ending at or before the base was already counted by the previous
                // window, so scan_window_broad_body skips it (see there). The carry is bounded by the previous window's
                // span so it never reads before it; page-granular regions make that bound a formality.
                constexpr std::size_t broad_carry = ZYDIS_MAX_INSTRUCTION_LENGTH - 1;
                std::uintptr_t prev_end = 0;
                std::size_t prev_span = 0;
                bool have_prev = false;
                for (const detail::ExecutableWindow &window : windows)
                {
                    detail::ExecutableWindow effective = window;
                    if (have_prev && window.base == prev_end)
                    {
                        const std::size_t carry = (broad_carry < prev_span) ? broad_carry : prev_span;
                        effective.base = window.base - carry;
                        effective.span = window.span + carry;
                    }
                    prev_end = window.base + window.span;
                    prev_span = window.span;
                    have_prev = true;

                    if (scan_window_broad_guarded(
                            decoder,
                            effective,
                            string_addr,
                            window.base,
                            found_count,
                            first_site,
                            first_end,
                            first_key
                        ))
                    {
                        ++faulted_windows;
                        continue;
                    }
                    if (found_count >= 2)
                    {
                        // resolve_string_xref maps a merged count of 2 or more to AmbiguousReference.
                        incomplete = faulted_windows > 0;
                        log_faulted_windows(faulted_windows);
                        return 0;
                    }
                }
                // Surface any skipped faulted window (see scan_string_ref_narrow). resolve_string_xref fails closed on
                // a lower-bound count and does not report a lone surviving reference as unique.
                incomplete = faulted_windows > 0;
                log_faulted_windows(faulted_windows);
                if (found_count != 1)
                {
                    return 0;
                }
                out_end = first_end;
                out_key = first_key;
                return first_site;
            }

            // `[B-64]` requires the x64 exception directory before the heuristic scan. RtlLookupFunctionEntry reports
            // the image base and innermost RUNTIME_FUNCTION for registered code. A null or invalid result permits the
            // fallback.
            //
            // UNW_FLAG_CHAININFO links a funclet or hot/cold fragment to its primary function. The chained record
            // follows the padded unwind-code array at UnwindData + 4 + 2 * ((CountOfCodes + 1) & ~1). Guarded reads and
            // a bounded hop count convert invalid metadata into fallback. The
            // StringXrefTest.EnclosingFunctionFollowsChainInfoToPrimaryFunction and
            // EnclosingFunctionFallsBackWhenChainInfoIsCyclic cases pin both outcomes.
            std::uintptr_t function_entry_via_pdata(std::uintptr_t instr_addr) noexcept
            {
                DWORD64 image_base = 0;
                PRUNTIME_FUNCTION entry = RtlLookupFunctionEntry(instr_addr, &image_base, nullptr);
                if (entry == nullptr || image_base == 0)
                {
                    return 0;
                }
                const std::uintptr_t base = static_cast<std::uintptr_t>(image_base);

                // The live image backing image_base bounds every RVA this walk dereferences. A dynamically registered
                // table (RtlAddFunctionTable over a non-image allocation) has no PE header, so the span stays invalid
                // and only the checked arithmetic and the fault guard apply; a normally loaded module always resolves,
                // and its unwind metadata is additionally required to stay inside [base, base + SizeOfImage) so a
                // malformed or wrapped RVA that merely happens to land on other mapped memory cannot escape the image.
                const detail::ModuleSpan image = detail::module_span(detail::module_image_region(Address{base}));
                const auto resolve_rva_span =
                    [base, image](std::uint64_t rva, std::size_t need) -> std::optional<std::uintptr_t>
                {
                    if (rva > static_cast<std::uint64_t>(UINTPTR_MAX - base))
                    {
                        return std::nullopt;
                    }
                    const std::uintptr_t address = base + static_cast<std::uintptr_t>(rva);
                    if (need > UINTPTR_MAX - address)
                    {
                        return std::nullopt;
                    }
                    if (image.valid() && (address < image.base || address >= image.end || image.end - address < need))
                    {
                        return std::nullopt;
                    }
                    return address;
                };

                // Copy the resolved record under the guard before walking .xdata by hand. RtlLookupFunctionEntry may
                // return a module .pdata record or a dynamically registered table record; both are still process memory
                // that must fail closed on an unexpected fault.
                RUNTIME_FUNCTION current{};
                const std::uintptr_t entry_address = reinterpret_cast<std::uintptr_t>(entry);
                if ((image.valid() &&
                     (!image.contains(entry_address) || image.end - entry_address < sizeof(current))) ||
                    !detail::guarded_read_bytes(entry_address, &current, sizeof(current)))
                {
                    return 0;
                }

                constexpr int MAX_CHAIN_HOPS = 16;
                for (int hop = 0; hop < MAX_CHAIN_HOPS; ++hop)
                {
                    if (current.EndAddress <= current.BeginAddress)
                    {
                        return 0;
                    }
                    const std::optional<std::uintptr_t> function_start =
                        resolve_rva_span(current.BeginAddress, current.EndAddress - current.BeginAddress);
                    if (!function_start)
                    {
                        return 0;
                    }

                    // UNWIND_INFO fixed header: byte 0 packs Version:3 | Flags:5 (so Flags = byte0 >> 3) and byte 2 is
                    // CountOfCodes. Only these two fields drive chain traversal, so read the 4-byte header instead of
                    // modelling the whole variable-length structure.
                    std::uint8_t unwind_header[4] = {};
                    const std::optional<std::uintptr_t> unwind_addr =
                        resolve_rva_span(current.UnwindData, sizeof(unwind_header));
                    if (!unwind_addr || !detail::guarded_read_bytes(*unwind_addr, unwind_header, sizeof(unwind_header)))
                    {
                        return 0;
                    }
                    if (((unwind_header[0] >> 3) & UNW_FLAG_CHAININFO) == 0)
                    {
                        return *function_start;
                    }
                    // The chained RUNTIME_FUNCTION follows the unwind-code array, padded up to an even entry count;
                    // UnwindData is that structure's own RVA. Compute the offset in 64-bit so a large CountOfCodes or
                    // UnwindData cannot wrap the 32-bit RVA before it is bounded against the image.
                    const std::uint32_t count_of_codes = unwind_header[2];
                    const std::uint64_t chained_rva =
                        static_cast<std::uint64_t>(current.UnwindData) + 4u +
                        2u * ((static_cast<std::uint64_t>(count_of_codes) + 1u) & ~std::uint64_t{1});
                    const std::optional<std::uintptr_t> chained_addr =
                        resolve_rva_span(chained_rva, sizeof(RUNTIME_FUNCTION));
                    RUNTIME_FUNCTION chained{};
                    if (!chained_addr || !detail::guarded_read_bytes(*chained_addr, &chained, sizeof(chained)))
                    {
                        return 0;
                    }
                    current = chained;
                }

                return 0;
            }

            // `[B-64]` requires the authoritative lookup before this bounded heuristic. Absent or malformed metadata
            // permits the fallback. The scan finds the nearest 0xC3 RET or 0xCC INT3 boundary and then requires a
            // plausible prologue. It returns zero when the bounded window contains no boundary. The Windows x64 ABI
            // cleans the stack in the caller, so no epilogue uses RET imm16 and 0xC2 stays out of the boundary set.
            std::uintptr_t enclosing_function_start(std::uintptr_t instr_addr, std::uintptr_t window_lo) noexcept
            {
                if (const std::uintptr_t via_pdata = function_entry_via_pdata(instr_addr); via_pdata != 0)
                {
                    return via_pdata;
                }

                constexpr std::uintptr_t back_scan_window = 0x2000; // 8 KiB.
                const std::uintptr_t floor =
                    (instr_addr - window_lo > back_scan_window) ? instr_addr - back_scan_window : window_lo;
                if (instr_addr <= floor)
                {
                    return 0;
                }

                // Buffer the back-scan window once instead of issuing a guarded read per byte. The window is read in
                // page-sized chunks from high address to low: a chunk that faults stops the read exactly where the
                // byte-at-a-time walk would have faulted going downward, so any boundary in the already-buffered higher
                // bytes is still found, and a fault below them returns 0 just as the per-byte version did. window[k]
                // holds the byte at floor + k; valid_lo is the lowest address actually buffered.
                //
                // Left deliberately uninitialized: the chunk-read loop fills exactly [valid_lo, instr_addr) via
                // guarded_read_bytes, and both probe loops below read only indices within that filled span (they are
                // bounded by valid_lo / instr_addr), so no unwritten byte is ever observed. Value-initializing the full
                // 8 KiB every call would be dead work on this control-plane path.
                // NOLINTNEXTLINE(cppcoreguidelines-pro-type-member-init) filled before any read, see above
                std::array<std::uint8_t, static_cast<std::size_t>(back_scan_window)> window;
                std::uintptr_t valid_lo = instr_addr;
                // Windows x86/x64 base page size; guarded_read_bytes faults at this granularity. Chunks are
                // page-aligned, not instr-aligned, so a single guarded read covers at most one page and never straddles
                // a readable/unreadable page boundary.
                constexpr std::uintptr_t page_size = 0x1000;
                for (std::uintptr_t hi = instr_addr; hi > floor;)
                {
                    const std::uintptr_t page_lo = (hi - 1) & ~(page_size - 1);
                    const std::uintptr_t lo = (page_lo > floor) ? page_lo : floor;
                    const std::size_t len = static_cast<std::size_t>(hi - lo);
                    if (!detail::guarded_read_bytes(lo, window.data() + (lo - floor), len))
                    {
                        // This page is unreadable; stop. The byte-at-a-time walk would fault on the first byte here
                        // too, after exhausting the readable bytes buffered above it.
                        break;
                    }
                    valid_lo = lo;
                    hi = lo;
                }
                if (valid_lo >= instr_addr)
                {
                    // Not even the highest chunk was readable: the first probed byte would have faulted.
                    return 0;
                }

                for (std::uintptr_t probe = instr_addr; probe > valid_lo; --probe)
                {
                    const std::uint8_t boundary_byte = window[static_cast<std::size_t>(probe - 1 - floor)];
                    if (boundary_byte != 0xCC && boundary_byte != 0xC3)
                    {
                        continue;
                    }
                    // The boundary byte ends the previous function (or its padding); the enclosing function begins at
                    // the first non-INT3 byte after it.
                    std::uintptr_t start = probe;
                    while (start < instr_addr && window[static_cast<std::size_t>(start - floor)] == 0xCC)
                    {
                        ++start;
                    }
                    return is_likely_function_prologue(Address{start}) ? start : 0;
                }
                return 0;
            }
        } // namespace

        namespace
        {
            /**
             * @brief Returns the address of the only occurrence of @p pattern in the readable pages, or the phase-1
             *        failure.
             * @details The linker pools identical literals, so a second occurrence makes the anchor ambiguous and must
             *          fail closed.
             */
            [[nodiscard]] Result<std::uintptr_t> locate_unique_string(
                const detail::EnginePattern &pattern,
                const detail::ModuleSpan &range,
                const detail::ScanExclusions *provided_exclusions
            ) noexcept
            {
                // One traversal counts zero, one, or two-or-more occurrences, so the located address and the uniqueness
                // verdict describe the same view of memory; two independent passes could straddle a concurrent write
                // and certify a pairing that never existed. compile_string_pattern emits literal bytes only, so this
                // pattern carries no bounded jumps and a skipped faulted region is its only truncation channel.
                const detail::MatchResult located = detail::scan_module_readable(
                    pattern,
                    range,
                    detail::ScanQuery{
                        .occurrence = 1,
                        .count_beyond = true,
                        .exclusions = provided_exclusions,
                    }
                );
                if (located.match == nullptr)
                {
                    if (located.truncated())
                    {
                        // A truncated sweep never read part of the image, so it cannot report the literal absent.
                        return std::unexpected(Error{ErrorCode::IncompleteScan, "scan::find_string_xref"});
                    }
                    return std::unexpected(Error{ErrorCode::StringNotFound, "scan::find_string_xref"});
                }
                if (located.count > 1)
                {
                    // A second pooled copy was actually observed, so the anchor is genuinely non-unique. That verdict
                    // is authoritative and stays ambiguous even when the sweep was also truncated.
                    return std::unexpected(Error{ErrorCode::StringAmbiguous, "scan::find_string_xref"});
                }
                if (located.truncated())
                {
                    // One copy was seen, but a truncated sweep makes the count a lower bound: a second pooled copy
                    // could hide in bytes that were never read, so uniqueness is unproven. Fail closed on the
                    // truncation itself rather than on an ambiguity verdict, so the reason survives to the caller and
                    // the ladder resolver's typed-failure latch cannot degrade it to NoMatch.
                    return std::unexpected(Error{ErrorCode::IncompleteScan, "scan::find_string_xref"});
                }
                return reinterpret_cast<std::uintptr_t>(located.match);
            }

            /**
             * @brief Returns the narrow reference result over @p windows, merged with the broad result when the broad
             *        sweep runs.
             * @details The narrow sweep writes @p lea_info.
             */
            [[nodiscard]] ReferenceScanResult sweep_string_references(
                const StringRefQuery &query,
                std::uintptr_t string_addr,
                std::span<const detail::ExecutableWindow> windows,
                LeaReferenceInfo &lea_info
            )
            {
                ReferenceScanResult references{};
                std::size_t narrow_count = 0;
                bool narrow_incomplete = false;
                const std::uintptr_t narrow_site =
                    scan_string_ref_narrow(string_addr, windows, narrow_count, lea_info, narrow_incomplete);
                // The narrow shape is REX + opcode + ModRM + disp32, so its disp32 field sits exactly three bytes into
                // the instruction and the reference key is derivable from the site alone.
                merge_reference_scan(
                    references,
                    narrow_site,
                    (narrow_site != 0) ? narrow_site + lea_info.instr_len : 0,
                    (narrow_site != 0) ? narrow_site + 3 : 0,
                    narrow_count,
                    narrow_incomplete
                );

                // `[B-63]` requires a broad second check before a derived return can certify one narrow hit. The
                // narrow shape accepts REX.W LEA and MOV, so the broad sweep re-counts whichever reference the
                // narrow phase returned. A rarer-shape twin raises the count to 2 and fails closed. lea_info stays
                // unchanged, so EnclosingFunction keeps that site and StringPointerSlot still requires the narrow
                // lea. ReferencingInstruction stays on the narrow path.
                //
                // A derived anchor that remains unique pays one complete executable-range sweep.
                // ReferencingInstruction avoids that confirmation unless broad_match requests the broad phase.
                const bool derived_return = query.return_mode != XrefReturn::ReferencingInstruction;
                const bool confirm_derived_uniqueness = derived_return && references.count == 1;
                if (references.count < 2 && (query.broad_match || confirm_derived_uniqueness))
                {
                    std::size_t broad_count = 0;
                    std::uintptr_t broad_end = 0;
                    std::uintptr_t broad_key = 0;
                    bool broad_incomplete = false;
                    const std::uintptr_t broad_site = scan_string_ref_broad(
                        string_addr,
                        windows,
                        broad_count,
                        broad_end,
                        broad_key,
                        broad_incomplete
                    );
                    merge_reference_scan(references, broad_site, broad_end, broad_key, broad_count, broad_incomplete);
                }
                return references;
            }

            /**
             * @brief Maps the unique reference to the address that query.return_mode selects.
             * @details A non-null @p physical_source receives the reference extent, which StringPointerSlot extends
             *          through the store.
             */
            [[nodiscard]] Result<Address> derive_xref_return(
                const StringRefQuery &query,
                const ReferenceScanResult &references,
                const LeaReferenceInfo &lea_info,
                const detail::ModuleSpan &range,
                Region *physical_source
            ) noexcept
            {
                if (physical_source != nullptr)
                {
                    // The referencing instruction is the byte evidence every return mode rides on. Publish its whole
                    // extent, not its first byte: a co-voting selector that matches the reference from any later byte
                    // would otherwise abut this span instead of overlapping it and would double-vote one instruction.
                    // Both sweeps carry that extent (the narrow shape's decoded length, the broad sweep's framed end),
                    // so the single-byte floor below is only a defensive fallback for a site with no recorded end.
                    const std::size_t reference_length =
                        (references.site_end > references.site) ? references.site_end - references.site : 1;
                    *physical_source = Region{Address{references.site}, reference_length};
                }

                if (query.return_mode == XrefReturn::StringPointerSlot)
                {
                    // Store-xref needs the unique reference to be the narrow `lea reg, [rip+string]` whose loaded
                    // pointer a following `mov [rip+slot], reg` caches. A broad-only surviving reference never
                    // populates lea_info, and a `mov reg, [rip+string]` load has no store to attribute, so is_lea is
                    // the whole test: it is set only by the narrow sweep, and only for the site it returned.
                    if (!lea_info.is_lea)
                    {
                        return std::unexpected(Error{ErrorCode::StoreNotFound, "scan::find_string_xref"});
                    }
                    std::uintptr_t store_end = 0;
                    const std::uintptr_t slot = scan_store_slot_after_lea(
                        references.site,
                        lea_info.instr_len,
                        lea_info.window_end,
                        lea_info.reg,
                        range,
                        store_end
                    );
                    if (slot == 0)
                    {
                        return std::unexpected(Error{ErrorCode::StoreNotFound, "scan::find_string_xref"});
                    }
                    if (physical_source != nullptr && store_end > references.site)
                    {
                        // The slot address is the store's own disp32 resolved against its next-IP, so the store is the
                        // evidence this mode returns; the reference only selects which store. The forward walk decoded
                        // every instruction from the reference to it, so the run between them is evidence too and the
                        // union is one contiguous extent rather than two disjoint spans.
                        *physical_source = Region{Address{references.site}, store_end - references.site};
                    }
                    return Address{slot};
                }

                if (query.return_mode == XrefReturn::EnclosingFunction)
                {
                    const std::uintptr_t function_start = enclosing_function_start(references.site, range.base);
                    if (function_start == 0)
                    {
                        return std::unexpected(Error{ErrorCode::FunctionNotFound, "scan::find_string_xref"});
                    }
                    return Address{function_start};
                }
                return Address{references.site};
            }

            /**
             * @brief Runs the two-phase resolve behind the three entry points below.
             * @details Only the ladder resolver passes an exclusion set, through find_string_xref_with_exclusions.
             */
            Result<Address> resolve_string_xref(
                const StringRefQuery &query,
                Region scope,
                const detail::ScanExclusions *provided_exclusions,
                std::span<const Region> declared_exclusions,
                Region *physical_source = nullptr
            )
            {
                if (physical_source != nullptr)
                {
                    *physical_source = Region{};
                }
                if (!detail::valid_string_encoding(query.encoding) || !detail::valid_xref_return(query.return_mode))
                {
                    return std::unexpected(Error{ErrorCode::InvalidArg, "scan::find_string_xref"});
                }
                if (query.text.empty())
                {
                    return std::unexpected(Error{ErrorCode::EmptyQuery, "scan::find_string_xref"});
                }
                const detail::ModuleSpan range = detail::module_span(scope);
                if (!range.valid())
                {
                    return std::unexpected(Error{ErrorCode::InvalidRange, "scan::find_string_xref"});
                }
                // Phase 1 is a readable sweep and follows the Readable authority rule of scan::Pages.
                if (!detail::readable_scan_is_authoritative(range, Pages::Readable, declared_exclusions))
                {
                    return std::unexpected(Error{ErrorCode::NotAuthoritative, "scan::find_string_xref"});
                }

                detail::ScanExclusions direct_exclusions;
                if (provided_exclusions == nullptr)
                {
                    direct_exclusions.restrict_to(range.base, range.end);
                    direct_exclusions.add_text(query.text);
                    provided_exclusions = &direct_exclusions;
                }
                if (provided_exclusions->overflowed())
                {
                    return std::unexpected(Error{ErrorCode::NotAuthoritative, "scan::find_string_xref"});
                }

                const Result<detail::EnginePattern> pattern = compile_string_pattern(query);
                if (!pattern)
                {
                    // MalformedQueryText: the query defines no literal, so the caller fixes the query, not the image.
                    return std::unexpected(pattern.error());
                }
                const Result<std::uintptr_t> located_string =
                    locate_unique_string(*pattern, range, provided_exclusions);
                if (!located_string)
                {
                    return std::unexpected(located_string.error());
                }
                const std::uintptr_t string_addr = *located_string;

                // Phase 2: find the single RIP-relative reference whose target is the string. The narrow sweep is the
                // fast, desync-immune default. A broad_match query keeps that coverage and adds a Zydis sweep for rarer
                // reference shapes.
                //
                // Both sweeps run over ONE enumeration of the execute-readable windows. With two enumerations, a
                // concurrent reprotect can hide a window from the second sweep only. An absent window is
                // indistinguishable from a window that agreed, so the confirmation in sweep_string_references can then
                // certify a site that it never examined. The shared list routes any mid-sweep loss through the
                // faulted-window channel, which fails closed.
                const std::vector<detail::ExecutableWindow> windows = detail::collect_executable_windows(range);

                LeaReferenceInfo lea_info{};
                const ReferenceScanResult references = sweep_string_references(query, string_addr, windows, lea_info);

                if (references.count >= 2)
                {
                    return std::unexpected(Error{ErrorCode::AmbiguousReference, "scan::find_string_xref"});
                }
                if (references.incomplete)
                {
                    // An execute-readable window faulted mid-sweep and was skipped, so the reference count is a lower
                    // bound. A second reference to the string can hide in the skipped window. A lone surviving
                    // reference is therefore not provably unique, and a zero count is not a proven absence. Fail closed
                    // on the truncation itself, as locate_unique_string does in phase 1. The count-driven
                    // AmbiguousReference check above stays the authoritative multiplicity verdict. Only the
                    // faulted-window channel reaches here, because merge_reference_scan carries no work budget.
                    return std::unexpected(Error{ErrorCode::IncompleteScan, "scan::find_string_xref"});
                }
                if (references.count == 0)
                {
                    return std::unexpected(Error{ErrorCode::NoReference, "scan::find_string_xref"});
                }

                return derive_xref_return(query, references, lea_info, range, physical_source);
            }

        } // namespace

        Result<Address> find_string_xref(const StringRefQuery &query, Region scope)
        {
            return resolve_string_xref(query, scope, nullptr, {});
        }
    } // namespace scan

    Result<Address> detail::find_string_xref_with_exclusions(
        const scan::StringRefQuery &query,
        Region scope,
        const ScanExclusions *exclusions,
        std::span<const Region> declared_exclusions,
        Region *physical_source
    )
    {
        return scan::resolve_string_xref(query, scope, exclusions, declared_exclusions, physical_source);
    }

    Result<Address>
    detail::find_string_xref_with_provenance(const scan::StringRefQuery &query, Region scope, Region &physical_source)
    {
        return scan::resolve_string_xref(query, scope, nullptr, {}, &physical_source);
    }
} // namespace DetourModKit
