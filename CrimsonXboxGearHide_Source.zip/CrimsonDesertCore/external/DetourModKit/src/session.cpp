#include "DetourModKit/session.hpp"

#include "DetourModKit/config.hpp"
#include "DetourModKit/diagnostics.hpp"
#include "DetourModKit/input.hpp"
#include "DetourModKit/logger.hpp"
#include "DetourModKit/memory.hpp"

#include "internal/config_reload_gate.hpp"
#include "internal/diagnostics_population.hpp"
#include "internal/input_binding_lifecycle.hpp"
#include "internal/input_delivery_scope.hpp"
#include "internal/lifecycle_context.hpp"
#include "internal/memory_guarded.hpp"
#include "platform.hpp"

#include <windows.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <climits>
#include <cstdint>
#include <cwchar>
#include <exception>
#include <new>
#include <optional>
#include <string_view>
#include <type_traits>
#include <utility>

namespace DetourModKit
{
    namespace detail
    {
#if defined(DMK_ENABLE_TEST_SEAMS)
        void (*g_session_configure_test_hook)() = nullptr;
#endif

        struct SessionBootstrapAccess
        {
            [[nodiscard]] static Session make(void *instance_mutex) noexcept { return Session(instance_mutex); }
        };
    } // namespace detail

    namespace
    {
        // Static bootstrap machinery (the async DllMain path only)
        // The synchronous Session::start path touches none of these: it returns a Session the caller holds directly.
        // These statics exist only to host a Session on a worker thread across a DllMain attach/detach pair.
        // request_shutdown() may signal from any thread while a control thread retires the event. The high bit closes
        // admission; the remaining bits count callers that may already have loaded the handle.
        constexpr std::uint64_t SHUTDOWN_EVENT_RETIRED = std::uint64_t{1} << 63;
        constexpr std::uint64_t SHUTDOWN_EVENT_READER_MASK = ~SHUTDOWN_EVENT_RETIRED;
        constexpr size_t SHUTDOWN_EVENT_DRAIN_YIELDS = 1024;
        std::atomic<HANDLE> s_shutdown_event{nullptr};
        std::atomic<std::uint64_t> s_shutdown_event_access{SHUTDOWN_EVENT_RETIRED};
        static_assert(std::atomic<std::uint64_t>::is_always_lock_free);
        HANDLE s_worker_thread = nullptr;

        enum class BootstrapState : std::uint8_t
        {
            Drained,
            Starting,
            Ready,
            Draining,
            Detached
        };

        // The single admission authority for the bootstrap statics, and the serializer for the one terminal action on
        // them, without taking a lock from DllMain. Every transition into and out of Drained brackets the whole of the
        // publication or retirement it names, so no other static may be used to decide admission: a drain nulls the
        // worker handle and the event well before it has finished retiring the callback and the module identity.
        std::atomic<BootstrapState> s_bootstrap_state{BootstrapState::Drained};

        constexpr size_t BOOTSTRAP_TEXT_CAPACITY = 32768;

        struct BootstrapLoggerInfo
        {
            std::array<char, BOOTSTRAP_TEXT_CAPACITY> name{};
            std::array<char, BOOTSTRAP_TEXT_CAPACITY> log_file{};
            size_t name_size{0};
            size_t log_file_size{0};
            size_t queue_capacity{DEFAULT_QUEUE_CAPACITY};
            size_t batch_size{DEFAULT_BATCH_SIZE};
            std::chrono::milliseconds flush_interval{DEFAULT_FLUSH_INTERVAL};
            OverflowPolicy overflow_policy{OverflowPolicy::DropOldest};
            size_t spin_backoff_iterations{DEFAULT_SPIN_BACKOFF_ITERATIONS};
            std::chrono::milliseconds block_timeout_ms{16};
            size_t block_max_spin_iterations{1000};
            LogOpenMode log_open_mode{LogOpenMode::Truncate};
            LogSourceStampMode log_source_stamp_mode{};

            [[nodiscard]] bool stage(const ModInfo &info) noexcept
            {
                if (info.name.size() > name.size() || info.log_file.size() > log_file.size())
                {
                    return false;
                }

                std::copy(info.name.begin(), info.name.end(), name.begin());
                std::copy(info.log_file.begin(), info.log_file.end(), log_file.begin());
                name_size = info.name.size();
                log_file_size = info.log_file.size();
                queue_capacity = info.log.queue_capacity;
                batch_size = info.log.batch_size;
                flush_interval = info.log.flush_interval;
                overflow_policy = info.log.overflow_policy;
                spin_backoff_iterations = info.log.spin_backoff_iterations;
                block_timeout_ms = info.log.block_timeout_ms;
                block_max_spin_iterations = info.log.block_max_spin_iterations;
                log_open_mode = info.log_open_mode;
                log_source_stamp_mode = info.log_source_stamp_mode;
                return true;
            }

            [[nodiscard]] std::string_view name_view() const noexcept { return {name.data(), name_size}; }
            [[nodiscard]] std::string_view log_file_view() const noexcept { return {log_file.data(), log_file_size}; }

            [[nodiscard]] AsyncLoggerConfig logger_config() const
            {
                AsyncLoggerConfig config{};
                config.queue_capacity = queue_capacity;
                config.batch_size = batch_size;
                config.flush_interval = flush_interval;
                config.overflow_policy = overflow_policy;
                config.spin_backoff_iterations = spin_backoff_iterations;
                config.block_timeout_ms = block_timeout_ms;
                config.block_max_spin_iterations = block_max_spin_iterations;
                return config;
            }

            void clear() noexcept
            {
                name_size = 0;
                log_file_size = 0;
            }
        };

        BootstrapLoggerInfo s_bootstrap_logger_info;

        // These two objects may still own consumer state when DLL_PROCESS_DETACH runs. Construct them into raw static
        // storage so the CRT never registers destructors for them: a clean off-loader-lock drain resets their contents,
        // while loader detach retains them untouched instead of destroying callback captures inside DllMain.
        using ReadyCallback = std::move_only_function<Result<void>(Session &)>;
        alignas(std::optional<Session>) unsigned char s_pending_session_storage[sizeof(std::optional<Session>)];
        alignas(ReadyCallback) unsigned char s_on_ready_storage[sizeof(ReadyCallback)];
        std::optional<Session> &s_pending_session =
            *::new (static_cast<void *>(s_pending_session_storage)) std::optional<Session>();
        ReadyCallback &s_on_ready = *::new (static_cast<void *>(s_on_ready_storage)) ReadyCallback();

        // This trivial pointer needs no raw-storage treatment.
        BootstrapReadyFn s_on_ready_fn = nullptr;
        static_assert(
            std::is_trivially_copyable_v<BootstrapReadyFn> && std::is_trivially_destructible_v<BootstrapReadyFn>,
            "the DllMain attach callback must stage no consumer capture (see bootstrap_attach)."
        );

#if defined(DMK_ENABLE_TEST_SEAMS)
        // Counts signals that reached SetEvent on a handle the kernel had already invalidated. Admission is supposed to
        // make that impossible, so a nonzero count is the direct observation of the use-after-close this word prevents,
        // and a test can assert it unconditionally rather than inferring safety from which retirement branch ran.
        std::atomic<std::uint64_t> s_signal_on_invalid_event{0};
        void (*s_bootstrap_pre_setup_probe)() noexcept = nullptr;
#endif

        void signal_shutdown_event() noexcept
        {
            // Observing "not retired" and registering as a reader must be ONE atomic step. A plain load followed by an
            // unconditional fetch_add lets a caller preempted between the two land its increment on a generation that
            // was retired and reopened meanwhile: its matching decrement then underflows the reopened word to all-ones
            // (which has the retired bit set) and no later request can ever signal that generation again.
            std::uint64_t access = s_shutdown_event_access.load(std::memory_order_acquire);
            do
            {
                if ((access & SHUTDOWN_EVENT_RETIRED) != 0)
                {
                    return;
                }
            } while (
                !s_shutdown_event_access
                     .compare_exchange_weak(access, access + 1, std::memory_order_acq_rel, std::memory_order_acquire)
            );

            if (HANDLE event = s_shutdown_event.load(std::memory_order_acquire))
            {
#if defined(DMK_ENABLE_TEST_SEAMS)
                if (!SetEvent(event))
                {
                    s_signal_on_invalid_event.fetch_add(1, std::memory_order_relaxed);
                }
#else
                SetEvent(event);
#endif
            }
            s_shutdown_event_access.fetch_sub(1, std::memory_order_release);
        }

        /**
         * @brief Closes admission and drops the event pointer, retaining any live kernel object.
         * @return true when a live handle was dropped, so the caller records the retention it just created.
         */
        [[nodiscard]] bool abandon_shutdown_event() noexcept
        {
            s_shutdown_event_access.fetch_or(SHUTDOWN_EVENT_RETIRED, std::memory_order_acq_rel);
            return s_shutdown_event.exchange(nullptr, std::memory_order_acq_rel) != nullptr;
        }

        void close_shutdown_event_at_process_exit() noexcept
        {
            s_shutdown_event_access.fetch_or(SHUTDOWN_EVENT_RETIRED, std::memory_order_acq_rel);
            if (HANDLE event = s_shutdown_event.exchange(nullptr, std::memory_order_acq_rel))
            {
                CloseHandle(event);
            }
        }

        void retire_shutdown_event_after_drain() noexcept
        {
            s_shutdown_event_access.fetch_or(SHUTDOWN_EVENT_RETIRED, std::memory_order_acq_rel);
            const HANDLE event = s_shutdown_event.exchange(nullptr, std::memory_order_acq_rel);
            if (event == nullptr)
            {
                return;
            }

            for (size_t i = 0; i < SHUTDOWN_EVENT_DRAIN_YIELDS; ++i)
            {
                if ((s_shutdown_event_access.load(std::memory_order_acquire) & SHUTDOWN_EVENT_READER_MASK) == 0)
                {
                    CloseHandle(event);
                    return;
                }
                SwitchToThread();
            }

            // A suspended signaler may retain access indefinitely. Keep its handle valid instead of blocking teardown.
            diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::Bootstrap);
        }

        Result<bool> is_target_process(std::string_view expected, const char *operation) noexcept
        {
            if (expected.empty())
            {
                return true;
            }

            // The full path can exceed MAX_PATH. Static storage covers Windows' extended path limit without allocating
            // in a DllMain caller; lifecycle admission serializes every writer of this scratch buffer.
            constexpr DWORD MODULE_PATH_CAPACITY = 32768;
            static wchar_t s_exe_path[MODULE_PATH_CAPACITY];
            const DWORD path_size = GetModuleFileNameW(nullptr, s_exe_path, MODULE_PATH_CAPACITY);
            if (path_size == 0)
            {
                return std::unexpected(Error{ErrorCode::SystemCallFailed, operation, GetLastError()});
            }
            if (path_size >= MODULE_PATH_CAPACITY)
            {
                return std::unexpected(Error{ErrorCode::SystemCallFailed, operation, ERROR_INSUFFICIENT_BUFFER});
            }

            const wchar_t *exe_name = std::wcsrchr(s_exe_path, L'\\');
            exe_name = exe_name ? exe_name + 1 : s_exe_path;

            // MultiByteToWideChar takes an int input count. Reject only values outside that domain.
            // The fixed buffer rejects malformed input and values beyond MAX_PATH - 1 UTF-16 code units.
            if (expected.size() > static_cast<size_t>(INT_MAX))
            {
                return false;
            }
            wchar_t expected_buf[MAX_PATH];
            const int wide_len = MultiByteToWideChar(
                CP_UTF8,
                MB_ERR_INVALID_CHARS,
                expected.data(),
                static_cast<int>(expected.size()),
                expected_buf,
                MAX_PATH - 1
            );
            if (wide_len <= 0)
            {
                return false;
            }
            return CompareStringOrdinal(exe_name, -1, expected_buf, wide_len, TRUE) == CSTR_EQUAL;
        }

        /**
         * @brief Classifies the outcome of a single-instance mutex acquisition.
         */
        enum class MutexAcquire : std::uint8_t
        {
            /// A fresh mutex was created; @p out holds the handle the Session must close.
            Acquired,
            /// No prefix was requested; @p out is null and no single-instance guard exists.
            NoGuard,
            /// The named mutex already existed: another load of this mod is live.
            AlreadyHeld,
            /// CreateMutexW failed; @p err holds GetLastError().
            SystemError
        };

        // Builds a per-PID named mutex from @p prefix and reports whether this load won the single-instance race.
        // Static scratch storage avoids heap work in bootstrap; lifecycle admission serializes every writer.
        MutexAcquire acquire_instance_mutex(std::string_view prefix, HANDLE &out, DWORD &err) noexcept
        {
            out = nullptr;
            err = 0;
            if (prefix.empty())
            {
                return MutexAcquire::NoGuard;
            }

            constexpr size_t MUTEX_NAME_CAPACITY = 32768;
            static wchar_t s_mutex_name[MUTEX_NAME_CAPACITY];
            constexpr size_t MAX_PID_DIGITS = 10;
            if (prefix.size() > MUTEX_NAME_CAPACITY - MAX_PID_DIGITS - 1)
            {
                err = ERROR_FILENAME_EXCED_RANGE;
                return MutexAcquire::SystemError;
            }

            size_t name_size = 0;
            for (const char character : prefix)
            {
                s_mutex_name[name_size++] = static_cast<wchar_t>(static_cast<unsigned char>(character));
            }

            wchar_t reversed_pid[MAX_PID_DIGITS];
            size_t pid_digits = 0;
            DWORD pid = GetCurrentProcessId();
            do
            {
                reversed_pid[pid_digits++] = static_cast<wchar_t>(L'0' + pid % 10);
                pid /= 10;
            } while (pid != 0);
            while (pid_digits != 0)
            {
                s_mutex_name[name_size++] = reversed_pid[--pid_digits];
            }
            s_mutex_name[name_size] = L'\0';

            HANDLE handle = CreateMutexW(nullptr, FALSE, s_mutex_name);
            if (!handle)
            {
                err = GetLastError();
                return MutexAcquire::SystemError;
            }
            if (GetLastError() == ERROR_ALREADY_EXISTS)
            {
                CloseHandle(handle);
                return MutexAcquire::AlreadyHeld;
            }
            out = handle;
            return MutexAcquire::Acquired;
        }

        [[nodiscard]] Result<HANDLE>
        begin_session(const ModInfo &info, const char *operation, detail::LoaderContext loader_context) noexcept
        {
            if (!detail::lifecycle().begin_start())
            {
                return std::unexpected(Error{ErrorCode::SessionAlreadyActive, operation});
            }

            Result<bool> target_process = is_target_process(info.game_process_name, operation);
            if (!target_process)
            {
                detail::lifecycle().mark_stopped();
                return std::unexpected(target_process.error());
            }
            if (!*target_process)
            {
                detail::lifecycle().mark_stopped();
                return std::unexpected(Error{ErrorCode::ProcessMismatch, operation});
            }

            HANDLE mutex = nullptr;
            DWORD error = 0;
            switch (acquire_instance_mutex(info.instance_mutex_prefix, mutex, error))
            {
            case MutexAcquire::AlreadyHeld:
                detail::lifecycle().mark_stopped();
                return std::unexpected(Error{ErrorCode::InstanceAlreadyRunning, operation});
            case MutexAcquire::SystemError:
                detail::lifecycle().mark_stopped();
                return std::unexpected(Error{ErrorCode::SystemCallFailed, operation, error});
            case MutexAcquire::NoGuard:
            case MutexAcquire::Acquired:
                break;
            }

            // This identity takes no reference. The bootstrap worker acquires its separate keepalive before
            // CreateThread.
            constexpr DWORD CAPTURE_FLAGS =
                GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT;
            HMODULE captured_module = nullptr;
            if (!GetModuleHandleExW(CAPTURE_FLAGS, reinterpret_cast<LPCWSTR>(&begin_session), &captured_module))
            {
                error = GetLastError();
                if (mutex != nullptr)
                {
                    CloseHandle(mutex);
                }
                detail::lifecycle().mark_stopped();
                return std::unexpected(Error{ErrorCode::SystemCallFailed, operation, error});
            }
            detail::lifecycle().publish_module(captured_module);

            // Publish the phase only once the fallible gates have passed. begin_start() already reset the context to
            // Normal for this epoch, so every rollback above leaves a neutral phase behind rather than stranding a
            // non-blocking Attach that would fail-close every later teardown in a process that never started.
            detail::lifecycle().set_loader_context(loader_context);
            return mutex;
        }

        /**
         * @brief Applies the subsystem order in the Session contract.
         * @details SessionTeardown.FullStackTeardownShutsEveryLeafDown proves leaf completion.
         *          Lifecycle.DiagnosticsTlsIndexReturnsWithTheSession pins the diagnostics release after config::clear.
         */
        void run_subsystem_teardown() noexcept
        {
            // First: the watcher thread can fire on_reload into any state below.
            config::disable_auto_reload();
            input::Input::instance().shutdown();
            memory::shutdown_cache();
            config::clear();
            // After config::clear, because a config callback can own a subscription.
            detail::release_diagnostics_emit_owners(
                detail::DiagnosticsTeardown::Session,
                detail::blocking_teardown_permitted()
            );
            // Last: every prior step can still log.
            log().shutdown();
        }

        /**
         * @brief Rolls a pre-publication attach back to a retryable Drained slot.
         * @param instance_mutex The preflight mutex, or nullptr when no guard was requested.
         * @details No Session or callback has been published when this runs. Closing the local mutex releases the
         *          instance gate without subsystem teardown or consumer destruction in DllMain.
         */
        void unwind_bootstrap(HANDLE instance_mutex) noexcept
        {
            if (abandon_shutdown_event())
            {
                diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::Bootstrap);
            }
            if (instance_mutex != nullptr)
            {
                CloseHandle(instance_mutex);
            }
            s_bootstrap_logger_info.clear();
            detail::lifecycle().clear_module();
            // Retire the Attach phase with the attach it described. Leaving it published would fail-close every later
            // teardown in a process whose consumer declined the load but kept using the library.
            detail::lifecycle().set_loader_context(detail::LoaderContext::Normal);
            detail::lifecycle().mark_stopped();
            s_bootstrap_state.store(BootstrapState::Drained, std::memory_order_release);
        }

        void retire_bootstrap_after_drain() noexcept
        {
            // Idempotent after the worker's own clear. It stays because this is the single retirement point for a
            // caller that arrives without a completed join. LifecycleContext::clear_worker_thread owns the hazard.
            detail::lifecycle().clear_worker_thread();
            retire_shutdown_event_after_drain();
            s_on_ready = nullptr;
            s_on_ready_fn = nullptr;
            s_bootstrap_logger_info.clear();
            detail::lifecycle().clear_module();
            // Retire the drain phase with everything else this drain retires, so the published word keeps describing
            // the phase the process is actually in. Both Normal and ExplicitDrain authorize blocking, so this is a
            // consistency store rather than a change of permission.
            detail::lifecycle().set_loader_context(detail::LoaderContext::Normal);
        }

        /**
         * @brief Retires the worker identity and releases its module reference on thread exit.
         * @details FreeLibraryAndExitThread cannot return through code that its final reference release unmaps.
         */
        [[noreturn]] void exit_bootstrap_worker(HMODULE self_ref) noexcept
        {
            detail::lifecycle().clear_worker_thread();
            detail::module_pin_observability::note_released(diagnostics::ModulePinReason::Bootstrap);
            FreeLibraryAndExitThread(self_ref, 0);
        }

        // The bootstrap worker. It finishes Session setup, runs on_ready, and performs teardown off the loader lock.
        DWORD WINAPI lifecycle_thread(LPVOID param) noexcept
        {
            const HMODULE self_ref = static_cast<HMODULE>(param);

            // Publish this thread's identity FIRST, before any consumer code can run on it. Collecting it from
            // CreateThread's out-parameter instead would leave a window in which on_ready is already executing while
            // the id is still 0, and a drain requested from inside on_ready would then slip past the self-drain guard
            // and report success for a session that is fully live. Publishing here closes that window without
            // resuming a thread from under the loader lock. The same identity authorizes this thread's teardown to
            // block regardless of the phase the DllMain thread publishes.
            detail::lifecycle().publish_worker_thread();

            // bootstrap_core publishes the thread handle before the Session and callback.
            // An off-loader-lock rich bootstrap requires this short publication wait.
            BootstrapState state = s_bootstrap_state.load(std::memory_order_acquire);
            while (state == BootstrapState::Starting)
            {
                SwitchToThread();
                state = s_bootstrap_state.load(std::memory_order_acquire);
            }

            // A control thread may claim Ready -> Draining before this thread observes Ready. Draining still owns a
            // fully published Session, callback, and shutdown event; adopt them and let the already-signalled event
            // drive the ordinary teardown so the waiting control thread can complete the drain.
            // An empty optional is unreachable. bootstrap_core stages the Session before its Ready release store, and
            // every state the spin can observe follows that store. Guard anyway.
            if ((state != BootstrapState::Ready && state != BootstrapState::Draining) || !s_pending_session)
            {
                exit_bootstrap_worker(self_ref);
            }

#if defined(DMK_ENABLE_TEST_SEAMS)
            if (s_bootstrap_pre_setup_probe != nullptr)
            {
                s_bootstrap_pre_setup_probe();
            }
#endif

            // A thread created from DllMain cannot execute its entry point until the loader releases the attach
            // notification. Publishing Normal retires the Attach phase before logger/file setup begins.
            detail::lifecycle().set_loader_context(detail::LoaderContext::Normal);

            {
                Session session = std::move(*s_pending_session);
                s_pending_session.reset();

                try
                {
                    Logger::configure(
                        s_bootstrap_logger_info.name_view(),
                        s_bootstrap_logger_info.log_file_view(),
                        DEFAULT_TIMESTAMP_FORMAT,
                        s_bootstrap_logger_info.log_open_mode,
                        s_bootstrap_logger_info.log_source_stamp_mode
                    );
                    DetourModKit::log().enable_async_mode(s_bootstrap_logger_info.logger_config());
                }
                catch (const std::bad_alloc &)
                {
                    OutputDebugStringA(
                        "DetourModKit: bootstrap logger setup ran out of memory; continuing without "
                        "guaranteed logging.\n"
                    );
                }
                catch (...)
                {
                    OutputDebugStringA(
                        "DetourModKit: bootstrap logger setup failed; continuing without guaranteed "
                        "logging.\n"
                    );
                }
#if !defined(_MSC_VER) && defined(_WIN64)
                detail::reopen_guarded_engine();
#endif
                detail::lifecycle().mark_running();

                if (const BootstrapReadyFn ready_fn = s_on_ready_fn; ready_fn != nullptr || s_on_ready)
                {
                    try
                    {
                        Result<void> ready = ready_fn != nullptr ? ready_fn(session) : s_on_ready(session);
                        if (!ready)
                        {
                            (void)log().try_log(
                                LogLevel::Error,
                                "bootstrap: on_ready reported failure: {}",
                                ready.error().message()
                            );
                        }
                    }
                    catch (const std::exception &e)
                    {
                        (void)log().try_log(LogLevel::Error, "bootstrap: on_ready threw: {}", e.what());
                    }
                    catch (...)
                    {
                        (void)log().try_log(LogLevel::Error, "bootstrap: on_ready threw an unknown exception.");
                    }
                }

                if (HANDLE event = s_shutdown_event.load(std::memory_order_acquire))
                {
                    WaitForSingleObject(event, INFINITE);
                }

                // `session` destructs at the end of this inner scope -> ordered teardown off the loader lock -> leaves
                // JOIN, all while self_ref keeps this module's code mapped through the teardown.
            }

            // The identity retires only after the teardown it authorized.
            exit_bootstrap_worker(self_ref);
        }

#if defined(DMK_ENABLE_TEST_SEAMS)
        // Forces worker launch to fail after process and instance gating but before consumer state is published.
        std::atomic<bool> s_fail_worker_launch{false};
#endif

        // Creates the bootstrap worker. Routed through one function so the test seam fails into CreateThread's own
        // rollback branch rather than duplicating it.
        [[nodiscard]] HANDLE launch_bootstrap_worker(HMODULE worker_ref) noexcept
        {
#if defined(DMK_ENABLE_TEST_SEAMS)
            if (s_fail_worker_launch.load(std::memory_order_acquire))
            {
                SetLastError(ERROR_NOT_ENOUGH_MEMORY);
                return nullptr;
            }
#endif
            return CreateThread(nullptr, 0, lifecycle_thread, worker_ref, 0, nullptr);
        }

        // A generation publishes one callback representation.
        [[nodiscard]] Result<void>
        bootstrap_core(const ModInfo &info, ReadyCallback *rich_on_ready, BootstrapReadyFn fn_on_ready) noexcept
        {
            // Claim the slot before touching any other static. A drain nulls the worker handle and the shutdown event
            // early but publishes Drained only after it has also retired the init callback and the module identity, so
            // admitting on those handles would let this generation publish into the tail of that retirement and have
            // its own callback destroyed and its own Ready overwritten by the drainer that is still finishing.
            BootstrapState expected = BootstrapState::Drained;
            if (!s_bootstrap_state
                     .compare_exchange_strong(expected, BootstrapState::Starting, std::memory_order_acq_rel))
            {
                if (expected == BootstrapState::Draining)
                {
                    return std::unexpected(Error{ErrorCode::SessionShutdownInProgress, "bootstrap"});
                }
                if (expected == BootstrapState::Detached)
                {
                    return std::unexpected(Error{ErrorCode::SessionShutdownUnavailable, "bootstrap"});
                }
                // Starting or Ready: another generation owns the slot.
                return std::unexpected(Error{ErrorCode::SessionAlreadyActive, "bootstrap"});
            }

            // A retirement that had to retain its event leaves a previous generation's signaler still inside SetEvent.
            // Its pending fetch_sub would underflow the access word this generation reopens, so refuse until that
            // signaler has left rather than start on a corrupted admission count. Checked here as well as at the
            // reopen so a doomed attach costs nothing: the reopen below is the authority.
            if (s_shutdown_event_access.load(std::memory_order_acquire) != SHUTDOWN_EVENT_RETIRED)
            {
                s_bootstrap_state.store(BootstrapState::Drained, std::memory_order_release);
                return std::unexpected(Error{ErrorCode::SessionShutdownInProgress, "bootstrap"});
            }

            // Keep the gates that let DllMain decline the load synchronous, but defer logger/file setup to the worker.
            Result<HANDLE> instance_mutex = begin_session(info, "bootstrap", detail::LoaderContext::Attach);
            if (!instance_mutex)
            {
                s_bootstrap_state.store(BootstrapState::Drained, std::memory_order_release);
                return std::unexpected(instance_mutex.error());
            }
            // begin_session publishes the DllMain module identity without a consumer-supplied handle.
            (void)DisableThreadLibraryCalls(detail::lifecycle().module());

            if (!s_bootstrap_logger_info.stage(info))
            {
                unwind_bootstrap(*instance_mutex);
                return std::unexpected(Error{ErrorCode::InvalidArg, "bootstrap"});
            }

            // Create into a local first, then publish with a release store so the worker's / consumer's acquire load
            // observes a fully-constructed handle. Owning Starting is what makes the slot free to publish into. The
            // TRUE second argument makes this a MANUAL-RESET event: a shutdown request is a one-way latch, so once
            // request_shutdown() signals it the event stays signaled. The worker observes it whether or not it was
            // already waiting, and a repeated request_shutdown() is idempotent (an auto-reset event would clear itself
            // after a single wait woke and could drop a later observer).
            const HANDLE shutdown_event = CreateEventW(nullptr, TRUE, FALSE, nullptr);
            if (!shutdown_event)
            {
                const DWORD err = GetLastError();
                unwind_bootstrap(*instance_mutex);
                return std::unexpected(Error{ErrorCode::SystemCallFailed, "bootstrap", err});
            }
            // Reopen admission by CLAIMING the retired word, never by storing over it: a straggling signaler from the
            // retired generation can still be counted, and a blind store would discard its registration and leave its
            // pending decrement to underflow the word. Reopening before the handle is published also keeps a signaler
            // admitted after this point from ever loading a half-published pointer.
            std::uint64_t retired_access = SHUTDOWN_EVENT_RETIRED;
            if (!s_shutdown_event_access
                     .compare_exchange_strong(retired_access, 0, std::memory_order_acq_rel, std::memory_order_acquire))
            {
                CloseHandle(shutdown_event);
                unwind_bootstrap(*instance_mutex);
                return std::unexpected(Error{ErrorCode::SessionShutdownInProgress, "bootstrap"});
            }
            s_shutdown_event.store(shutdown_event, std::memory_order_release);

            // Acquire the worker's module reference BEFORE CreateThread. A thread created from DllMain may not execute
            // its entry point until after the loader releases the attach notification, but the caller can FreeLibrary
            // immediately after LoadLibrary returns. The reference therefore has to exist before the worker is
            // scheduled, not at the top of the worker function.
            const HMODULE worker_ref = detail::try_acquire_module_ref(diagnostics::ModulePinReason::Bootstrap);
            if (worker_ref == nullptr)
            {
                const DWORD err = GetLastError();
                unwind_bootstrap(*instance_mutex);
                return std::unexpected(Error{ErrorCode::SystemCallFailed, "bootstrap", err});
            }

            // The worker publishes its own thread id as its first instruction, so this call does not collect it. A
            // CREATE_SUSPENDED plus ResumeThread is not leaf-safe inside DllMain.
            s_worker_thread = launch_bootstrap_worker(worker_ref);
            if (!s_worker_thread)
            {
                const DWORD err = GetLastError();
                detail::release_module_ref(worker_ref, diagnostics::ModulePinReason::Bootstrap);
                unwind_bootstrap(*instance_mutex);
                return std::unexpected(Error{ErrorCode::SystemCallFailed, "bootstrap", err});
            }

            // No fallible operation remains. Stage the Session and callback, then release the worker from its Starting
            // wait. This ordering also keeps a launch failure from destroying consumer state or shutting subsystems
            // down inside DllMain.
            s_pending_session.emplace(detail::SessionBootstrapAccess::make(*instance_mutex));
            if (rich_on_ready != nullptr)
            {
                s_on_ready = std::move(*rich_on_ready);
            }
            s_on_ready_fn = fn_on_ready;
            s_bootstrap_state.store(BootstrapState::Ready, std::memory_order_release);
            return {};
        }

    } // anonymous namespace

    Session::Session(void *instance_mutex) noexcept : m_instance_mutex(instance_mutex), m_active(true) {}

    Session::Session(Session &&other) noexcept
        : m_scope(std::move(other.m_scope)), m_instance_mutex(other.m_instance_mutex), m_active(other.m_active)
    {
        // Leave the source inert so its destructor does nothing: exactly one Session ever carries the live teardown.
        other.m_instance_mutex = nullptr;
        other.m_active = false;
    }

    Session &Session::operator=(Session &&other) noexcept
    {
        if (this != &other)
        {
            // Assigning over a live Session ends it: run the full ordered teardown of THIS session first (which also
            // clears the single-session guard), then adopt the source. A mod holds one session at a time, so the source
            // is always inert here; a no-op release() when this Session is already inert makes the common
            // reassign-a-moved-from-Session case free.
            release();
            m_scope = std::move(other.m_scope);
            m_instance_mutex = other.m_instance_mutex;
            m_active = other.m_active;
            other.m_instance_mutex = nullptr;
            other.m_active = false;
        }
        return *this;
    }

    Session::~Session() noexcept
    {
        // Moved-from or abandon()ed sessions are inert, so release() is a no-op and a double-drop never
        // double-tears-down.
        release();
    }

    void Session::release() noexcept
    {
        // The Session class `[B-100]` warning owns the caller precondition.
        if (!m_active)
        {
            return;
        }

        // Enter Stopping so a start racing this teardown stays rejected until the slot is fully released.
        detail::lifecycle().begin_stop();
        m_scope.clear();
        run_subsystem_teardown();
        if (m_instance_mutex)
        {
            CloseHandle(static_cast<HANDLE>(m_instance_mutex));
            m_instance_mutex = nullptr;
        }
        m_active = false;
        // The identity retires with the session, after every teardown callback that can still read it.
        detail::lifecycle().clear_module();
        detail::lifecycle().mark_stopped();
    }

    Result<Session> Session::start(const ModInfo &info) noexcept
    {
        Result<HANDLE> instance_mutex = begin_session(info, "Session::start", detail::LoaderContext::Normal);
        if (!instance_mutex)
        {
            return std::unexpected(instance_mutex.error());
        }

        // Logger::configure can throw while it builds owned strings. A std::bad_alloc maps to OutOfMemory.
        // Every other exception maps to Unknown because a retry cannot clear an arbitrary fault.
        // enable_async_mode contains its failures, so this catch owns only configuration.
        try
        {
#if defined(DMK_ENABLE_TEST_SEAMS)
            if (const auto probe = detail::g_session_configure_test_hook)
                probe();
#endif
            Logger::configure(
                info.name,
                info.log_file,
                DEFAULT_TIMESTAMP_FORMAT,
                info.log_open_mode,
                info.log_source_stamp_mode
            );
            // Qualified: inside this static member the free accessor is hidden by the non-static Session::log().
            DetourModKit::log().enable_async_mode(info.log);
        }
        catch (const std::bad_alloc &)
        {
            if (*instance_mutex != nullptr)
            {
                CloseHandle(*instance_mutex);
            }
            detail::lifecycle().clear_module();
            detail::lifecycle().mark_stopped();
            return std::unexpected(Error{ErrorCode::OutOfMemory, "Session::start"});
        }
        catch (...)
        {
            if (*instance_mutex != nullptr)
            {
                CloseHandle(*instance_mutex);
            }
            detail::lifecycle().clear_module();
            detail::lifecycle().mark_stopped();
            return std::unexpected(Error{ErrorCode::Unknown, "Session::start"});
        }

        // Setup succeeded. The session now owns the single-session slot and mutex handle until release().
#if !defined(_MSC_VER) && defined(_WIN64)
        detail::reopen_guarded_engine();
#endif
        detail::lifecycle().mark_running();
        return Session(*instance_mutex);
    }

    Logger &Session::log() const noexcept
    {
        // Qualified: the member Session::log() would otherwise hide the free accessor and recurse.
        return DetourModKit::log();
    }

    config::Ini Session::ini() const noexcept
    {
        return config::Ini{};
    }

    input::Input &Session::input() const noexcept
    {
        return input::Input::instance();
    }

    input::Scope &Session::scope() noexcept
    {
        return m_scope;
    }

    void Session::abandon() noexcept
    {
        // abandon() in session.hpp owns the process-termination-only rule. m_scope is a member whose own destructor
        // still runs after this Session, so abandon it explicitly. Scope::abandon retains the guard container, so
        // neither release logic nor consumer callback destruction can run during process detach.
        m_scope.abandon();
        m_active = false;
        m_instance_mutex = nullptr;
        detail::lifecycle().clear_module();
        detail::lifecycle().mark_stopped();
    }

    // Bootstrap free functions

    Result<void> bootstrap_attach(const ModInfo &info, BootstrapReadyFn on_ready) noexcept
    {
        return bootstrap_core(info, nullptr, on_ready);
    }

    Result<void> bootstrap(const ModInfo &info, std::move_only_function<Result<void>(Session &)> on_ready) noexcept
    {
        return bootstrap_core(info, &on_ready, nullptr);
    }

    void bootstrap_detach(void *reserved) noexcept
    {
        // This entry point is called only from DllMain. lpReserved distinguishes process termination from an explicit
        // unload. Publish that context even when a prior drain already retired the handles, so later CRT destructors
        // cannot inherit ExplicitDrain and treat a false heuristic result as permission to block under the loader lock.
        const detail::LoaderContext context =
            reserved != nullptr ? detail::LoaderContext::ProcessExit : detail::LoaderContext::LoaderDetach;
        detail::lifecycle().set_loader_context(context);

        if (context == detail::LoaderContext::ProcessExit)
        {
            const BootstrapState previous =
                s_bootstrap_state.exchange(BootstrapState::Detached, std::memory_order_acq_rel);
            if (previous == BootstrapState::Detached)
            {
                return;
            }

            // PROCESS TERMINATION (abandon). The OS has already killed the worker; its adopted Session lives in that
            // dead frame and is leaked untouched. If the worker never adopted the pending Session, leave it engaged in
            // the never-destroyed storage too. Neither path runs consumer destruction inside DllMain.
            if (s_pending_session)
            {
                s_pending_session->abandon();
            }
            detail::lifecycle().clear_worker_thread();
            if (s_worker_thread)
            {
                CloseHandle(s_worker_thread);
                s_worker_thread = nullptr;
            }
            // Process termination: the OS has already terminated every other thread before this DllMain notification,
            // so no request_shutdown() can be in flight and closing the event is safe.
            close_shutdown_event_at_process_exit();
            detail::lifecycle().clear_module();
            if (previous != BootstrapState::Drained)
            {
                diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::Bootstrap);
            }
            return;
        }

        BootstrapState expected = BootstrapState::Ready;
        if (!s_bootstrap_state.compare_exchange_strong(expected, BootstrapState::Detached, std::memory_order_acq_rel))
        {
            // A drained unload has no handles left. Only its terminal transition remains.
            if (expected == BootstrapState::Drained)
            {
                (void)s_bootstrap_state
                    .compare_exchange_strong(expected, BootstrapState::Detached, std::memory_order_acq_rel);
            }
            return;
        }

        // EXPLICIT FreeLibrary. Signal the worker, then stop admitting signalers and retain the event rather than
        // waiting for an already-admitted request_shutdown() call. The worker's counted module reference keeps its code
        // mapped until it exits; this path never waits or destroys callback state under the loader lock.
        signal_shutdown_event();
        if (abandon_shutdown_event())
        {
            diagnostics::record_intentional_leak(diagnostics::LeakSubsystem::Bootstrap);
        }
        // The published Detached state is terminal, so no drain, attach, or later detach can still read the worker's
        // thread handle. Closing it does not disturb the running worker and keeps a repeated load/unload cycle from
        // leaking one kernel thread object per load.
        if (s_worker_thread)
        {
            CloseHandle(s_worker_thread);
            s_worker_thread = nullptr;
        }
        detail::lifecycle().clear_module();
    }

    void request_shutdown() noexcept
    {
        // The access word admits this caller before it loads the handle. A clean drain closes the handle only after
        // closing admission and observing every admitted caller leave SetEvent.
        signal_shutdown_event();
    }

    Result<void> shutdown_and_wait() noexcept
    {
        // Refuse a self-drain before touching the state machine, so a worker-thread caller perturbs nothing and an
        // ordinary control thread can still drain afterwards. Waiting here would block on the calling thread's own
        // exit, which only that wait prevents.
        if (detail::lifecycle().is_worker_thread())
        {
            return std::unexpected(Error{ErrorCode::SessionShutdownWouldBlock, "shutdown_and_wait"});
        }

        BootstrapState expected = BootstrapState::Ready;
        if (!s_bootstrap_state.compare_exchange_strong(expected, BootstrapState::Draining, std::memory_order_acq_rel))
        {
            if (expected == BootstrapState::Drained)
            {
                return {};
            }
            if (expected == BootstrapState::Detached)
            {
                return std::unexpected(Error{ErrorCode::SessionShutdownUnavailable, "shutdown_and_wait"});
            }
            return std::unexpected(Error{ErrorCode::SessionShutdownInProgress, "shutdown_and_wait"});
        }

        // LoaderContext describes the phase, not the current thread's lock ownership.
        // Only the per-thread probe decides whether this caller can wait.
        if (detail::is_loader_lock_held())
        {
            s_bootstrap_state.store(BootstrapState::Ready, std::memory_order_release);
            return std::unexpected(Error{ErrorCode::SessionShutdownWouldBlock, "shutdown_and_wait"});
        }

        detail::lifecycle().set_loader_context(detail::LoaderContext::ExplicitDrain);
        request_shutdown();

        if (s_worker_thread != nullptr)
        {
            const DWORD wait_result = WaitForSingleObject(s_worker_thread, INFINITE);
            if (wait_result != WAIT_OBJECT_0)
            {
                const DWORD error = wait_result == WAIT_FAILED ? GetLastError() : ERROR_GEN_FAILURE;
                // The shutdown request is already latched, so the worker drains regardless of this failure; only the
                // slot is restored, for a caller that wants to retry the wait. Retire the drain phase with the drain
                // this caller no longer owns. The worker's own authorization comes from its identity, not this word.
                detail::lifecycle().set_loader_context(detail::LoaderContext::Normal);
                s_bootstrap_state.store(BootstrapState::Ready, std::memory_order_release);
                return std::unexpected(Error{ErrorCode::SystemCallFailed, "shutdown_and_wait", error});
            }
            CloseHandle(s_worker_thread);
            s_worker_thread = nullptr;
        }

        retire_bootstrap_after_drain();
        s_bootstrap_state.store(BootstrapState::Drained, std::memory_order_release);
        return {};
    }

    ModuleHandle module_handle() noexcept
    {
        return detail::lifecycle().module();
    }

#if defined(DMK_ENABLE_TEST_SEAMS)
    // Test-only accessor for the bootstrap shutdown event handle. A test captures it before a synchronous drain and
    // confirms the handle closes only after racing request_shutdown() callers have left SetEvent. Not declared in a
    // public header; the test extern-declares it like the loader-lock override seams.
    HANDLE bootstrap_shutdown_event_for_test() noexcept
    {
        return s_shutdown_event.load(std::memory_order_acquire);
    }

    // Arms or disarms the worker-launch failure. Set it around one bootstrap entry call only.
    void bootstrap_fail_worker_launch_for_test(bool fail) noexcept
    {
        s_fail_worker_launch.store(fail, std::memory_order_release);
    }

    void bootstrap_pre_setup_probe_for_test(void (*probe)() noexcept) noexcept
    {
        s_bootstrap_pre_setup_probe = probe;
    }

    // How many signals reached SetEvent on an already-invalidated handle. Monotonic across the process, so a case
    // brackets its own window with two reads.
    std::uint64_t bootstrap_signals_on_invalid_event_for_test() noexcept
    {
        return s_signal_on_invalid_event.load(std::memory_order_relaxed);
    }
#endif

    namespace
    {
        /**
         * @brief Runs both halves of the [B-74] transaction under one deadline.
         */
        template <typename DrainInput>
            requires std::is_nothrow_invocable_r_v<input::CallbackDrainStatus, DrainInput, std::chrono::milliseconds>
        [[nodiscard]] LogicDllUnloadStatus
        run_logic_dll_unload(std::chrono::milliseconds timeout, DrainInput drain_input) noexcept
        {
            if (!detail::blocking_teardown_permitted())
            {
                return LogicDllUnloadStatus::LoaderLock;
            }
            if (detail::current_thread_in_delivery())
            {
                return LogicDllUnloadStatus::SelfDelivery;
            }

            const auto deadline = detail::drain_deadline(timeout);
            const config::detail::ReloadDrainStatus begin_status = config::detail::begin_reload_drain();
            if (begin_status == config::detail::ReloadDrainStatus::SelfDelivery)
            {
                return LogicDllUnloadStatus::SelfDelivery;
            }
            if (begin_status == config::detail::ReloadDrainStatus::InProgress)
            {
                return LogicDllUnloadStatus::InProgress;
            }

            const auto now = std::chrono::steady_clock::now();
            const auto input_timeout = now < deadline
                                           ? std::chrono::duration_cast<std::chrono::milliseconds>(deadline - now)
                                           : std::chrono::milliseconds{0};
            const input::CallbackDrainStatus input_status = drain_input(input_timeout);

            const config::detail::ReloadDrainStatus config_status = config::detail::finish_reload_drain(deadline);
            LogicDllUnloadStatus status = LogicDllUnloadStatus::TimedOut;
            if (input_status == input::CallbackDrainStatus::SelfDelivery ||
                config_status == config::detail::ReloadDrainStatus::SelfDelivery)
            {
                status = LogicDllUnloadStatus::SelfDelivery;
            }
            else if (input_status == input::CallbackDrainStatus::InProgress ||
                     config_status == config::detail::ReloadDrainStatus::InProgress)
            {
                status = LogicDllUnloadStatus::InProgress;
            }
            else if (input_status == input::CallbackDrainStatus::RetireFailed)
            {
                status = LogicDllUnloadStatus::RetireFailed;
            }
            else if (input_status == input::CallbackDrainStatus::Drained &&
                     config_status == config::detail::ReloadDrainStatus::Ready)
            {
                if (detail::open_input_callback_admission())
                {
                    return LogicDllUnloadStatus::SafeToUnload;
                }
                status = LogicDllUnloadStatus::InProgress;
            }

            // The unresolved drain closes admission until a later transaction proves the old callbacks gone.
            detail::mark_input_callback_drain_pending();
            return status;
        }
    } // namespace

    LogicDllUnloadStatus prepare_logic_dll_unload(
        std::span<const std::string_view> binding_names,
        std::chrono::milliseconds timeout
    ) noexcept
    {
        return run_logic_dll_unload(
            timeout,
            [binding_names](std::chrono::milliseconds input_timeout) noexcept -> input::CallbackDrainStatus
            { return input::Input::instance().prepare_logic_dll_unload(binding_names, input_timeout); }
        );
    }

    LogicDllUnloadStatus prepare_logic_dll_unload_all(std::chrono::milliseconds timeout) noexcept
    {
        return run_logic_dll_unload(
            timeout,
            [](std::chrono::milliseconds input_timeout) noexcept -> input::CallbackDrainStatus
            { return input::Input::instance().prepare_logic_dll_unload_all(input_timeout); }
        );
    }

    void on_logic_dll_unload(std::span<const std::string_view> binding_names) noexcept
    {
        if (!detail::blocking_teardown_permitted())
        {
            detail::close_input_callback_admission();
            config::detail::disable_reloads_for_unload();
            return;
        }
        (void)prepare_logic_dll_unload(binding_names);
    }

    void on_logic_dll_unload_all() noexcept
    {
        if (!detail::blocking_teardown_permitted())
        {
            detail::close_input_callback_admission();
            config::detail::disable_reloads_for_unload();
            return;
        }
        (void)prepare_logic_dll_unload_all();
    }
} // namespace DetourModKit
