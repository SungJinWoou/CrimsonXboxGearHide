# Changelog

All notable changes to the CrimsonDesertEquipHide mod will be documented in this file.

## [0.10.2] - Fixed chest hiding for companions

- Fixed the chest staying visible on other characters when `CascadeFix` is on, because a chest hidden on one character blocked the hide on the rest
- Fixed `CascadeFix` freezing chest changes on NPCs that use the same part as a hidden protagonist chest
- INI auto-reload now retries in the background if it fails to start during game launch
- Fixed tools such as the pickaxe showing on the character's back while stowed and clipping with two-handed weapons. Disabled categories no longer change how the game shows their parts. With `Tools` enabled, remove `CD_Tool_Axe`, `CD_Tool_Hammer`, `CD_Tool_Broom`, `CD_Tool_FarmScythe`, `CD_Tool_Pickaxe` and `CD_Tool_Shovel` from existing INI files
- Pikes and the stowed two-handed scabbard now hide with `TwoHandWeapons`. Existing INI files need `CD_TwoHandWeapon_Pike` and `CD_TwoHandWeapon_Sword_IN` added to that section's `Parts`

## [0.10.1] - [Title for next release]

- New feature
- Bug fix
- Improvement

## [0.10.0] - Crimson Desert 2.04.00 support

- Updated the mod to work with Crimson Desert version 2.04.00
- Made the mod more tolerant of future game updates

## [0.9.1] - Crimson Desert 2.03.00 support

- Updated the mod to work with Crimson Desert version 2.03.00

## [0.9.0] - Crimson Desert 2.01.00 support and performance fixes

- Updated the mod to work with Crimson Desert version 2.01.00
- Fixed a performance drop that built up across loading screens, fast travel and zone changes
- Sped up the equipment name lookup the mod runs while loading
- Cut background scanning while the mod waits for late-loading equipment parts

## [0.8.7] - Crimson Desert 1.18.00 support

- Updated the mod to work with Crimson Desert version 1.18.00

## [0.8.6] - Fixed broken weapon attachment

- Fixed drawn weapons ending up attached incorrectly after hiding armor
- Thanks to [Rubsi](https://www.nexusmods.com/profile/Rubsi) for reporting and fixing this

## [0.8.5] - Crimson Desert 1.16.00 support

- Updated the mod to work with Crimson Desert version 1.16.00

## [0.8.4] - Crimson Desert 1.13.00 support

- Updated the mod to work with Crimson Desert version 1.13.00
- The chest/legs flickering when hiding the chest is resolved on game version 1.13.00; the CascadeFix option works again

## [0.8.3] - Stability and framework update

- Updated the underlying framework (DetourModKit) to 3.9.0 for better stability and future compatibility
- More resilient to future game updates: some internal addresses now self-correct after a patch
- Added an advanced INI setting (SelfHealWindow) to help the mod recover after a game update
- Standardised the source-code formatting and added automatic style enforcement for future development
- Tidied developer comments and documentation for consistency, with no change to in-game behaviour

## [0.8.2] - Crimson Desert 1.10.00 support

- Updated the mod to work with Crimson Desert version 1.10.00.
- Fixed hidden gear not following the character you control after the game update.
- Oongka now hides the same one-handed weapons and tools as Kliff by default.
- Hardened the mod under the hood for better stability and resilience to game updates.
- Updated the mod's underlying framework (DetourModKit) to v3.4.0 for better stability and future compatibility.

## [0.8.1] - Maintenance and reliability

- Upgraded DetourModKit dependency from v3.2.3 to v3.3.0.
- More resilient internal checks against the game's loaded modules.
- Fixed companions' hidden equipment sometimes not applying in crowded areas.
- Demoted some verbose logs.

## [0.8.0] - Sturdier save-load detection

- Per-character hide rules stay correct immediately after a save-load instead of needing a short settle window.
- The active protagonist is detected purely from in-game data, so loading EquipHide alongside other tools is one step lighter.
- All three protagonists are tracked from frame zero without needing the user to cycle to each one first.
- Fixed cases where part hide rules silently failed to take effect when the mod started while still on the main menu.
- A single typo in the Parts list no longer blocks every other entry from taking effect.
- Compatibility fix for Crimson Desert game version 1.08.00

## [0.7.3] - Save-load and radial swap reliability

- More reliable per-character hide rules on save-load and radial swap; the active protagonist's Parts list is picked up from the engine's own focus broadcast instead of needing a chain walk to settle.

## [0.7.2] - v1.06.00 patch support

- Compatibility fix for Crimson Desert game version 1.06.00. Restored radial-character swap detection so equipment hiding stays correct after switching characters.

## [0.7.1] - v1.05.00 atomic save-load fix

- Fixed cases where loading a save while the mod was active could break the hide toggle until the game was restarted.

## [0.7.0] - v1.05.00 patch support + multi-protagonist fixes

- NPCs are no longer accidentally stripped by the protagonist hide settings.
- Per-character hide masks now apply correctly to each visible protagonist (after one radial-cycle through all three).
- Fixed coexistence with Live Transmog: both mods can now be loaded together without breaking radial-menu tracking.
- Updated for game version 1.05.00: armor hide bindings now toggle visibility correctly on the latest patch.
- Body armor categories no longer remain visually hidden after toggling them back on.
- Restored radial character-swap detection on game version 1.05.00.
- Removed the `ForceShow` INI option; visible parts are now force-shown unconditionally so toggling back to visible works without configuration.

## [0.6.3] - [Title for next release]

- Fix: equipment hiding no longer occasionally bleeds onto NPCs after a
  save load or character swap.
- Removed the `PlayerOnly` setting; hiding is now always limited to the
  playable cast. Existing INIs with the entry can leave it in place; it
  is simply ignored.

## [0.6.2] - Multi-Protagonist Support and 1.04.00 Reliability

- Per-character armor-hide settings now stick when you swap protagonists; hiding gear on one party member no longer flips back when you switch to another.
- Per-character Parts overrides are now honoured by the live mid-hook (not just the resync pass), so a hash excluded from one protagonist's `[Section:CharName]` list will no longer be momentarily hidden on that protagonist's frames.
- INI template now lists the exact `CD_*` part names alongside each per-character override comment, so users can copy-paste names without guessing what "R-daggers" or "fire can" map to.
- Detect all three party members on game version 1.04.00 (the third character was previously missing the per-character hide mask).
- Toggle hotkeys reliably apply right after a character swap; presses are no longer silently dropped on internal lock contention.
- Equipment hash table now retries until your world finishes loading, so worlds with extremely sparse table state at startup still converge to the full hide list.
- Hot-reload during development no longer hangs the game on shutdown.
- Quieter logs: per-binding registration and per-part trace lines moved off the default INFO/DEBUG output.
- Migrated to DetourModKit 3.2.3 lifecycle helpers; existing INI files keep working unchanged.
- INI auto-reload (default on) -- most edits to category Enabled/DefaultHidden/Parts/per-character overrides take effect within a single frame, no relaunch required. Disable via `[General] AutoReloadConfig=false`.
- Categories sharing the same `ToggleHotkey` now flip independently (each on its own state). Bind the same combo to `[General] HideAll`/`ShowAll` for a synchronised toggle.
- Cleaner shutdown: full DetourModKit teardown removes every hook and restores patched bytes, so dev hot-reload starts each cycle from a clean state.

## [0.6.1] - [Title for next release]

- Compatibility update for Crimson Desert v1.04.00
- Fix crash on world load: PostfixEval AOB resolved to a mid-instruction address on v1.04.00, causing the trampoline to run a truncated register save and corrupt rbp. Added explicit prologue candidates for both v1.03.01 and v1.04.00 (full-function anchors) and recalibrated the body-only fallback offset
- Fix per-character Parts overrides on v1.04.00: the actor slot-index byte moved from +0x60 to +0x50 (+0x60 is no longer a discriminator). Companion diff table ({Damiane=1, Oongka=2}) unchanged
- Add resolver poll thread: drives `resolve_player_vis_ctrls` on a 1s cadence so cold load and in-session character swaps are detected without relying on the EquipVisCheck hook firing
- Add cold-load safety net in the EquipVisCheck hook: if the body list is still empty when the hook fires, run the resolve pass inline once so DefaultHidden categories apply on first visibility decision
- Add INFO logs on UserActor swap and in-session controlled-actor swap (makes save-load and swap transitions visible in the log)
- Known issue: leg/pants flashes during movement while chest is hidden on v1.04.00. `CascadeFix` relies on EquipVisCheck firing at v1.03.01 rates; on v1.04.00 the hook's event set is narrower. Deferred to a future update

## [0.6.0] - Multi-Character Support

- Shared AOB scanning utilities moved into the new `CrimsonDesertCore` static library. No behavioural change ([#33](https://github.com/tkhquang/CrimsonDesertTools/pull/33))
- Minor post-extraction cleanups in `aob_resolver`, `armor_injection`, `bald_fix`, `equip_hide`, `player_detection`, and `visibility_write`. No user-visible change ([#34](https://github.com/tkhquang/CrimsonDesertTools/pull/34))
- Per-character Parts overrides. Every category section now accepts `[Section:Kliff]`, `[Section:Damiane]`, and `[Section:Oongka]` subsections; the mod picks the active character's list automatically on in-game swap. Missing subsection inherits from the base `[Section]` list. Use `Parts = NONE` to disable a category for a specific character without affecting the others
- Bald Fix now works for Kliff, Damiane, and Oongka
- Fixed: swapping between characters no longer leaves the previous character's hide state stuck on the new character's body (e.g. hiding Oongka's chest parts and then swapping to Kliff no longer leaves Kliff bare-chested)
- Per-character detection is now robust across saves regardless of party composition

## [0.5.2] - Game v1.03.01 Support

- Added support for Crimson Desert v1.03.01 (the mod still works on v1.02.00)
- Fixed equipment not hiding after the game update
- Improved diagnostic logging for easier troubleshooting

## [0.5.1] - Upgrade to DetourModKit v3.0.0

### Internal

- Upgraded DetourModKit dependency from v2.2.0 to v3.0.0 (std::expected API, typed hook errors, AVX2 scanner, deterministic shutdown)
- Bumped CMake minimum to 3.25; added SYSTEM subdirectory to suppress dependency header warnings
- Fixed [[nodiscard]] violation on memory cache initialization
- Fixed linker warning (LNK4075) from INCREMENTAL/ICF conflict in dev builds
- Reduced amour flashing issues when CascadeFix is on

## [0.5.0] - BaldFix Rework & CascadeFix

- Added `CascadeFix` option (disabled by default, experimental): reduces pants flickering when hiding chest armor, allowing bare-chested gameplay without visual glitches. Some armor (e.g. Bandit Cloth) may show invisible torso or missing upper body parts when hiding chest with legs visible. Reloading a save may briefly show armor during loading.
- BaldFix reworked: now uses a per-call priority bitmask override instead of permanent state changes, hair-hiding rules are suppressed only for the player context when Helm, Cloak, or Mask is hidden, eliminating NPC hair clipping entirely
- Improved performance when toggling equipment visibility
- Reorganized internal code for easier maintenance and future updates
- Adopted newer DetourModKit APIs for faster and more reliable pattern scanning

## [0.4.0] - Runtime Hash Resolution & Bug Fixes

### Bug Fixes
- Fixed face/eye mesh disappearing when hiding necklace, rings, or other accessories
- Fixed helmet and mask not hiding/showing correctly when toggled via hotkey
- Fixed equipment on wrong character parts being hidden after game updates

### Improvements
- Equipment hashes are now fully resolved at runtime - no more hardcoded values that break across game patches
- Faster and more reliable hash scanning with smart retry logic
- Cleaner log output - removed excessive warnings during normal operation
- Init message now accurately reflects mod readiness state

### Technical
- Removed all compile-time fallback hashes; part map is purely runtime-resolved
- Widened IndexedStringA scan range for better coverage across game versions
- Deferred scan thread uses adaptive intervals and never exhausts
- Vis byte cleanup after hash rebuild prevents orphaned hidden parts
- Armor injection flags reset on toggle for correct re-injection

## [0.3.1] - Performance & Stability Improvements

### Fixed

- Reduced micro-stuttering caused by frequent memory safety checks in the hot path
- Fixed game thread stalling when pressing hotkeys during heavy scenes
- Fixed equipment parts not updating after editing the INI and hot-reloading (dev builds)
- Fixed shutdown corrupting visibility state of unrelated equipment parts
- Fixed repeated log entries for already-resolved parts during startup scan

### Changed

- Removed flight cloak parts (CD_Cloak_Flight) from default Cloak category to prevent visual artifacts and squished hair when toggling cloak visibility
- Unified address format in log output to uppercase hex
- Added per-part trace logging when toggling visibility (visible at Trace log level)
- Added category summary after config load (visible at Trace log level)

### Added

- Expanded user presets from 3 to 10 slots
- Added workaround tip in INI for dagger clipping issue
- Documented known issues: flight cloak artifacts, chest/legs flickering, dagger clipping

## [0.3.0] - Full gear hider with armor, accessories, and user presets

### Added

- Armor hiding � 9 new categories: Helm, Chest, Legs, Gloves, Boots, Cloak, Shoulder, Mask, Glasses
- Accessory hiding � 4 new categories: Earrings, Rings, Necklace, Bags (belt/bag parts)
- User Presets � 3 custom part groups (UserPreset1�3) with independent visibility control; presets take priority over built-in categories when enabled
- [Experimental] BaldFix � runtime hair-visibility fix when helmet or cloak is hidden; hooks the postfix rule evaluator to suppress hair-hiding rules (`_a`, `_c`, `_d`, `_f`, `_i`, `_q`, `_v`) without PAZ patching; enabled by default via `BaldFix = true` in `[General]`. Hair/beard may occasionally disappear; re-toggling the helmet (show then hide) restores it
- Gliding flash fix � inline hook on PartAddShow prevents shield/equipment from briefly flashing visible when exiting glide; controllable via `GlidingFix = true/false` in `[General]`
- Hot-reload cleanup � visibility bytes are restored to original values on DLL unload
- ForceShow fix � vis byte restore now works correctly even with `ForceShow = false`

### Improved

- Flat lookup table and classification bitset for O(1) part lookups
- Primary player cache to reduce per-frame pointer chain walks
- Default config ships with only Shields, Helm, and Mask enabled (`DefaultHidden = true`, `ToggleHotkey = V`)

### Changed

- Renamed from "Weapon Hider" to "Gear Hider" to reflect expanded scope (20 built-in categories + 3 user presets = 23 total)
- Updated DetourModKit to latest version

## [0.2.3] - Thread safety and hot-path performance improvements

### Fixed

- Fix potential permanent mutex deadlock in `apply_direct_vis_write` on SEH unwind � switched to manual `try_lock`/`unlock`
- Fix TOCTOU race on player slot caching in d8 fallback path � use `compare_exchange_weak`
- Fix hotkey toggle causing `apply_direct_vis_write` to run on every subsequent hook call indefinitely
- Fix silent `catch(...)` swallowing malformed hex IDs in INI parsing � now logs a warning

### Improved

- Avoid `lock xchg` (~25 cycles) on every hook call via load-before-exchange on `s_needsDirectWrite`
- Background threads now exit cleanly on DLL unload via `s_shutdownRequested` flag

### Added

- CMakePresets.json (msvc-release, mingw-release, msvc-dev, mingw-dev)
- Dev build two-DLL hot-reload infrastructure (loader stub + logic DLL)

## [0.2.2] - Runtime hash resolution for patch-proof equipment detection

### Added

- Runtime IndexedStringA table scan at init � part name-to-hash resolution is now automatic, eliminating the need to manually update hardcoded hash IDs after each game patch
- Targeted outlier probe for parts with non-deterministic hash slots (e.g. CD_Tool_Book), searching a �0x100 window around fallback hashes
- Dynamic range filter with automatic outlier detection � contiguous hash block bounds and outlier set are computed from resolved hashes at startup
- Background thread for deferred table scan with retry logic � avoids blocking the game thread during loading

### Improved

- Replaced per-entry is_readable (VirtualQuery) calls with SEH exception handling in the table scanner � scan time reduced from 300-900ms to <1ms
- Thread-safe double-buffered part lookup map � eliminates data race between background scan thread and hook callback

### Fixed

- Fix equipment hide not working on game v1.01.00 � the patch inserted ~60 new entries into the IndexedStringA table, shifting all 98 equipment part hash IDs
- Fix DefaultHidden intermittently not applying on cold boot � added 60-second startup direct-write enforcement that proactively writes visibility bytes after init, covering the race where the game processes initial equipment visibility before the hook is installed or the PlayerOnly filter has transitional pointer data
- Direct-write visibility updates now work in d8-based fallback mode, improving hotkey responsiveness when the global pointer chain is unavailable
- Fix toggling a category to visible forcing all its parts to always-show (vis=0) � the direct-write path now caches each part's original vis byte before overriding and restores it on un-hide, preserving the game's per-part-type render routing (vis=0 for shields rendered through the PartInOut path, vis=3 for weapons rendered by the animation system). This fixes daggers/knives becoming permanently visible after any hide/show toggle cycle

## [0.2.1] - Fixed equipment hash IDs for game v1.01.00

- Fix equipment hide not working on game v1.01.00 � the patch inserted ~60 new entries (bags, accessories) into the IndexedStringA table, shifting all 98 equipment part hash IDs upward and causing most categories (1H weapons, shields, bows, special weapons, lanterns) to fail silently while tools and 2H weapons appeared to work by coincidence
- Update range filter bounds from

## [0.2.0] - Player-Only Mode, Show/Hide Hotkeys, and Reliable Hook Init

### Added
- Player-only filtering mode that restricts equipment hiding to player characters using a global pointer chain with d8-based fallback
- Per-category ShowHotkey / HideHotkey bindings alongside existing toggle
- Global ShowAllHotkey / HideAllHotkey overrides for one-press show/hide
- Direct-write visibility updates via map lookup for immediate visual feedback on hotkey press
- Complete equipment part registry covering all known part hashes, removing hardcoded defaults
- Process-wide executable memory scan (VirtualQuery over all PAGE_EXECUTE_READ regions) to find hook targets in VirtualAlloc'd code outside the main module
- Per-process named mutex to detect duplicate ASI instances
- SyncFallback async logger overflow policy to prevent message drops
- Fail-fast when hook installation fails (no hotkeys, no input thread)
- Centralized constants into constants.hpp

### Fixed
- Suppress spurious empty-parts warning during config registration
- Hook init no longer relies on SizeOfImage polling or module-only AOB scan, which failed because the game's protector unpacks code into regions outside the 0.6 MB main module stub
- Gate on process name before logger init to prevent crashpad_handler and other non-game processes from truncating the log file

### Changed
- Upgraded DetourModKit to v2.1.1
- Removed redundant InitDelayMs config and retry loop

### Docs
- Updated installation docs with ASI loader instructions

## [0.1.0] - Initial Release

- Hide equipped weapons, shields, bows, tools, and lanterns with a configurable hotkey
- Per-category toggle with independent hotkey bindings
- Cascading AOB pattern scanning for resilience across game updates
- SEH-protected hook callback to prevent crashes if mod is outdated
- Full keyboard, mouse, and gamepad (XInput) hotkey support with modifier combos
- Customizable part lists per category via INI configuration
- Configurable init delay and log level

[0.10.2]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.10.2
[0.10.1]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.10.1
[0.10.0]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.10.0
[0.9.1]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.9.1
[0.9.0]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.9.0
[0.8.7]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.8.7
[0.8.6]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.8.6
[0.8.5]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.8.5
[0.8.4]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.8.4
[0.8.3]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.8.3
[0.8.2]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.8.2
[0.8.1]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.8.1
[0.8.0]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.8.0
[0.7.3]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.7.3
[0.7.2]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.7.2
[0.7.1]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.7.1
[0.7.0]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.7.0
[0.6.3]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.6.3
[0.6.2]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.6.2
[0.6.1]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.6.1
[0.6.0]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.6.0
[0.5.2]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.5.2
[0.5.1]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.5.1
[0.5.0]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.5.0
[0.4.0]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.4.0
[0.3.1]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.3.1
[0.3.0]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.3.0
[0.2.3]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.2.3
[0.2.2]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.2.2
[0.2.1]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.2.1
[0.2.0]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.2.0
[0.1.0]: https://github.com/tkhquang/CrimsonDesertTools/releases/tag/equip-hide/v0.1.0
