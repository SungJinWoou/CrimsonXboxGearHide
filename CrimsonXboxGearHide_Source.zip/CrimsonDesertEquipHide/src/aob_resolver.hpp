#ifndef EQUIPHIDE_AOB_RESOLVER_HPP
#define EQUIPHIDE_AOB_RESOLVER_HPP

/**
 * @file aob_resolver.hpp
 * @brief EquipHide-local AOB candidate ladders plus the declarative anchor registry for the mod.
 *
 * The roles both mods share live in cdcore/anchors.hpp. Only the EquipHide-only roles are declared here. Every
 * table, shared or local, enters the registry below as the `site` of an AnchorKind::RipGlobal entry, and
 * resolve_all_anchors() resolves the whole table in one parallel pass at startup. anchor_address() then hands each
 * resolved address, or 0 on a ladder miss, to the call sites.
 *
 * A mid-body hook site is a Direct row whose `|` result marker sits on the exact instruction the hook must mid-hook,
 * so the hook offset is part of the matched bytes instead of a count kept by hand next to them.
 *
 * Naming convention (unified across both mods):
 *   <RoleName>_P<N>_<AnchorDescriptor>
 * See cdcore/anchors.hpp for the full convention and authoring rules.
 */

#include <cdcore/anchors.hpp>

#include <DetourModKit/anchor.hpp>

#include <cstdint>
#include <span>
#include <string_view>

namespace EquipHide
{
    using CDCore::anchors::Candidate;
    using CDCore::anchors::Pattern;

    /**
     * @brief ChildActor (pa::ClientChildOnlyInGameActor) vtable.
     * @details Resolves by RTTI mangled name first (patch-stable, self-healing), with two nearby RIP-relative byte
     *          loads as fallback. Each byte candidate resolves to the `lea rax, [rip+disp32]` that loads the vtable
     *          base. That base is also the primary (COL.offset == 0) vtable that the RTTI backend returns for the
     *          class, so every tier resolves the same pointer.
     * @note A 3-row ladder resolving the vtable address (data in .rdata, not code).
     */
    inline const Candidate CHILD_ACTOR_VTBL_CANDIDATES[] = {

        // Branch-encoding caveat (aob-signatures.md, the short Jcc rel8 rule): neither byte row crosses a branch whose
        // encoding it pins. P1 stops at the vtable store, ahead of the jmp-over-fallback that follows it, and P2
        // carries its preceding jz in a `[2-6]` bounded gap, so it admits the rel8 and the rel32 form alike.

        // Primary - resolve the vtable by its RTTI mangled name. The AllocCtor stores ClientChildOnlyInGameActor's
        // primary vtable into the new object, so the RTTI backend yields the exact pointer the byte tiers below
        // recover. The mangled name is patch-stable, so this tier self-heals across the vtable relocations and
        // jmp-encoding flips the byte anchors are sensitive to. require_unique does not apply: the RTTI backend is
        // unique-only and fails closed on an ambiguous name, so the ladder falls through to the byte tiers.
        Candidate::rtti_vtable("ChildActorVtbl_RTTI", ".?AVClientChildOnlyInGameActor@pa@@"),

        // P1 - truncated: ends at the `mov [rsi], rax` that stores the vtable. It does not cross the trailing `EB 03`
        // jmp, so it survives a jmp-encoding flip.
        //
        // 48 8B 55 ??            mov rdx, [rbp+d8]
        // 48 89 F1               mov rcx, rsi
        // E8 ?? ?? ?? ??         call <rel32>
        // 90                     nop
        // 48 8D 05 ?? ?? ?? ??   lea rax, [rip+d32]   <- result offset
        // 48 89 06               mov [rsi], rax
        Candidate::rip_relative(
            "ChildActorVtbl_P1_AllocCtor",
            Pattern::literal("48 8B 55 ?? 48 89 F1 E8 ?? ?? ?? ?? 90 | 48 8D 05 ?? ?? ?? ?? 48 89 06"),
            3,
            7
        ),

        // P2 - the jz ahead of the ctor call sits in a `[2-6]` bounded gap, so the row matches the 2-byte `74 rel8`
        // and the 6-byte `0F 84 rel32` form alike. The resolver adds the actual gap width at match time, so the `|`
        // marker still lands on the lea. The trailing `?? ?? ?? ??` is the lea's own disp32: the RipRelative tier
        // decode-verifies the instruction at the marker, so the matched suffix has to span the displacement it
        // authorizes.
        //
        // 45 31 ED               xor r13d, r13d
        // 48 85 F6               test rsi, rsi
        // [2-6]                  je <rel8 or rel32>
        // 48 8B 55 ??            mov rdx, [rbp+d8]
        // 48 89 F1               mov rcx, rsi
        // E8 ?? ?? ?? ??         call <rel32>
        // 90                     nop
        // 48 8D 05 ?? ?? ?? ??   lea rax, [rip+d32]   <- result offset
        Candidate::rip_relative(
            "ChildActorVtbl_P2_WiderCtorStore",
            Pattern::literal("45 31 ED 48 85 F6 [2-6] 48 8B 55 ?? 48 89 F1 E8 ?? ?? ?? ?? 90 | 48 8D 05 ?? ?? ?? ??"),
            3,
            7
        ),
    };

    /**
     * @brief IndexedStringA map insert routine, the companion to CDCore::anchors::map_lookup().
     * @details Map layout every row depends on: bucket modulus at +0, live count at +4, capacity at +8, bucket array
     *          at +0x10 (256-byte buckets, index `(key % modulus) << 8`), entry-pointer array at +0x18.
     * @warning Do NOT anchor a row on the bucket arithmetic alone. This hash map is heavily templated. The
     *          `div modulus / shl 8 / add [map+0x10]` probe matches hundreds of sites in the image, and the
     *          `inc [map+4]` plus `[map+0x18]` write-back pair matches as many. What singles out THIS instantiation
     *          is its argument shuffle, four arguments parked in a specific order, PLUS the width of the key compare.
     * @warning The argument shuffle alone is not enough. The image carries a twin instantiation with the identical
     *          prologue and shuffle whose key compare is 16-bit (`movzx ecx,word [rax] / cmp word [rbx+4],cx`). The
     *          part-hash map compares a full u32 (`mov ecx,[rax] / cmp dword [rbx+4],ecx`), so every row runs on
     *          into that compare. Calling the u16 twin would insert with a truncated key.
     * @note A 3-tier ladder resolving the function entry.
     */
    inline const Candidate MAP_INSERT_CANDIDATES[] = {

        // P1 - full prologue through the argument shuffle, then a bounded gap over the empty-map early-out and the
        // bucket probe, closed by the u32 key compare. The row wildcards the stack-allocation imm8 because the
        // compiler sizes the frame. The match lands on the function start.
        //
        // The window opens with the empty-map test folded into the modulus read (`cmp dword [rcx],0`) and runs through
        // the r9/r8d/rdx/rcx parking. The parking ORDER is the identifier. The map pointer's own register is not.
        //
        // 40 53         push rbx
        // 56            push rsi
        // 57            push rdi
        // 41 54         push r12
        // 41 55         push r13
        // 48 83 EC ??   sub rsp, imm8
        // 83 39 00      cmp dword [rcx], 0x0
        // 4D 8B E1      mov r12, r9
        // 41 8B F0      mov esi, r8d
        // 4C 8B EA      mov r13, rdx
        // 48 8B F9      mov rdi, rcx
        // [60-90]       empty-map early-out, bucket probe, entry fetch
        // 49 8B 45 00   mov rax, [r13]
        // 8B 08         mov ecx, [rax]          ; u32 key
        // 39 4B 04      cmp [rbx+0x4], ecx
        Candidate::direct(
            "MapInsert_P1_FullPrologue",
            Pattern::literal(
                "40 53 56 57 41 54 41 55 48 83 EC ?? 83 39 00 4D 8B E1 41 8B F0 4C 8B EA 48 8B F9 [60-90] "
                "49 8B 45 00 8B 08 39 4B 04"
            )
        ),

        // P2 - argument shuffle, with no prologue head at all, then the u32 key compare. Independent of the
        // register-save set, which is the part of the prologue that moves most. Walk back 0x0C bytes to the function
        // start.
        //
        // 83 39 00   cmp dword [rcx], 0x0
        // 4D 8B E1   mov r12, r9
        // 41 8B F0   mov esi, r8d
        // 4C 8B EA   mov r13, rdx
        // 48 8B F9   mov rdi, rcx
        // [60-90]    empty-map early-out, bucket probe, entry fetch, key-pointer load
        // 8B 08      mov ecx, [rax]          ; u32 key
        // 39 4B 04   cmp [rbx+0x4], ecx
        Candidate::direct(
            "MapInsert_P2_ArgShuffleBody",
            Pattern::literal("83 39 00 4D 8B E1 41 8B F0 4C 8B EA 48 8B F9 [60-90] 8B 08 39 4B 04"),
            -0x0C
        ),

        // P3 - past the shuffle and past the empty-map early-out, opening on the re-read of the modulus and the
        // bucket-array lea that the probe loop runs on, then the u32 key compare. The row wildcards the mid-function
        // callee-saved spill slot.
        //
        // This row shares no PATTERN bytes with the argument shuffle, so a rewrite of those bytes cannot take all
        // three down. It is not independent of the entry block, though. The -0x1D walk-back spans that block and the
        // empty-map jcc. An added instruction there, or a jcc widened from rel8 to rel32, still matches the pattern
        // but resolves the row SHORT. Re-measure it whenever the entry block changes.
        //
        // 41 8B D0         mov edx, r8d
        // E8 ?? ?? ?? ??   call <rel32>
        // 44 8B 17         mov r10d, [rdi]
        // 4C 89 74 24 ??   mov [rsp+d8], r14
        // 4C 8D 77 10      lea r14, [rdi+0x10]
        // 45 85 D2         test r10d, r10d
        // [40-70]          bucket probe and entry fetch
        // 49 8B 45 00      mov rax, [r13]
        // 8B 08            mov ecx, [rax]          ; u32 key
        // 39 4B 04         cmp [rbx+0x4], ecx
        Candidate::direct(
            "MapInsert_P3_BucketArrayLea",
            Pattern::literal(
                "41 8B D0 E8 ?? ?? ?? ?? 44 8B 17 4C 89 74 24 ?? 4C 8D 77 10 45 85 D2 [40-70] "
                "49 8B 45 00 8B 08 39 4B 04"
            ),
            -0x1D
        ),
    };

    /**
     * @brief EquipVisCheck: the equipment-visibility decision the PartInOut transition runs per part.
     *
     * @details The decision is a leaf function of its own:
     *            float check(a1, const uint32_t *part_hash, PartInOut *pio, uint8_t inOut)
     *          It returns the alpha the caller then publishes: 1.0f show, 0.0f hide, -1.0f "no opinion", which the
     *          caller tests with `vcomiss xmm0,0 / jb` and skips the publish for. Every input arrives in a register;
     *          the function allocates no frame of its own.
     *
     *          Hook point: `movzx r11d, byte ptr [r8+0x20]`, the first instruction after the single
     *          `mov [rsp+8],rbx` spill, plus the `cmp r11b, 3` that follows the `mov rbx,rcx` context move.
     *
     *          Register layout at the hook point:
     *            RCX = the a1 visibility-control context, which the caller loads from its own frame slot and passes
     *                  in. It owns the exclusion array at a1+0x78 and its count at a1+0x80, with a 0x10-byte entry
     *                  stride.
     *            RDX = pointer to the part-hash DWORD. The exclusion walk dereferences it as `mov ecx,[rdx]` before
     *                  comparing against each entry's first DWORD. A register the walk does not dereference is the
     *                  wrong one. Verify against the disassembly, do not assume.
     *            R8  = the PartInOut struct. The hooked movzx reads its visibility byte at +0x20, and the branch
     *                  after the exclusion walk reads its transition byte at +3.
     *            R9B = the In/Out selector the caller passes: 0 = In, 1 = Out. The engine consumes it at
     *                  `test r9b,r9b`, `cmp r9b,1` and `cmp r9b,r11b`. Writing the visibility byte alone does not
     *                  decide the outcome: visibility 2 hides only on the In pass (R9B = 0), visibility 1 only on the
     *                  Out pass.
     *            RBX, R10, R11 are scratch and hold nothing useful before the hooked instruction retires.
     *
     * @warning Do NOT write R8 to steer the decision: it carries the struct pointer, so a write replaces a live
     *          pointer with a small integer that the engine then dereferences. R9B is the only input that steers the
     *          outcome. See on_vis_check_impl in equip_hide.cpp.
     * @warning The compiler is free to inline this body back into its caller. If it does, the rows stop matching and
     *          the anchors have to move to the caller's frame, where the caller spills the same four values to fixed
     *          slots.
     *          That is a re-derivation, not a displacement fix: do not try to patch the offsets through it.
     * @note Ladder contract: each candidate must match exactly once in the scanned scope. A wide shape can still match
     *       once while its walk-back lands mid-instruction after a body shift. Verify the match count and the
     *       match-to-hook displacement together for each added candidate.
     * @note A 3-tier ladder resolving the mid-hook instruction.
     */
    inline const Candidate EQUIP_VIS_CHECK_CANDIDATES[] = {

        // P1 - the whole entry block: the single rbx spill, the visibility read, the context move, the sentinel
        // compare, its branch, and the exclusion-array header. No frame arithmetic sits inside the window because this
        // function allocates no frame, so nothing here moves when the compiler resizes a caller. The row wildcards
        // the visibility field offset and carries the sentinel branch in a `[2-6]` bounded gap, so the 2-byte
        // `74 rel8` and the 6-byte `0F 84 rel32` encodings both match. The exclusion offsets are engine layout and
        // stay literal. The `|` marker puts the result on the movzx, so the hook offset is part of the matched bytes
        // instead of a walk counted next to them.
        //
        // 48 89 5C 24 08         mov [rsp+0x8], rbx
        // 45 0F B6 58 ??         movzx r11d, byte [r8+d8]   <- result marker
        // 48 8B D9               mov rbx, rcx
        // 41 80 FB 03            cmp r11b, 0x3
        // [2-6]                  je <rel8 or rel32>
        // 48 8B 41 78            mov rax, [rcx+0x78]
        // 44 8B 91 80 00 00 00   mov r10d, [rcx+0x80]
        Candidate::direct(
            "EquipVisCheck_P1_EntrySpillToExclusionHeader",
            Pattern::literal(
                "48 89 5C 24 08 | 45 0F B6 58 ?? 48 8B D9 41 80 FB 03 [2-6] 48 8B 41 78 44 8B 91 80 00 00 00"
            )
        ),

        // P2 - the same window without the prologue spill, so a change to the register the entry saves (or a move to
        // a push) cannot take this row down with P1. The match lands directly on the movzx, walk-back 0. It pins the
        // 6-byte `0F 84 rel32` branch on purpose: P1 and P3 admit either width through their gaps, and one row with
        // the literal width keeps the three rows from sharing a single failure mode.
        //
        // 45 0F B6 58 ??         movzx r11d, byte [r8+d8]
        // 48 8B D9               mov rbx, rcx
        // 41 80 FB 03            cmp r11b, 0x3
        // 0F 84 ?? ?? ?? ??      je <rel32>
        // 48 8B 41 78            mov rax, [rcx+0x78]
        // 44 8B 91 80 00 00 00   mov r10d, [rcx+0x80]
        // 49 C1 E2 04            shl r10, 0x4
        Candidate::direct(
            "EquipVisCheck_P2_VisReadToExclusionHeader",
            Pattern::literal(
                "45 0F B6 58 ?? 48 8B D9 41 80 FB 03 0F 84 ?? ?? ?? ?? 48 8B 41 78 44 8B 91 80 00 00 00 49 C1 E2 04"
            )
        ),

        // P3 - the visibility read through the exclusion walk: array base at a1+0x78, count at a1+0x80, the
        // 0x10-byte stride shift, the end-pointer form, the empty-list test, and the first key compare through the
        // hash pointer. Both branches sit in `[2-6]` bounded gaps, so neither a widened sentinel branch nor a widened
        // empty-list branch takes the row down, and the match lands on the movzx itself: no negative walk-back spans a
        // variable-width instruction. The head is kept on purpose. The mid-hook reads R8 as the PartInOut pointer
        // and RCX as the context at this instruction, so a row that matched the walk without the head could resolve
        // a re-registered body whose register contract no longer holds. A rewrite of the head is a re-derivation of
        // the hook, and it must fail loudly here. Order it last.
        //
        // 45 0F B6 58 ??         movzx r11d, byte [r8+d8]
        // 48 8B D9               mov rbx, rcx
        // 41 80 FB 03            cmp r11b, 0x3
        // [2-6]                  je <rel8 or rel32>
        // 48 8B 41 78            mov rax, [rcx+0x78]
        // 44 8B 91 80 00 00 00   mov r10d, [rcx+0x80]
        // 49 C1 E2 04            shl r10, 0x4
        // 4C 03 D0               add r10, rax
        // 49 3B C2               cmp rax, r10
        // [2-6]                  je <rel8 or rel32>
        // 8B 0A                  mov ecx, [rdx]
        // 39 08                  cmp [rax], ecx
        Candidate::direct(
            "EquipVisCheck_P3_VisReadThroughExclusionWalk",
            Pattern::literal(
                "45 0F B6 58 ?? 48 8B D9 41 80 FB 03 [2-6] 48 8B 41 78 44 8B 91 80 00 00 00 49 C1 E2 04 4C 03 D0 "
                "49 3B C2 [2-6] 8B 0A 39 08"
            )
        ),
    };

    /**
     * @brief PostfixEval: the postfix rule evaluator.
     * @details Evaluates whether a postfix rule matches the currently equipped items. Returns 1 = rule matches (hide
     *          hair), 0 = no match (keep hair). The engine reaches it through a named method-binding table rather than
     *          a COL-tagged C++ vtable, so there is no RTTI identity to name-resolve and the prologue ladder is the
     *          strongest available anchor.
     * @note A 3-tier ladder resolving the function entry.
     */
    inline const Candidate POSTFIX_EVAL_CANDIDATES[] = {

        // P1 - full prologue through the first body instruction.
        // The prologue alone is not unique: the same three shadow stores, push set, frame allocation and xmm spill
        // pair appear in other functions in the module. The `mov r15, rdx` that follows is what separates this
        // function from them, so the window has to reach it. The row wildcards the frame size and both spill slots
        // because the compiler assigns them. The match lands on the function start.
        //
        // 48 89 5C 24 08      mov [rsp+0x8], rbx
        // 48 89 6C 24 10      mov [rsp+0x10], rbp
        // 48 89 74 24 18      mov [rsp+0x18], rsi
        // 57                  push rdi
        // 41 56               push r14
        // 41 57               push r15
        // 48 83 EC ??         sub rsp, imm8
        // C5 F8 29 74 24 ??   vmovaps [rsp+d8], xmm6
        // C5 F8 29 7C 24 ??   vmovaps [rsp+d8], xmm7
        // 4C 8B FA            mov r15, rdx
        Candidate::direct(
            "PostfixEval_P1_FullPrologue",
            Pattern::literal(
                "48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 41 56 41 57 48 83 EC ?? C5 F8 29 74 24 ?? "
                "C5 F8 29 7C 24 ?? 4C 8B FA"
            )
        ),

        // P2 - push set, frame allocation, xmm spills, first body instruction.
        // Drops the three shadow stores, which are the part of the prologue a recompile is most likely to reshape: an
        // earlier build spilled a fourth register here instead of pushing it. Walk back 0x0F to the function start.
        //
        // 57                  push rdi
        // 41 56               push r14
        // 41 57               push r15
        // 48 83 EC ??         sub rsp, imm8
        // C5 F8 29 74 24 ??   vmovaps [rsp+d8], xmm6
        // C5 F8 29 7C 24 ??   vmovaps [rsp+d8], xmm7
        // 4C 8B FA            mov r15, rdx
        Candidate::direct(
            "PostfixEval_P2_PushSetToBody",
            Pattern::literal("57 41 56 41 57 48 83 EC ?? C5 F8 29 74 24 ?? C5 F8 29 7C 24 ?? 4C 8B FA"),
            -0x0F
        ),

        // P3 - equipped-item vector header only.
        // Loads the entry array from the rule context, loads the count, scales it by the 0x10 entry stride and forms
        // the end pointer. Independent of the whole prologue. The 0x10 stride encoded by `shl rdi, 4` is the same
        // stride bald_fix.cpp walks the container with, so this window also documents that contract. Walk back 0x24 to
        // the function start.
        //
        // 4C 8B FA      mov r15, rdx
        // 48 8B 5A ??   mov rbx, [rdx+d8]
        // 8B 7A ??      mov edi, [rdx+d8]
        // 48 C1 E7 04   shl rdi, 0x4
        // 48 03 FB      add rdi, rbx
        Candidate::direct(
            "PostfixEval_P3_ItemVectorHeader",
            Pattern::literal("4C 8B FA 48 8B 5A ?? 8B 7A ?? 48 C1 E7 04 48 03 FB"),
            -0x24
        ),
    };

    /**
     * @brief Return-address landmark inside createPrefabFromPartPrefab, the engine-registered profiling label for the
     *        prefab instantiation routine.
     *
     * @details That function instantiates a renderable prefab from a PartPrefab, then calls the rule-eval entry point.
     *          The rule-eval pipeline inside that call reaches PostfixEval on the freshly-built instance. The landmark
     *          is the return address of that call, the byte immediately after it.
     *
     *          Player PostfixEval invocations come from the equipment-visibility update loop elsewhere in the binary
     *          and never include this return address on their stack. bald_fix uses stack presence of this landmark to
     *          reject prefab-instantiation-path calls. It does not cache ctx pointers and it does not depend on
     *          frequency heuristics.
     * @warning This landmark carries a MEANING beyond its address: the row has to name the rule-eval call
     *          specifically, so re-verify the bald fix in game after any change here.
     * @warning Do NOT identify the call by its position in the function. It is not reliably the last call, and the
     *          compiler schedules local cleanup between it and the epilogue, so a "call followed by the frame reload"
     *          row picks up a destructor's return address instead. That resolves cleanly and silently makes the bald
     *          fix reject every NPC. Identify it by its ARGUMENT SETUP instead.
     * @note A 1-row image-wide ladder resolving the return address. A second route, independent of it, is the
     *       NpcPfeCaller string-xref anchor plus @ref NPC_PFE_LANDMARK_LOCAL_CANDIDATES; equip_hide.cpp resolves both
     *       and logs whether they agree.
     */
    inline const Candidate NPC_PFE_RETURN_ADDR_CANDIDATES[] = {

        // P1 - the rule-eval call's argument setup, then the call itself. The `|` marker trails the call, on the byte
        // after it, which IS the return address, so the landmark offset is part of the matched bytes and cannot go
        // stale on its own. The setup loads the world singleton from a module global, walks it to a large sub-object
        // displacement (in the +0x40000 family that LiveTransmog's LoaderRegistry ladder also walks), and passes an
        // outbound `lea r8,[rbp-X]` result slot. The row wildcards the global's RIP displacement, the sub-object
        // displacement and the outbound frame slot. The `add rdx,0x40` argument adjustment ahead of the global load is
        // what makes the window unique image-wide.
        //
        // Do not extend the row past the call. What follows it is a per-thread flag probe whose slot offset
        // (`mov eax/ecx, 0x1FD`, then `0x1FE`) is renumbered by the build and that a TLS-init call can precede.
        //
        // 48 83 C2 40            add rdx, 0x40
        // 48 8B 05 ?? ?? ?? ??   mov rax, [rip+d32]
        // 48 8B 08               mov rcx, [rax]
        // 4C 8D 45 ??            lea r8, [rbp-d8]
        // 48 8B 89 ?? ?? ?? ??   mov rcx, [rcx+d32]
        // E8 ?? ?? ?? ??         call <rel32>
        // |                      result marker, the return address
        Candidate::direct(
            "NpcPfeReturnAddr_P1_RuleEvalCallLandmark",
            Pattern::literal(
                "48 83 C2 40 48 8B 05 ?? ?? ?? ?? 48 8B 08 4C 8D 45 ?? 48 8B 89 ?? ?? ?? ?? E8 ?? ?? ?? ?? |"
            )
        ),
    };

    /**
     * @brief The profiling label the prefab-instantiation routine registers for itself.
     * @details The literal names the function that carries the NpcPfeReturnAddr landmark. The image holds exactly one
     *          copy of it and exactly one instruction references that copy, so a StringXref anchor with
     *          XrefReturn::EnclosingFunction resolves the function entry from the label alone, with no byte pattern
     *          involved. That identity survives the code motion inside the function that a byte row is sensitive to.
     */
    inline constexpr std::string_view NPC_PFE_CALLER_LABEL = "createPrefabFromPartPrefab";

    /**
     * @brief Function-scoped rows that cut the rule-eval return address out of the caller named by
     *        @ref NPC_PFE_CALLER_LABEL.
     * @details Neither row is unique image-wide, so neither may join NPC_PFE_RETURN_ADDR_CANDIDATES. They resolve only
     *          inside the bounds of the enclosing function (derive_npc_pfe_return_addr scopes the scan to the
     *          function's exception-table extent), where each matches once. L1 identifies the call by its argument
     *          setup alone and L2 by the per-thread flag probe the engine emits right after it. A re-registered
     *          argument setup takes down L1 and P1 together, a reshaped probe takes down only L2, and no single change
     *          takes down all three.
     * @note Every row places the `|` marker on the byte after the call, the return address itself.
     */
    inline const Candidate NPC_PFE_LANDMARK_LOCAL_CANDIDATES[] = {

        // L1 - the argument setup through the call: context load, outbound result slot, sub-object walk, call.
        //
        // 48 8B 08               mov rcx, [rax]
        // 4C 8D 45 ??            lea r8, [rbp-d8]
        // 48 8B 89 ?? ?? ?? ??   mov rcx, [rcx+d32]
        // E8 ?? ?? ?? ??         call <rel32>
        Candidate::direct(
            "NpcPfeLandmark_L1_ArgSetupThroughCall",
            Pattern::literal("48 8B 08 4C 8D 45 ?? 48 8B 89 ?? ?? ?? ?? E8 ?? ?? ?? ?? |")
        ),

        // L2 - the call, the TLS-init call the engine emits ahead of the per-thread flag probe, then the probe's flag
        // slot offset and its allocation-size argument. The slot offset's low byte is wildcarded because the build
        // renumbers it.
        //
        // The TLS-init call stays literal. A `[0-5]` gap in its place lets the TLS-init `E8` open a second match with
        // a zero-width gap, so the row would match twice inside the function and fail require_unique.
        //
        // E8 ?? ?? ?? ??         call <rel32>
        // |                      result marker, the return address
        // E8 ?? ?? ?? ??         call <rel32>   ; TLS init
        // B8 ?? 01 00 00         mov eax, 0x1FE
        // BA 10 00 00 00         mov edx, 0x10
        Candidate::direct(
            "NpcPfeLandmark_L2_CallThenFlagProbe",
            Pattern::literal("E8 ?? ?? ?? ?? | E8 ?? ?? ?? ?? B8 ?? 01 00 00 BA 10 00 00 00")
        ),
    };

    /**
     * @enum AnchorId
     * @brief Every address the mod resolves at startup. The enumerator order IS the registry table order.
     * @warning Index the results through these enumerators and never through a literal: inserting a row otherwise
     *          silently re-points every later consumer.
     */
    enum class AnchorId : std::size_t
    {
        /// Module-static slot for the root world-system global (data).
        WorldSystem,
        /// pa::ClientChildOnlyInGameActor vtable (data, .rdata).
        ChildActorVtbl,
        /// IndexedStringA lookup routine entry (code).
        MapLookup,
        /// IndexedStringA insert routine entry (code).
        MapInsert,
        /// The mid-body EquipVisCheck instruction the visibility mid-hook patches (code).
        EquipVisCheck,
        /// PartAddShow function entry (code).
        PartAddShow,
        /// PostfixEval function entry (code).
        PostfixEval,
        /// Return-address landmark inside createPrefabFromPartPrefab (code).
        NpcPfeReturnAddr,
        /// Entry of createPrefabFromPartPrefab, named by its own profiling label through a string xref (code).
        NpcPfeCaller,
        /// VisualEquipChange function entry (code).
        VisualEquipChange,
        /// BatchEquip function entry, which this mod calls VisualEquipSwap (code).
        VisualEquipSwap,
        /// Sentinel: the number of anchors in the registry table.
        Count
    };

    /**
     * @brief Resolves the whole anchor table in one parallel pass and records every address.
     * @details Grades the candidate patterns offline first, then resolves. Each entry's validator rejects a value
     *          outside the host image. A code entry additionally rejects a site whose first byte is zero fill, INT3
     *          padding, or a near return, so a match that landed past the end of a function degrades to a clean miss
     *          instead of a hook on an unrelated address.
     * @note Setup/control-plane only: the pass spawns a worker pool. Never call it under the loader lock.
     */
    void resolve_all_anchors();

    /**
     * @brief The address recorded for @p id, or 0 when its ladder missed.
     * @note Callback-safe after resolve_all_anchors() returns: a plain read of write-once storage.
     */
    [[nodiscard]] std::uintptr_t anchor_address(AnchorId id) noexcept;

    /**
     * @brief The NpcPfeReturnAddr landmark derived from the NpcPfeCaller anchor, or 0.
     * @details Takes the function entry the string-xref anchor resolved, bounds it through the image's exception table,
     *          and resolves @ref NPC_PFE_LANDMARK_LOCAL_CANDIDATES inside that one function only. Independent of the
     *          image-wide byte row: the two agree on a healthy build, and the caller logs a disagreement.
     * @note Setup/control-plane only: one bounded byte scan. Call it after resolve_all_anchors().
     */
    [[nodiscard]] std::uintptr_t derive_npc_pfe_return_addr() noexcept;

    /**
     * @brief The per-anchor drift report, for the startup quality summary and the diagnostics snapshot.
     * @note Callback-safe after resolve_all_anchors() returns.
     */
    [[nodiscard]] std::span<const DetourModKit::anchor::ResolvedAnchor> anchor_report() noexcept;

} // namespace EquipHide

#endif // EQUIPHIDE_AOB_RESOLVER_HPP
