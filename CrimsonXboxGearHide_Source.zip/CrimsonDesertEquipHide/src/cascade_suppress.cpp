#include "cascade_suppress.hpp"
#include "aob_resolver.hpp"
#include "categories.hpp"
#include "shared_state.hpp"

#include <DetourModKit/logger.hpp>
#include <DetourModKit/memory.hpp>
#include <DetourModKit/scan.hpp>

#include <Windows.h>

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string_view>

namespace EquipHide
{
    namespace
    {
        std::atomic<bool> s_equip_change_detected{false};
        std::atomic<VisualEquipChangeFn> s_original_visual_equip_change{nullptr};
        std::atomic<VisualEquipSwapFn> s_original_visual_equip_swap{nullptr};

        // Slot id for chest armor. Only a chest change needs a cascade re-sync - the other armor slots (necklace=9,
        // mask=18, and so on) do not affect the chest lock state.
        constexpr uint16_t CHEST_SLOT = 4;

        // BatchEquip dispatch-entry layout, used to read the per-entry slot id.
        //
        // The engine walks two nested containers here, and the mod must read from the outer one. The outer loop
        // iterates the swap entries handed to on_visual_equip_swap: it loads the list head, takes the count from the
        // head's `+8`, and forms the end pointer with an `imul <reg>, rax, <stride>`. The inner loop searches one
        // actor's authority table with a different stride and a different slot field. A read of the inner values
        // mis-indexes every entry, so the mod decodes both constants below from the outer loop.
        //
        // The mod decodes both values live and does not hardcode them. The entry width changes across builds, so a
        // fixed size mis-reads the slot id silently instead of failing. The nominal is the last verified layout, and
        // the code uses it only when the decode fails. Verify it against live memory on patch day.
        //
        // Stride: the imm32 of the outer `imul <reg>, rax, <stride>`. No candidate pins that imm32. P1 and P2 stop
        // before it, and P3 wildcards it. The pattern therefore stays value-agnostic and self-heals when the entry
        // width changes.
        //
        // A short branch sits between the outer loop head and the imul, and the same three-instruction shape appears at
        // an unrelated container-iteration site. No branch-free window tells the two sites apart, so each candidate
        // below spans that jump, as a `[2-6]` bounded gap that admits the 2-byte rel8 and the 6-byte rel32 encoding.
        // A build that rewrites the jump into something else entirely still stops the candidate from matching, and
        // the mod accepts that outcome: the decode keeps the nominal instead of resolving to the wrong site.
        //
        // Every candidate below puts the `|` result marker on the IMUL ITSELF, which is the instruction
        // read_code_constant decodes the operand from. The marker rides the matched bytes, so a fold or reflow ahead
        // of the imul either still matches with the marker on the imul or fails to match at all. No counted walk-back
        // is left to go stale and decode a neighboring instruction's bytes as the stride.
        const DMK::scan::Candidate EQUIP_SWAP_STRIDE_SITE[] = {
            // P1 - outer loop head through the imul. Widest context, anchored before the null check.
            //
            // C7 85 ?? ?? ?? ?? ?? ?? ?? ??   mov [rbp+d32], imm32
            // 49 8B 19                        mov rbx, [r9]
            // 48 85 DB                        test rbx, rbx
            // [2-6]                           je <rel8 or rel32>
            // 8B 43 08                        mov eax, [rbx+0x8]
            // 48 69 F8                        imul rdi, rax, imm32 (truncated)   <- result marker
            DMK::scan::Candidate::direct(
                "BatchEquipStride_P1_LoopHeadToImul",
                DMK::scan::Pattern::literal("C7 85 ?? ?? ?? ?? ?? ?? ?? ?? 49 8B 19 48 85 DB [2-6] 8B 43 08 | 48 69 F8")
            ),

            // P2 - null check through the imul. Drops the preceding frame initialization.
            //
            // 49 8B 19   mov rbx, [r9]
            // 48 85 DB   test rbx, rbx
            // [2-6]      je <rel8 or rel32>
            // 8B 43 08   mov eax, [rbx+0x8]
            // 48 69 F8   imul rdi, rax, imm32 (truncated)   <- result marker
            DMK::scan::Candidate::direct(
                "BatchEquipStride_P2_NullCheckToImul",
                DMK::scan::Pattern::literal("49 8B 19 48 85 DB [2-6] 8B 43 08 | 48 69 F8")
            ),

            // P3 - imul forward into the branch that follows it. Independent of everything before the imul, so it
            // survives a rewrite of the loop head that defeats P1 and P2. The join jmp sits in a `[2-5]` gap, the
            // 2-byte rel8 and the 5-byte rel32 form.
            //
            // 8B 43 08               mov eax, [rbx+0x8]
            // 48 69 F8 ?? ?? ?? ??   imul rdi, rax, imm32   <- result marker
            // 48 03 3B               add rdi, [rbx]
            // 48 8B 1B               mov rbx, [rbx]
            // [2-5]                  jmp <rel8 or rel32>
            // 49 8B 49 08            mov rcx, [r9+0x8]
            DMK::scan::Candidate::direct(
                "BatchEquipStride_P3_ImulToJoin",
                DMK::scan::Pattern::literal("8B 43 08 | 48 69 F8 ?? ?? ?? ?? 48 03 3B 48 8B 1B [2-5] 49 8B 49 08")
            ),
        };

        // Slot: the disp32 of `movzx eax, word ptr [rbx+<slot>]`, where rbx is the current outer entry. The instruction
        // that follows compares that word against the inner table's own slot field, which uses a different offset.
        // Anchor on the movzx, not on the compare: P1 carries the `|` marker on it, P2 and P3 start on it.
        const DMK::scan::Candidate EQUIP_SWAP_SLOT_SITE[] = {
            // P1 - inner-loop setup through the movzx. Widest context and unique across the whole process.
            //
            // 48 69 C8 ?? ?? ?? ??   imul rcx, rax, imm32
            // 48 03 CA               add rcx, rdx
            // 48 3B D1               cmp rdx, rcx
            // [2-6]                  je <rel8 or rel32>
            // 0F B7 83               movzx eax, word [rbx+d32] (truncated)   <- result marker
            DMK::scan::Candidate::direct(
                "BatchEquipSlot_P1_InnerSetupToMovzx",
                DMK::scan::Pattern::literal("48 69 C8 ?? ?? ?? ?? 48 03 CA 48 3B D1 [2-6] | 0F B7 83")
            ),

            // P2 - movzx and compare, extended into the entry advance that follows.
            //
            // 0F B7 83 ?? ?? ?? ??   movzx eax, word [rbx+d32]
            // 66 39 82 ?? ?? ?? ??   cmp [rdx+d32], ax
            // [2-6]                  je <rel8 or rel32>
            // 48 81 C2               add rdx, imm32 (truncated)
            DMK::scan::Candidate::direct(
                "BatchEquipSlot_P2_MovzxCompareAdvance",
                DMK::scan::Pattern::literal("0F B7 83 ?? ?? ?? ?? 66 39 82 ?? ?? ?? ?? [2-6] 48 81 C2")
            ),

            // P3 - movzx and compare only. The pattern wildcards both displacements, so a shifted slot field still
            // matches.
            //
            // 0F B7 83 ?? ?? ?? ??   movzx eax, word [rbx+d32]
            // 66 39 82 ?? ?? ?? ??   cmp [rdx+d32], ax
            DMK::scan::Candidate::direct(
                "BatchEquipSlot_P3_MovzxCompare",
                DMK::scan::Pattern::literal("0F B7 83 ?? ?? ?? ?? 66 39 82 ?? ?? ?? ??")
            ),
        };

        /**
         * @brief One layout-constant decode request.
         * @details Designated initializers name every field at the call site. The two adjacent range bounds and the
         *          nominal therefore cannot transpose without a visible diagnostic.
         */
        struct LayoutConstantRequest
        {
            /// Candidate ladder that locates the instruction carrying the constant.
            std::span<const DMK::scan::Candidate> site{};
            /// Operand class the decoder reads from that instruction.
            DMK::scan::OperandKind kind{};
            /// Zero-based operand index within the instruction.
            std::uint8_t operand_index{0};
            /// Inclusive lower bound of the accepted decoded value.
            std::int64_t lo{0};
            /// Inclusive upper bound of the accepted decoded value.
            std::int64_t hi{0};
            /// Last verified layout value, kept whenever the decode misses.
            std::size_t nominal{0};
            /// Short constant name used in the log line.
            std::string_view label{};
        };

        // Decode an instruction operand to a layout constant, validated to a plausible range. On any miss, out-of-range
        // value, or decode exception the code keeps the nominal. A wrong anchor or operand index therefore can never
        // mis-read the dispatch entry. The code logs the decoded value once for verification.
        [[nodiscard]] std::size_t decode_layout_constant(const LayoutConstantRequest &request) noexcept
        {
            try
            {
                DMK::scan::CodeConstant cc{};
                cc.site = request.site;
                cc.kind = request.kind;
                cc.operand_index = request.operand_index;
                cc.nominal = static_cast<std::int64_t>(request.nominal);
                cc.has_nominal = true;
                const auto decoded = DMK::scan::read_code_constant(cc);
                if (decoded.has_value() && *decoded >= request.lo && *decoded <= request.hi)
                {
                    const auto value = static_cast<std::size_t>(*decoded);
                    // A live value != nominal means the engine layout drifted on a patch. The decode self-heals it, but
                    // reports a WARNING so the offset change is easy to find in the log.
                    if (value != request.nominal)
                        DMK::log().warning(
                            "BatchEquip {} DRIFTED: live={} nominal={} - self-healed (engine layout changed)",
                            request.label,
                            value,
                            request.nominal
                        );
                    else
                        DMK::log().info("BatchEquip {} decoded live: {} (matches nominal)", request.label, value);
                    return value;
                }
                DMK::log().warning(
                    "BatchEquip {} live-decode out of range/unavailable; using nominal {}",
                    request.label,
                    request.nominal
                );
            }
            catch (...)
            {
                // Fail closed and loud. A silent swallow here hides a decode that never ran, and the nominal below then
                // looks like a successful match.
                static std::atomic<bool> s_throw_logged{false};
                if (!s_throw_logged.exchange(true, std::memory_order_relaxed))
                    (void)DMK::log().try_log(
                        DMK::LogLevel::Warning,
                        "BatchEquip {} live-decode raised an exception. Using nominal {}",
                        request.label,
                        request.nominal
                    );
            }
            return request.nominal;
        }

        [[nodiscard]] std::size_t equip_swap_entry_stride() noexcept
        {
            // Nominal is the outer entry stride, 240 (0xF0). The accepted range leaves headroom on both sides so a
            // further change of entry width still decodes instead of a fall back to the nominal.
            static const std::size_t value = decode_layout_constant(
                LayoutConstantRequest{
                    .site = EQUIP_SWAP_STRIDE_SITE,
                    .kind = DMK::scan::OperandKind::Immediate,
                    .operand_index = 2,
                    .lo = 216,
                    .hi = 264,
                    .nominal = 240,
                    .label = "stride",
                }
            );
            return value;
        }

        [[nodiscard]] std::size_t equip_swap_slot_offset() noexcept
        {
            // Nominal is the slot field of the outer entry, 216 (0xD8). Do not set this to the inner table's slot
            // field: that one sits at a different offset and belongs to a container with a different stride.
            static const std::size_t value = decode_layout_constant(
                LayoutConstantRequest{
                    .site = EQUIP_SWAP_SLOT_SITE,
                    .kind = DMK::scan::OperandKind::MemoryDisplacement,
                    .operand_index = 1,
                    .lo = 192,
                    .hi = 240,
                    .nominal = 216,
                    .label = "slot",
                }
            );
            return value;
        }
    } // namespace

    void set_visual_equip_change_trampoline(VisualEquipChangeFn original) noexcept
    {
        s_original_visual_equip_change.store(original, std::memory_order_relaxed);
    }

    __int64 __fastcall on_visual_equip_change(__int64 body_comp, int16_t slot_id, int16_t item_id, __int64 itemData)
    {
        DMK::log().trace("VisualEquipChange: slot={} item={}", slot_id, item_id);

        if (flag_cascade_fix().load(std::memory_order_relaxed) && is_category_hidden(Category::Chest) &&
            slot_id == CHEST_SLOT)
        {
            DMK::log().debug("VisualEquipChange: chest slot={} item={} - clearing cascade locks", slot_id, item_id);
            s_equip_change_detected.store(true, std::memory_order_relaxed);
        }
        // Snapshot guards a teardown race. A drop of the Hook handle restores the prologue and disables the detour,
        // but a game thread already past the JMP can still enter the body before the DLL unmaps. A return of zero
        // matches the engine no-op shape for this slot-update API.
        const auto trampoline = s_original_visual_equip_change.load(std::memory_order_relaxed);
        if (!trampoline)
            return 0;
        return trampoline(body_comp, slot_id, item_id, itemData);
    }

    void set_visual_equip_swap_trampoline(VisualEquipSwapFn original) noexcept
    {
        s_original_visual_equip_swap.store(original, std::memory_order_relaxed);
        // Warm the layout self-heal at install (setup/control-plane). The dispatch-entry stride and slot then decode
        // and cache before the first swap, and the hot path stays free of the one-time AOB scan.
        (void)equip_swap_entry_stride();
        (void)equip_swap_slot_offset();
    }

    __int64 __fastcall on_visual_equip_swap(__int64 *a1, __int64 *a2, __int64 **a3, __int64 **a4)
    {
        __try
        {
            // Log all swapped slots at trace level for future reference.
            auto &logger = DMK::log();
            __int64 *iter = a4 ? (*a4 ? *a4 : a4[1]) : nullptr;
            if (iter)
            {
                // The list head sits at [iter] and the live entry count at [iter+8]. Guarded reads make a stale or
                // reshaped dispatch list a per-entry miss instead of a fault the frame below has to absorb.
                const auto base = DMK::memory::read<std::uintptr_t>(DMK::Address{iter});
                const auto count = DMK::memory::read<std::uint32_t>(DMK::Address{iter}.offset(8));
                bool has_chest = false;
                const uint32_t entries = (base && count) ? *count : 0;
                for (uint32_t i = 0; i < entries && i < 16; ++i)
                {
                    const auto slot = DMK::memory::read<std::uint16_t>(DMK::Address{*base}.offset(
                        static_cast<std::ptrdiff_t>(equip_swap_entry_stride() * i + equip_swap_slot_offset())
                    ));
                    if (!slot)
                        break;
                    logger.trace("EquipSwap: slot={}", *slot);
                    if (*slot == CHEST_SLOT)
                        has_chest = true;
                }

                if (has_chest && flag_cascade_fix().load(std::memory_order_relaxed) &&
                    is_category_hidden(Category::Chest))
                {
                    logger.debug("EquipSwap: chest slot detected - signaling re-sync");
                    s_equip_change_detected.store(true, std::memory_order_relaxed);
                }
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            // Fail closed and loud. A silent swallow hides a reshaped dispatch list, and the chest re-sync then stops
            // firing with the hook still reporting installed.
            static std::atomic<bool> s_crash_logged{false};
            if (!s_crash_logged.exchange(true, std::memory_order_relaxed))
                (void)DMK::log().try_log(DMK::LogLevel::Warning, "EquipSwap: SEH caught crash in the slot walk");
        }
        // Snapshot guards a teardown race (see on_visual_equip_change).
        const auto trampoline = s_original_visual_equip_swap.load(std::memory_order_relaxed);
        if (!trampoline)
            return 0;
        return trampoline(a1, a2, a3, a4);
    }

    bool consume_equip_change() noexcept
    {
        return s_equip_change_detected.exchange(false, std::memory_order_relaxed);
    }

} // namespace EquipHide
