#include "version.hpp"

#include <DetourModKit.hpp>

namespace EquipHide::version
{
    void log_version_info()
    {
        auto &logger = DMK::log();
        logger.info("{} {} ({} {})", MOD_NAME, TAG, BUILD_DATE, BUILD_TIME);
        logger.info("Author: {}", AUTHOR);
        logger.info("Source: {}", REPOSITORY);
        logger.info("Nexus:  {}", NEXUS_URL);
    }

} // namespace EquipHide::version
