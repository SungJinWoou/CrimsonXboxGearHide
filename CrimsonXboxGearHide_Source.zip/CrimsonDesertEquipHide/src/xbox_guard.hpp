#pragma once
// Xbox-specific build gate for CrimsonXboxGearHide. No code writes or hooks here.
// This gate recognizes one executable, NOT all Game Pass builds.
// Original Gear Hide authorship/licensing retained (MIT); this is an experimental downstream adaptation.
#include <Windows.h>
#include <array>
#include <cstdint>
#include <cstring>
#include <string>

namespace XboxGuard {
struct Result {
    bool recognized;
    const char* reason;
    const char* failed_check;
    unsigned passed;
};
struct Sample {
    const char* name;
    std::uint32_t rva;
    std::array<std::uint8_t, 16> bytes;
};
inline Result verify_game_image() noexcept {
    const auto* base = reinterpret_cast<const std::uint8_t*>(GetModuleHandleW(nullptr));
    if (!base) return {false, "No game executable base", "", 0};
    const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0 || dos->e_lfanew > 0x1000)
        return {false, "Invalid executable PE header", "", 0};
    const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS64*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE || nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC)
        return {false, "Invalid 64-bit image", "", 0};
    constexpr std::uint32_t expected_image_size = 0x13774000u;
    if (nt->OptionalHeader.SizeOfImage != expected_image_size)
        return {false, "Unsupported Xbox executable SizeOfImage", "", 0};
    static constexpr std::array<Sample, 6> known_samples{{
        {"EquipVisCheck", 0x00B64EC5u, {0x45, 0x0F, 0xB6, 0x58, 0x20, 0x48, 0x8B, 0xD9, 0x41, 0x80, 0xFB, 0x03, 0x0F, 0x84, 0x86, 0x00}},
        {"PartAddShow", 0x00B65F60u, {0x40, 0x53, 0x57, 0x41, 0x54, 0x48, 0x83, 0xEC, 0x60, 0x48, 0x8B, 0x59, 0x78, 0x4D, 0x8B, 0xE0}},
        {"WorldSystem", 0x003B0E22u, {0x48, 0x8B, 0x05, 0xB7, 0xFF, 0xE4, 0x06, 0x48, 0x8B, 0x88, 0xD8, 0x00, 0x00, 0x00, 0x48, 0x8B}},
        {"MapLookup", 0x038CD8D0u, {0x48, 0x83, 0xEC, 0x08, 0x83, 0x79, 0x04, 0x00, 0x4C, 0x8B, 0xC1, 0x75, 0x07, 0x33, 0xC0, 0x48}},
        {"PostfixEval", 0x02F49050u, {0x48, 0x89, 0x5C, 0x24, 0x08, 0x48, 0x89, 0x6C, 0x24, 0x10, 0x48, 0x89, 0x74, 0x24, 0x18, 0x57}},
        {"MapInsert", 0x02E7BDF0u, {0x40, 0x53, 0x56, 0x57, 0x41, 0x54, 0x41, 0x55, 0x48, 0x83, 0xEC, 0x20, 0x83, 0x39, 0x00, 0x4D}},
    }};
    unsigned passed = 0;
    for (const auto& s : known_samples) {
        if (s.rva > expected_image_size - s.bytes.size())
            return {false, "Sample out of image range", s.name, passed};
        if (std::memcmp(base + s.rva, s.bytes.data(), s.bytes.size()) != 0)
            return {false, "Executable instructions differ", s.name, passed};
        ++passed;
    }
    return {true, "Xbox executable samples verified", "", passed};
}
inline std::wstring default_ini_path() {
    wchar_t exe_path[32768] = {};
    const DWORD count = GetModuleFileNameW(nullptr, exe_path, 32768);
    if (!count || count >= 32768) return {};
    std::wstring result(exe_path, count);
    const auto i = result.find_last_of(L"\\/");
    if (i == std::wstring::npos) return {};
    result.resize(i + 1);
    result.append(L"CrimsonDesertEquipHide.ini");
    return result;
}
inline bool user_enabled_hooks() {
    const auto ini = default_ini_path();
    if (ini.empty()) return false;
    return GetPrivateProfileIntW(L"XboxCompatibility", L"EnableExperimentalHooks", 0, ini.c_str()) == 1;
}
} // namespace XboxGuard
