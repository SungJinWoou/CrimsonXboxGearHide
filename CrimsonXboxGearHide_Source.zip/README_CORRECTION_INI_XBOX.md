# Correction du chemin de configuration Xbox (9 novembre 2026)

Le journal precedent confirme un demarrage correct : Xbox guard 6/6.
Mais l'EXE a ete vu dans C:\Program Files\WindowsApps, tandis que les fichiers du mod sont copies dans C:\XboxGames\...\bin64.

Dans la version precedente, GetModuleFileNameW(nullptr) prenait le chemin de l'EXE (WindowsApps), pas celui de l'ASI. Ainsi `EnableExperimentalHooks=1` aurait pu etre ignore si le fichier INI etait dans XboxGames.

Le correctif cherche `CrimsonDesertEquipHide.ini` dans le dossier du module CrimsonDesertEquipHide.asi. S'il ne le trouve pas, les hooks restent desactives. Le nouveau journal affiche :
`Xbox INI next to ASI: FOUND` ou `MISSING`.

Cette archive est la SOURCE, pas un ASI compile. Pour reconstruire avec le workflow GitHub deja fonctionnel :
1. Dans le depot, remplacer **CrimsonXboxGearHide_Source.zip** a la racine par ce ZIP de meme nom.
2. Valider le commit (cela declenche le workflow).
3. Recuperer le nouvel artefact, remplacer l'ancien ASI ET l'INI cote a cote dans bin64.
4. Tester d'abord avec `EnableExperimentalHooks=0`, puis consulter le nouveau log ; s'assurer de `Xbox INI next to ASI: FOUND`.
5. Seulement en acceptant le risque de crash, tenter `EnableExperimentalHooks=1` hors jeu. Ne pas sauvegarder lors du premier test.

Attention : `6/6` confirme seulement six blocs d'instructions ; il ne garantit pas la securite des hooks Xbox.
Cette adaptation utilise le code original MIT de tkhquang ; la licence est preservee.
