# CrimsonXboxGearHide — diagnostic hook v0.2 (expérimental)

Ce correctif SOURCE ne modifie pas la logique de masquage. Il ajoute des compteurs et un readback mémoire aux fonctions de la v0.1, afin de comprendre pourquoi les logs indiquent « hidden » alors que l'objet 3D reste affiché.

## Résultats de ton précédent log
- Xbox guard : 6/6 OK ; anchor resolution : 11/11 ; mid-hook installé et actif ; Kliff détecté.
- F10 est reconnue et les trois catégories passent HIDDEN / VISIBLE.
- DirectWrite écrit de nombreuses entrées, sans preuve que le moteur 3D applique leur visibilité.

## Installation / compilation
1. Sur GitHub, remplace le fichier à la racine **CrimsonXboxGearHide_Source.zip** par cette archive portant le même nom.
2. Commit changes pour reconstruire l'ASI avec ton workflow GitHub Actions actuel.
3. Télécharge le nouvel artifact ; remplace uniquement l'ASI (et laisse l'INI si déjà configuré).
4. Ferme le jeu avant toute opération. Sauvegardes de sécurité conservées. Essai hors ligne et sans sauvegarder.
5. Dans `CrimsonDesertEquipHide.ini` garde `EnableExperimentalHooks=1` pour ce test (si le précédent lancement a été stable) et `LogLevel = Info`.
6. Lance une partie, équipe une arme visible, laisse-la rengainée, appuie sur F10 une fois. Marche quelques secondes, sors/rengaine l'arme, puis F10 à nouveau et ferme le jeu.
7. Envoie le nouveau fichier `CrimsonDesertEquipHide.log`.

## Nouveaux diagnostics
Chaque changement de catégorie par F10 affiche une ligne :
`XboxHookProbe: entered=... hash_read=... classified=... player_pass=... hide_requested=... byte2_readback=...`

Interprétation :
- `entered=0` : le hook est installé mais le moteur ne passe pas par cette instruction pendant le test.
- `entered>0` et `hash_read=0` : lecture du pointeur / du registre RDX non valide.
- `hash_read>0` et `classified=0` : aucune pièce reconnue par notre mapping de catégories.
- `classified>0` et `player_pass=0` : identification du contexte joueur incorrecte.
- `player_pass>0` et `hide_requested=0` : la logique n'atteint pas une catégorie masquée.
- `hide_requested>0` mais `byte2_readback=0` : écriture non validée.
- `byte2_readback>0` et aucun changement visuel : visibilité du modèle 3D recalculée ailleurs, ou autre état/maillage concerné.

Le log DirectWrite ajoute également `byte2_readback`, immédiat et non une garantie de résultat visuel.
Ce projet réutilise légalement le code MIT de CrimsonDesertEquipHide / tkhquang et conserve la licence d'origine.

ATTENTION : Projet expérimental, le jeu peut planter ou les équipements se comporter anormalement. Aucun correctif de gameplay validé à ce stade. Ne pas confondre compilation et réussite fonctionnelle.
