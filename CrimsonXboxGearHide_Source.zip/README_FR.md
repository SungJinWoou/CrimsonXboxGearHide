# CrimsonXboxGearHide — Xbox PC experimental source port (0.1)

## What this is

An MIT-licensed downstream source adaptation of **CrimsonDesertEquipHide 0.10.2** (tkhquang).
This is **not** a port of Sov3ryn and does not modify or reuse Sov3ryn's proprietary ASI.
It aims only to hide equipped items, starting with one-handed weapons, two-handed weapons and shields.

## Verified in this session

- ZIP includes the full original source and necessary submodules (DetourModKit, SafetyHook, SimpleIni, DirectXMath).
- Xbox executable SHA256: `15ea299752f3757fbe13400739498cab361502aa0ebd43ef563b713bd935b242`.
- Six code samples in your executable match the included `src/xbox_guard.hpp` exactly.
- The `EquipVisCheck` sample begins `45 0F B6 58 20` and is at Xbox image RVA `0x00B64EC5`.
- Original game mod logic performs mid-hooks and visibility writes; the Xbox version is NOT yet runtime tested.

## Safety decisions

- `XboxGuard::verify_game_image()` rejects other executables before any game hook.
- `EnableExperimentalHooks=0` (default) means **read-only identification, no gameplay hooks**.
- With `EnableExperimentalHooks=1`, the upstream Gear Hide code will attempt the real visibility hook and other runtime behavior. **Not yet tested on Xbox PC**. This is a potentially unstable opt-in experiment, not a released mod.
- The Xbox guard checks `SizeOfImage` and six code sequences. It is not a full runtime SHA-256 computation or a proof that structures are safe.
- `BaldFix`, `GlidingFix`, `CascadeFix` disabled in the supplied test configuration. All gear categories disabled except `OneHandWeapons`, `TwoHandWeapons`, `Shields`. F10 toggles these three categories. No gear hidden by default.

## Build (Windows)

1. Install **Visual Studio 2022** with the **Desktop development with C++** workload and CMake version **3.28+**.
2. Extract this project. Open PowerShell in its root.
3. Ensure network access for the first CMake configure: SafetyHook can fetch Zydis/Zycore automatically. Run `powershell -ExecutionPolicy Bypass -File .\build_xbox.ps1`. Inspect scripts before running them.
4. Output appears in `OUTPUT_XBOX_TEST/` if compilation succeeds. This was not compiled in the assistant's Linux environment: it lacks the Microsoft C++ standard library / Windows SDK.

## Alternative build: GitHub Actions

If you do not have Visual Studio, create a repository containing this source (including `.github/workflows/build-xbox.yml`), then trigger **Build Xbox Gear Hide (experimental)** with *Actions > Run workflow*. Download the generated artifact named `CrimsonXboxGearHide-experimental`. This workflow has not been run or validated in this environment.

## Test

1. Keep your already-backed-up saves safe. Close game and DMM.
2. Temporarily disable **Sov3ryn Mod Hub's visibility fixes** and other gear-hiding ASIs to avoid simultaneous hooks. Keep necessary loaders active.
3. Place ONLY `CrimsonDesertEquipHide.asi` + `CrimsonDesertEquipHide.ini` into `bin64`; **do not replace winmm.dll or install a second ASI loader**.
4. Initial run with `EnableExperimentalHooks=0`: inspect `CrimsonDesertEquipHide.log` for `Xbox guard: 6/6` and `hooks DISABLED`. No gear change expected.
5. **Only if you accept the risk of an unstable mod**, close the game and change `EnableExperimentalHooks=1`. Relaunch, inspect log for `Hook installed at...`, then (in game) try F10 with a one-handed weapon equipped.
6. If game crashes or equips vanish unexpectedly, remove `.asi` and restore config. Avoid saving during testing.
7. Send the generated `CrimsonDesertEquipHide.log` with the state (menu/gameplay; whether F10 works).

## Attribution

Original implementation copyright Quang Trinh (tkhquang), MIT License, details in LICENSE_ORIGINAL_MIT.txt and original project docs. This experiment is not endorsed by the author.
