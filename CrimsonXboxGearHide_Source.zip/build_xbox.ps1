# Builds only. Does not touch Crimson Desert installation.
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) {
    throw 'CMake 3.28+ is required. Install Visual Studio 2022 with Desktop development with C++ and CMake.'
}
$cmakeVersion = (cmake --version | Select-Object -First 1)
Write-Host "Build tool: $cmakeVersion"
Push-Location 'CrimsonDesertEquipHide'
try {
    cmake --preset msvc-release
    if ($LASTEXITCODE -ne 0) { throw 'CMake configure failed' }
    cmake --build build/release-msvc --config Release --parallel
    if ($LASTEXITCODE -ne 0) { throw 'Build failed' }
    $candidate = Get-ChildItem -Recurse -Path build/release-msvc -Filter CrimsonDesertEquipHide.asi | Select-Object -First 1
    if (-not $candidate) { throw 'Built .asi not found' }
    $dist = Join-Path $PSScriptRoot 'OUTPUT_XBOX_TEST'
    New-Item -ItemType Directory -Force -Path $dist | Out-Null
    Copy-Item $candidate.FullName (Join-Path $dist 'CrimsonDesertEquipHide.asi') -Force
    Copy-Item (Join-Path $PSScriptRoot 'CrimsonDesertEquipHide_Xbox_Test.ini') (Join-Path $dist 'CrimsonDesertEquipHide.ini') -Force
    Copy-Item (Join-Path $PSScriptRoot 'LICENSE_ORIGINAL_MIT.txt') (Join-Path $dist 'LICENSE_ORIGINAL_MIT.txt') -Force
    Write-Host "Built: $dist" -ForegroundColor Green
    Write-Host 'Do not copy the original repository loader DLL: use your existing DMM winmm.dll.'
}
finally { Pop-Location }
