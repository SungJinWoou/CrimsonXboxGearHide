#!/usr/bin/env python3
"""Pure-Python validation for EXACT Xbox CrimsonDesert.exe build; no game modifications."""
import hashlib, sys, pathlib,struct
EXPECTED='15ea299752f3757fbe13400739498cab361502aa0ebd43ef563b713bd935b242'
p=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else None
if not p or not p.exists():
    print('Usage: python verify_xbox_exe.py "C:\\XboxGames\\Crimson Desert_1\\Content\\packages\\bin64\\CrimsonDesert.exe"');sys.exit(2)
h=hashlib.sha256()
with p.open('rb') as f:
    for data in iter(lambda:f.read(4*1024*1024),b''):h.update(data)
print('SHA256:',h.hexdigest())
if h.hexdigest()==EXPECTED:
    print('PASS: identical to the user-supplied Xbox PC executable');sys.exit(0)
print('FAIL: different executable. Do not enable experimental hooks.');sys.exit(1)
